/**
 * src/components/stadium/StadiumMaterials.js
 *
 * ══════════════════════════════════════════════════════════════════════════
 *  ФАБРИКА МАТЕРИАЛОВ С КЭШЕМ
 *
 *  ─── ПРИНЦИПЫ ────────────────────────────────────────────────────────────
 *    • Один материал = одна инстанция на всю сцену.
 *    • Все запросы через getX() функции — они возвращают кэшированный объект.
 *    • Ключ кэша — строковый идентификатор (не ссылка на конфиг).
 *    • Материалы никогда не мутируются после создания.
 *    • disposeAll() полностью очищает кэш при уничтожении сцены.
 *
 *  ─── ЗАЧЕМ КЭШ ──────────────────────────────────────────────────────────
 *    • Экономия GPU-памяти: у нас ~93 000 мест, ~5 000 колонн и рёбер.
 *      Без кэша драйвер создал бы сотни идентичных программ шейдеров.
 *    • Быстрый рендер: Three.js группирует объекты по материалам.
 *      Один материал → один draw call в идеале.
 *    • Единая палитра: изменение цвета в одном месте меняет всё.
 *
 *  ─── СОГЛАШЕНИЯ ПО ИМЕНОВАНИЮ ────────────────────────────────────────────
 *    getXxx()  — кэшированный материал (всегда возвращает тот же объект)
 *    createXxx() — НЕ кэшированный, уникальный экземпляр
 *                  (например, материал мест — может понадобиться per-instance)
 * ══════════════════════════════════════════════════════════════════════════
 */

import * as THREE from 'three';
import { STADIUM_CONFIG } from './StadiumConfig.js';


/* ══════════════════════════════════════════════════════════════════════════
 *  § 1. КЭШ
 * ══════════════════════════════════════════════════════════════════════════ */

/**
 * Внутренний кэш материалов.
 * Ключ — строковый идентификатор, значение — THREE.Material.
 * @type {Map<string, THREE.Material>}
 */
const materialCache = new Map();

/**
 * Возвращает материал из кэша или создаёт его фабрикой.
 *
 * @param {string}   key      — уникальный идентификатор материала
 * @param {Function} factory  — функция, возвращающая новый материал
 * @returns {THREE.Material}
 */
function cached(key, factory) {
    if (!materialCache.has(key)) {
        const material = factory();
        materialCache.set(key, material);
    }
    return materialCache.get(key);
}

/**
 * Ссылка на раздел материалов в конфиге (для краткости).
 */
const M = STADIUM_CONFIG.materials;


/* ══════════════════════════════════════════════════════════════════════════
 *  § 2. БЕТОН
 * ══════════════════════════════════════════════════════════════════════════ */

/**
 * Светлый бетон — поверхности трибун, ступени, пол.
 * @returns {THREE.MeshStandardMaterial}
 */
export function getConcrete() {
    return cached('concrete', () => new THREE.MeshStandardMaterial({
        name: 'concrete',
        color: M.concrete.color,
        roughness: M.concrete.roughness,
        metalness: M.concrete.metalness,
    }));
}

/**
 * Тёмный бетон — цоколь, фундамент, нижние уровни.
 * @returns {THREE.MeshStandardMaterial}
 */
export function getDarkConcrete() {
    return cached('darkConcrete', () => new THREE.MeshStandardMaterial({
        name: 'darkConcrete',
        color: M.darkConcrete.color,
        roughness: M.darkConcrete.roughness,
        metalness: M.darkConcrete.metalness,
    }));
}


/* ══════════════════════════════════════════════════════════════════════════
 *  § 3. МЕТАЛЛ
 * ══════════════════════════════════════════════════════════════════════════ */

/**
 * Светлая сталь — несущие колонны, фермы, стойки прожекторов.
 * @returns {THREE.MeshStandardMaterial}
 */
export function getSteel() {
    return cached('steel', () => new THREE.MeshStandardMaterial({
        name: 'steel',
        color: M.steel.color,
        roughness: M.steel.roughness,
        metalness: M.steel.metalness,
    }));
}

/**
 * Тёмная сталь — отделка, основания колонн, декоративные элементы.
 * @returns {THREE.MeshStandardMaterial}
 */
export function getDarkSteel() {
    return cached('darkSteel', () => new THREE.MeshStandardMaterial({
        name: 'darkSteel',
        color: M.darkSteel.color,
        roughness: M.darkSteel.roughness,
        metalness: M.darkSteel.metalness,
    }));
}


/* ══════════════════════════════════════════════════════════════════════════
 *  § 4. СТЕКЛО
 * ══════════════════════════════════════════════════════════════════════════ */

/**
 * Стекло фасада — MeshPhysicalMaterial с transmission.
 * Прозрачное, но с отражениями и лёгким тинтом.
 *
 * ВАЖНО: для корректного transmission нужен envMap на сцене.
 * Без него материал будет выглядеть как матовый белый.
 *
 * @returns {THREE.MeshPhysicalMaterial}
 */
export function getGlass() {
    return cached('glass', () => new THREE.MeshPhysicalMaterial({
        name: 'glass',
        color: M.glass.color,
        roughness: M.glass.roughness,
        metalness: M.glass.metalness,
        transmission: M.glass.transmission,
        thickness: M.glass.thickness,
        ior: 1.5,
        transparent: true,
        opacity: 1.0,
        side: THREE.DoubleSide,
        /* Стекло не отбрасывает тени в этой сцене — иначе будет темнить
         * всё, что за ним. */
        depthWrite: false,
    }));
}


/* ══════════════════════════════════════════════════════════════════════════
 *  § 5. КРЫША
 * ══════════════════════════════════════════════════════════════════════════ */

/**
 * Верхняя поверхность крыши — светлая, отражающая.
 * @returns {THREE.MeshStandardMaterial}
 */
export function getRoofTop() {
    return cached('roofTop', () => new THREE.MeshStandardMaterial({
        name: 'roofTop',
        color: M.roofTop.color,
        roughness: M.roofTop.roughness,
        metalness: M.roofTop.metalness,
        side: THREE.DoubleSide,
    }));
}

/**
 * Нижняя поверхность крыши — тёмная (видна из чаши).
 * Отдельный материал нужен, потому что «изнутри» крыша всегда темнее
 * из-за отсутствия прямого света.
 * @returns {THREE.MeshStandardMaterial}
 */
export function getRoofBottom() {
    return cached('roofBottom', () => new THREE.MeshStandardMaterial({
        name: 'roofBottom',
        color: M.roofBottom.color,
        roughness: M.roofBottom.roughness,
        metalness: M.roofBottom.metalness,
        side: THREE.DoubleSide,
    }));
}


/* ══════════════════════════════════════════════════════════════════════════
 *  § 6. ЗЕМЛЯ / ПОДСТИЛАЮЩАЯ ПОВЕРХНОСТЬ
 * ══════════════════════════════════════════════════════════════════════════ */

/**
 * Земля вокруг стадиона — тёмная, полностью матовая.
 * @returns {THREE.MeshStandardMaterial}
 */
export function getGround() {
    return cached('ground', () => new THREE.MeshStandardMaterial({
        name: 'ground',
        color: M.ground.color,
        roughness: M.ground.roughness,
        metalness: M.ground.metalness,
    }));
}


/* ══════════════════════════════════════════════════════════════════════════
 *  § 7. ЗРИТЕЛЬСКИЕ МЕСТА
 * ══════════════════════════════════════════════════════════════════════════ */

/**
 * Материал для InstancedMesh зрительских мест.
 *
 * НЕ кэшируется, потому что:
 *   • для мест используем instanceColor (цвет каждого инстанса)
 *   • возможно понадобится несколько вариантов (VIP-сектор, гостевой)
 *   • лёгкий per-material шейдерный тюнинг
 *
 * @param {Object}  [options]
 * @param {number}  [options.roughness=0.75]
 * @param {number}  [options.metalness=0.05]
 * @returns {THREE.MeshStandardMaterial}
 */
export function createSeatMaterial(options = {}) {
    const {
        roughness = 0.75,
        metalness = 0.05,
    } = options;

    const material = new THREE.MeshStandardMaterial({
        name: 'seat',
        color: 0xffffff,        // белый — чтобы instanceColor корректно умножался
        roughness,
        metalness,
        /* Освещение с обеих сторон — места могут быть видны «изнутри». */
        side: THREE.FrontSide,
    });

    return material;
}


/* ══════════════════════════════════════════════════════════════════════════
 *  § 8. ОТДЕЛКА
 * ══════════════════════════════════════════════════════════════════════════ */

/**
 * Отделка колонн — тёмная, с лёгким металлическим блеском.
 * Используется для оснований колонн, поручней, декоративных вставок.
 * @returns {THREE.MeshStandardMaterial}
 */
export function getPillarTrim() {
    return cached('pillarTrim', () => new THREE.MeshStandardMaterial({
        name: 'pillarTrim',
        color: M.pillarTrim.color,
        roughness: M.pillarTrim.roughness,
        metalness: M.pillarTrim.metalness,
    }));
}


/* ══════════════════════════════════════════════════════════════════════════
 *  § 9. ПРОЖЕКТОРЫ (визуальные корпуса)
 * ══════════════════════════════════════════════════════════════════════════ */

/**
 * Корпус прожектора — тёмный матовый, чтобы не отвлекал.
 * @returns {THREE.MeshStandardMaterial}
 */
export function getFloodlightHousing() {
    return cached('floodlightHousing', () => new THREE.MeshStandardMaterial({
        name: 'floodlightHousing',
        color: 0x2a2e34,
        roughness: 0.55,
        metalness: 0.65,
    }));
}

/**
 * Лампы прожектора — эмиссивный материал.
 * @returns {THREE.MeshStandardMaterial}
 */
export function getFloodlightLens() {
    return cached('floodlightLens', () => new THREE.MeshStandardMaterial({
        name: 'floodlightLens',
        color: 0xfff4dc,
        emissive: 0xfff4dc,
        emissiveIntensity: 0.9,
        roughness: 0.15,
        metalness: 0.0,
        transparent: true,
        opacity: 0.95,
    }));
}


/* ══════════════════════════════════════════════════════════════════════════
 *  § 10. УПРАВЛЕНИЕ
 * ══════════════════════════════════════════════════════════════════════════ */

/**
 * Возвращает количество материалов в кэше.
 * Полезно для отладки и метрик памяти.
 * @returns {number}
 */
export function getCacheSize() {
    return materialCache.size;
}

/**
 * Возвращает список всех кэшированных ключей.
 * @returns {string[]}
 */
export function getCacheKeys() {
    return Array.from(materialCache.keys());
}

/**
 * Полностью очищает кэш, вызывая dispose() на каждом материале.
 * Вызывать при уничтожении сцены.
 */
export function disposeAll() {
    for (const material of materialCache.values()) {
        material.dispose();
    }
    materialCache.clear();
}