/**
 * src/components/stadium/StadiumValidation.js
 *
 * ══════════════════════════════════════════════════════════════════════════
 *  ВАЛИДАЦИЯ КОНФИГУРАЦИИ СТАДИОНА
 *
 *  ─── ЗАЧЕМ ЭТО НУЖНО ────────────────────────────────────────────────────
 *    Ошибка в конфиге (например, ярус пересекает поле) приведёт к тому,
 *    что Three.js сгенерирует 90 000 мест, потратит ~600 МБ VRAM, и только
 *    тогда вы увидите проблему. Валидация занимает <1 мс и ловит всё
 *    заранее — до генерации геометрии.
 *
 *  ─── УРОВНИ СЕРЬЁЗНОСТИ ─────────────────────────────────────────────────
 *    ERROR   — конфиг сломан, нельзя строить стадион
 *    WARNING — работает, но подозрительно (может выглядеть плохо)
 *    INFO    — просто метрики для отладки
 *
 *  ─── ПРОВЕРКИ ───────────────────────────────────────────────────────────
 *    1.  Поле влезает в первый ярус (базовый clearance)
 *    2.  Ярусы не пересекаются между собой
 *    3.  Фасад покрывает всю высоту трибун
 *    4.  Крыша выше верхнего яруса
 *    5.  Крыша накрывает фасад (внешний край ≥ фасада)
 *    6.  Внутренний край крыши над чашей
 *    7.  Ширина места ≤ глубины ряда (иначе сиденья пересекаются)
 *    8.  Высота ступени ≤ глубины ряда (иначе угол > 45°, нереально круто)
 *    9.  Радиальные сегменты достаточны для плавности овалов
 *    10. Оценка вместимости и вывод метрик
 * ══════════════════════════════════════════════════════════════════════════
 */

import { STADIUM_CONFIG, superEllipsePerimeter } from './StadiumConfig.js';


/* ══════════════════════════════════════════════════════════════════════════
 *  § 1. КОНСТАНТЫ
 * ══════════════════════════════════════════════════════════════════════════ */

/** Уровни серьёзности. */
export const SEVERITY = Object.freeze({
    ERROR:   'error',
    WARNING: 'warning',
    INFO:    'info',
});

/** Максимально допустимый уклон трибуны (угол от горизонтали). */
const MAX_INCLINE_RADIANS = Math.PI / 4;   // 45°

/** Минимальный зазор от поля до первого ряда (м). */
const MIN_PITCH_CLEARANCE = 5.0;

/** Желательный зазор от поля до первого ряда (м). */
const RECOMMENDED_PITCH_CLEARANCE = 15.0;

/** Минимальная ширина прохода (м). */
const MIN_AISLE_WIDTH = 1.1;

/** Минимальное количество радиальных сегментов для плавных овалов. */
const MIN_RADIAL_SEGMENTS = 64;


/* ══════════════════════════════════════════════════════════════════════════
 *  § 2. ВСПОМОГАТЕЛЬНЫЕ ФУНКЦИИ
 * ══════════════════════════════════════════════════════════════════════════ */

/**
 * Периметр контура (суперэллипс), численно.
 *
 * @param {number} a — полуось по X
 * @param {number} b — полуось по Z
 * @returns {number} периметр
 */
function ellipsePerimeter(a, b) {
    return superEllipsePerimeter(a, b, STADIUM_CONFIG.shape.power);
}

/**
 * Оценка количества мест в ряду яруса.
 * Учитывает только периметр — без вычетов под проходы.
 *
 * @param {number} rX — средний радиус по X
 * @param {number} rZ — средний радиус по Z
 * @param {number} seatWidth
 * @returns {number}
 */
function estimateSeatsPerRow(rX, rZ, seatWidth) {
    const perim = ellipsePerimeter(rX, rZ);
    return Math.floor(perim / seatWidth);
}


/* ══════════════════════════════════════════════════════════════════════════
 *  § 3. ГЛАВНАЯ ФУНКЦИЯ ВАЛИДАЦИИ
 * ══════════════════════════════════════════════════════════════════════════ */

/**
 * Проверяет всю конфигурацию стадиона.
 *
 * @returns {{
 *   valid:    boolean,
 *   errors:   Array<{check: string, message: string, value?: any}>,
 *   warnings: Array<{check: string, message: string, value?: any}>,
 *   info:     Array<{check: string, message: string, value?: any}>,
 *   metrics:  Object
 * }}
 */
export function validateStadium() {
    const errors   = [];
    const warnings = [];
    const info     = [];
    const metrics  = {};

    const cfg = STADIUM_CONFIG;

    /* ─── § 3.1. ПОЛЕ ВЛЕЗАЕТ В ПЕРВЫЙ ЯРУС ─────────────────────────── */
    validatePitchClearance(cfg, errors, warnings, info, metrics);

    /* ─── § 3.2. ЯРУСЫ НЕ ПЕРЕСЕКАЮТСЯ ──────────────────────────────── */
    validateTierProgression(cfg, errors, warnings, info, metrics);

    /* ─── § 3.3. ФАСАД ПОКРЫВАЕТ ЯРУСЫ ──────────────────────────────── */
    validateFacade(cfg, errors, warnings, info, metrics);

    /* ─── § 3.4. КРЫША ─────────────────────────────────────────────── */
    validateRoof(cfg, errors, warnings, info, metrics);

    /* ─── § 3.5. ГЕОМЕТРИЯ РЯДА ─────────────────────────────────────── */
    validateRowGeometry(cfg, errors, warnings, info, metrics);

    /* ─── § 3.6. ИНФРАСТРУКТУРА ────────────────────────────────────── */
    validateInfrastructure(cfg, errors, warnings, info, metrics);

    /* ─── § 3.7. ВМЕСТИМОСТЬ ───────────────────────────────────────── */
    validateCapacity(cfg, warnings, info, metrics);

    return {
        valid: errors.length === 0,
        errors,
        warnings,
        info,
        metrics,
    };
}


/* ══════════════════════════════════════════════════════════════════════════
 *  § 4. ОТДЕЛЬНЫЕ ПРОВЕРКИ
 * ══════════════════════════════════════════════════════════════════════════ */

/* ─── § 4.1. ПОЛЕ ВЛЕЗАЕТ ──────────────────────────────────────────── */

function validatePitchClearance(cfg, errors, warnings, info, metrics) {
    const firstTier = cfg.tiers[0];
    const pitchHalfX = cfg.pitch.length / 2;
    const pitchHalfZ = cfg.pitch.width / 2;

    /* Пересечение с полем. */
    if (firstTier.startRadiusX <= pitchHalfX) {
        errors.push({
            check: 'pitch.intersectionX',
            message:
                `Первый ярус (X=${firstTier.startRadiusX.toFixed(2)}) ` +
                `пересекает поле (X=${pitchHalfX.toFixed(2)}).`,
            value: { tierStart: firstTier.startRadiusX, pitchHalf: pitchHalfX },
        });
    }

    if (firstTier.startRadiusZ <= pitchHalfZ) {
        errors.push({
            check: 'pitch.intersectionZ',
            message:
                `Первый ярус (Z=${firstTier.startRadiusZ.toFixed(2)}) ` +
                `пересекает поле (Z=${pitchHalfZ.toFixed(2)}).`,
            value: { tierStart: firstTier.startRadiusZ, pitchHalf: pitchHalfZ },
        });
    }

    /* Зазоры. */
    const clearanceX = firstTier.startRadiusX - pitchHalfX;
    const clearanceZ = firstTier.startRadiusZ - pitchHalfZ;

    metrics.pitchClearanceX = clearanceX;
    metrics.pitchClearanceZ = clearanceZ;

    if (clearanceX < MIN_PITCH_CLEARANCE) {
        warnings.push({
            check: 'pitch.clearanceX',
            message:
                `Маленький зазор по X: ${clearanceX.toFixed(2)} м ` +
                `(рекомендуется >${MIN_PITCH_CLEARANCE} м).`,
            value: clearanceX,
        });
    }
    if (clearanceZ < MIN_PITCH_CLEARANCE) {
        warnings.push({
            check: 'pitch.clearanceZ',
            message:
                `Маленький зазор по Z: ${clearanceZ.toFixed(2)} м ` +
                `(рекомендуется >${MIN_PITCH_CLEARANCE} м).`,
            value: clearanceZ,
        });
    }

    info.push({
        check: 'pitch.clearance',
        message:
            `Зазор от поля до трибун: ` +
            `X=${clearanceX.toFixed(2)} м, Z=${clearanceZ.toFixed(2)} м.`,
        value: { x: clearanceX, z: clearanceZ },
    });
}


/* ─── § 4.2. ЯРУСЫ НЕ ПЕРЕСЕКАЮТСЯ ────────────────────────────────── */

function validateTierProgression(cfg, errors, warnings, info, metrics) {
    const tiers = cfg.tiers;

    for (let i = 0; i < tiers.length; i++) {
        const tier = tiers[i];

        /* Проверка: положительные размеры. */
        if (tier.rows <= 0) {
            errors.push({
                check: `tier.${tier.id}.rows`,
                message:
                    `Ярус «${tier.name}»: количество рядов должно быть > 0.`,
                value: tier.rows,
            });
        }

        if (tier.depth <= 0 || tier.height <= 0) {
            errors.push({
                check: `tier.${tier.id}.dimensions`,
                message:
                    `Ярус «${tier.name}»: глубина и высота должны быть > 0.`,
                value: { depth: tier.depth, height: tier.height },
            });
        }

        /* Проверка: следующий ярус не пересекается с текущим. */
        if (i < tiers.length - 1) {
            const next = tiers[i + 1];
            const curEndX = tier.startRadiusX + tier.depth;
            const curEndZ = tier.startRadiusZ + tier.depth;

            if (next.startRadiusX < curEndX - 0.01) {
                errors.push({
                    check: `tier.${next.id}.overlapX`,
                    message:
                        `Ярус «${next.name}» (X=${next.startRadiusX.toFixed(2)}) ` +
                        `пересекает конец яруса «${tier.name}» ` +
                        `(X=${curEndX.toFixed(2)}).`,
                    value: {
                        nextStart: next.startRadiusX,
                        currentEnd: curEndX,
                    },
                });
            }

            if (next.startRadiusZ < curEndZ - 0.01) {
                errors.push({
                    check: `tier.${next.id}.overlapZ`,
                    message:
                        `Ярус «${next.name}» (Z=${next.startRadiusZ.toFixed(2)}) ` +
                        `пересекает конец яруса «${tier.name}» ` +
                        `(Z=${curEndZ.toFixed(2)}).`,
                    value: {
                        nextStart: next.startRadiusZ,
                        currentEnd: curEndZ,
                    },
                });
            }

            /* Информация о разделительном поясе. */
            const gapX = next.startRadiusX - curEndX;
            const gapZ = next.startRadiusZ - curEndZ;

            if (gapX > 0 || gapZ > 0) {
                info.push({
                    check: `tier.${next.id}.gap`,
                    message:
                        `Разделительный пояс между «${tier.name}» и ` +
                        `«${next.name}»: X=${gapX.toFixed(2)} м, ` +
                        `Z=${gapZ.toFixed(2)} м.`,
                    value: { gapX, gapZ },
                });
            }
        }

        /* Угол наклона яруса — проверка физической реалистичности. */
        const inclineRad = Math.atan2(tier.height, tier.depth / tier.rows);
        /* Замечание: tier.height — общая высота, tier.depth — общая глубина. */
        const inclineFromStep = Math.atan2(
            cfg.row.height,
            cfg.row.depth
        );
        metrics[`tier.${tier.id}.incline`] = inclineFromStep;

        if (inclineFromStep > MAX_INCLINE_RADIANS) {
            warnings.push({
                check: `tier.${tier.id}.incline`,
                message:
                    `Ярус «${tier.name}» слишком крутой: ` +
                    `${(inclineFromStep * 180 / Math.PI).toFixed(1)}° ` +
                    `(макс. ${(MAX_INCLINE_RADIANS * 180 / Math.PI).toFixed(0)}°).`,
                value: inclineFromStep,
            });
        }
    }

    metrics.tierCount = tiers.length;
}


/* ─── § 4.3. ФАСАД ───────────────────────────────────────────────── */

function validateFacade(cfg, errors, warnings, info, metrics) {
    const lastTier = cfg.tiers[cfg.tiers.length - 1];
    const lastEndX = lastTier.startRadiusX + lastTier.depth;
    const lastEndZ = lastTier.startRadiusZ + lastTier.depth;
    const facade = cfg.facade;

    /* Фасад должен быть снаружи последнего яруса. */
    if (facade.radiusX <= lastEndX) {
        errors.push({
            check: 'facade.radiusX',
            message:
                `Фасад (X=${facade.radiusX.toFixed(2)}) не снаружи ` +
                `последнего яруса (X=${lastEndX.toFixed(2)}).`,
            value: { facade: facade.radiusX, tierEnd: lastEndX },
        });
    }
    if (facade.radiusZ <= lastEndZ) {
        errors.push({
            check: 'facade.radiusZ',
            message:
                `Фасад (Z=${facade.radiusZ.toFixed(2)}) не снаружи ` +
                `последнего яруса (Z=${lastEndZ.toFixed(2)}).`,
            value: { facade: facade.radiusZ, tierEnd: lastEndZ },
        });
    }

    /* Фасад должен быть выше трибун — иначе «дыра» сверху. */
    const standsHeight = cfg.arena.standsTopY;
    if (facade.height < standsHeight) {
        errors.push({
            check: 'facade.height',
            message:
                `Фасад (h=${facade.height.toFixed(2)}) ниже трибун ` +
                `(h=${standsHeight.toFixed(2)}) — видна зияющая щель.`,
            value: { facadeHeight: facade.height, standsHeight },
        });
    }

    /* Количество рёбер — минимум 24 для визуальной плотности. */
    if (facade.ribCount < 24) {
        warnings.push({
            check: 'facade.ribCount',
            message:
                `Мало рёбер фасада (${facade.ribCount}). ` +
                `Рекомендуется >24 для визуальной плотности.`,
            value: facade.ribCount,
        });
    }

    metrics.facadeRadiusX = facade.radiusX;
    metrics.facadeRadiusZ = facade.radiusZ;
    metrics.facadeHeight = facade.height;

    info.push({
        check: 'facade.bounds',
        message:
            `Фасад: ${facade.radiusX.toFixed(1)} × ${facade.radiusZ.toFixed(1)} м, ` +
            `высота ${facade.height.toFixed(1)} м, ${facade.ribCount} рёбер.`,
        value: { radiusX: facade.radiusX, radiusZ: facade.radiusZ },
    });
}


/* ─── § 4.4. КРЫША ───────────────────────────────────────────────── */

function validateRoof(cfg, errors, warnings, info, metrics) {
    const roof = cfg.roof;
    const facade = cfg.facade;
    const standsHeight = cfg.arena.standsTopY;

    /* Крыша должна быть выше трибун. */
    if (roof.baseHeight <= standsHeight) {
        errors.push({
            check: 'roof.baseHeight',
            message:
                `Крыша (h=${roof.baseHeight.toFixed(2)}) ниже верхнего яруса ` +
                `(h=${standsHeight.toFixed(2)}).`,
            value: { roofBase: roof.baseHeight, standsHeight },
        });
    }

    /* Внешний край крыши — не меньше фасада. */
    if (roof.outerRadiusX < facade.radiusX) {
        errors.push({
            check: 'roof.outerRadiusX',
            message:
                `Внешний край крыши (X=${roof.outerRadiusX.toFixed(2)}) ` +
                `меньше фасада (X=${facade.radiusX.toFixed(2)}).`,
            value: {
                roofOuter: roof.outerRadiusX,
                facade: facade.radiusX,
            },
        });
    }
    if (roof.outerRadiusZ < facade.radiusZ) {
        errors.push({
            check: 'roof.outerRadiusZ',
            message:
                `Внешний край крыши (Z=${roof.outerRadiusZ.toFixed(2)}) ` +
                `меньше фасада (Z=${facade.radiusZ.toFixed(2)}).`,
            value: {
                roofOuter: roof.outerRadiusZ,
                facade: facade.radiusZ,
            },
        });
    }

    /* Внутренний край крыши должен быть над чашей. */
    const lastTier = cfg.tiers[cfg.tiers.length - 1];
    const lastTierStartX = lastTier.startRadiusX;
    if (roof.innerRadiusX >= lastTierStartX) {
        warnings.push({
            check: 'roof.innerRadiusX',
            message:
                `Внутренний край крыши (X=${roof.innerRadiusX.toFixed(2)}) ` +
                `не выходит за начало верхнего яруса ` +
                `(X=${lastTierStartX.toFixed(2)}) — передний ряд под открытым небом.`,
            value: { inner: roof.innerRadiusX, tierStart: lastTierStartX },
        });
    }

    metrics.roofInnerRadiusX = roof.innerRadiusX;
    metrics.roofOuterRadiusX = roof.outerRadiusX;
    metrics.roofHeight = roof.baseHeight;

    info.push({
        check: 'roof.bounds',
        message:
            `Крыша: ${roof.outerRadiusX.toFixed(1)} × ` +
            `${roof.outerRadiusZ.toFixed(1)} м, ` +
            `на высоте ${roof.baseHeight.toFixed(1)} м, ` +
            `${roof.pillarCount} опорных колонн.`,
        value: { outerX: roof.outerRadiusX, outerZ: roof.outerRadiusZ },
    });
}


/* ─── § 4.5. ГЕОМЕТРИЯ РЯДА ───────────────────────────────────────── */

function validateRowGeometry(cfg, errors, warnings, info, metrics) {
    const { seatWidth, depth, height } = cfg.row;

    /* Ширина места не должна превышать глубину ряда. */
    if (seatWidth > depth) {
        errors.push({
            check: 'row.seatWidth',
            message:
                `Ширина места (${seatWidth}) больше глубины ряда ` +
                `(${depth}) — сиденья пересекутся.`,
            value: { seatWidth, depth },
        });
    }

    /* Ширина места 40–55 см — стандарт для стадионов. */
    if (seatWidth < 0.40) {
        warnings.push({
            check: 'row.seatWidth.tight',
            message:
                `Узкое место: ${seatWidth} м (стандарт 0.45–0.55 м).`,
            value: seatWidth,
        });
    }
    if (seatWidth > 0.60) {
        warnings.push({
            check: 'row.seatWidth.wide',
            message:
                `Широкое место: ${seatWidth} м (стандарт 0.45–0.55 м).`,
            value: seatWidth,
        });
    }

    /* Угол ступени — читаемость сидений. */
    const stepAngle = Math.atan2(height, depth);
    if (stepAngle > MAX_INCLINE_RADIANS) {
        warnings.push({
            check: 'row.stepAngle',
            message:
                `Очень крутой шаг ступени: ` +
                `${(stepAngle * 180 / Math.PI).toFixed(1)}°.`,
            value: stepAngle,
        });
    }

    metrics.rowStepAngle = stepAngle;
    metrics.rowStepAngleDeg = stepAngle * 180 / Math.PI;

    info.push({
        check: 'row.dimensions',
        message:
            `Ряд: глубина ${depth} м, высота ${height} м, ` +
            `шаг ступени ${(stepAngle * 180 / Math.PI).toFixed(1)}°, ` +
            `сиденье ${seatWidth} м.`,
        value: { depth, height, seatWidth },
    });
}


/* ─── § 4.6. ИНФРАСТРУКТУРА ───────────────────────────────────────── */

function validateInfrastructure(cfg, errors, warnings, info, metrics) {
    const inf = cfg.infrastructure;

    /* Проходов должно быть достаточно — минимум 8. */
    if (inf.aisleCount < 8) {
        warnings.push({
            check: 'infrastructure.aisleCount',
            message:
                `Мало проходов: ${inf.aisleCount} (рекомендуется ≥8).`,
            value: inf.aisleCount,
        });
    }

    /* Ширина прохода — минимум 1.1 м (пожарные нормы). */
    if (inf.aisleWidth < MIN_AISLE_WIDTH) {
        warnings.push({
            check: 'infrastructure.aisleWidth',
            message:
                `Узкий проход: ${inf.aisleWidth} м ` +
                `(рекомендуется ≥${MIN_AISLE_WIDTH} м).`,
            value: inf.aisleWidth,
        });
    }

    /* Входов-ворот — минимум 6. */
    if (inf.vomitoryCount < 6) {
        warnings.push({
            check: 'infrastructure.vomitoryCount',
            message:
                `Мало входов: ${inf.vomitoryCount} (рекомендуется ≥6).`,
            value: inf.vomitoryCount,
        });
    }

    /* Количество колонн должно быть кратно числу проходов. */
    if (inf.pillarCount % inf.aisleCount !== 0) {
        info.push({
            check: 'infrastructure.pillarAlignment',
            message:
                `Колонны (${inf.pillarCount}) не кратны проходам ` +
                `(${inf.aisleCount}) — колонны не встанут идеально между проходами.`,
            value: { pillars: inf.pillarCount, aisles: inf.aisleCount },
        });
    }

    metrics.aisleCount = inf.aisleCount;
    metrics.pillarCount = inf.pillarCount;

    info.push({
        check: 'infrastructure.summary',
        message:
            `Инфраструктура: ${inf.pillarCount} колонн, ` +
            `${inf.aisleCount} проходов, ` +
            `${inf.vomitoryCount} входов.`,
        value: inf,
    });
}


/* ─── § 4.7. ВМЕСТИМОСТЬ ──────────────────────────────────────────── */

function validateCapacity(cfg, warnings, info, metrics) {
    let total = 0;
    const breakdown = [];

    for (const tier of cfg.tiers) {
        const rMidX = tier.startRadiusX + tier.depth * 0.5;
        const rMidZ = tier.startRadiusZ + tier.depth * 0.5;

        const perRow = estimateSeatsPerRow(rMidX, rMidZ, cfg.row.seatWidth);
        const tierSeats = perRow * tier.rows;
        total += tierSeats;

        breakdown.push({
            id: tier.id,
            name: tier.name,
            seatsPerRow: perRow,
            rows: tier.rows,
            total: tierSeats,
        });

        info.push({
            check: `capacity.${tier.id}`,
            message:
                `Ярус «${tier.name}»: ` +
                `${perRow} мест × ${tier.rows} рядов = ` +
                `${tierSeats.toLocaleString()} мест.`,
            value: tierSeats,
        });
    }

    /* Меньше 30 000 — маловато для «большой арены». */
    if (total < 30000) {
        warnings.push({
            check: 'capacity.low',
            message:
                `Малая вместимость: ${total.toLocaleString()} мест.`,
            value: total,
        });
    }

    metrics.totalCapacity = total;
    metrics.capacityBreakdown = breakdown;

    info.push({
        check: 'capacity.total',
        message:
            `Общая вместимость (до вычета проходов): ` +
            `${total.toLocaleString()} мест.`,
        value: total,
    });
}


/* ══════════════════════════════════════════════════════════════════════════
 *  § 5. ЛОГИРОВАНИЕ
 * ══════════════════════════════════════════════════════════════════════════ */

/**
 * Выводит отчёт валидации в консоль с цветовой разметкой.
 *
 * @param {Object} report — результат validateStadium()
 */
export function logValidation(report) {
    if (!report) {
        console.warn('[Stadium] Нет отчёта для вывода.');
        return;
    }

    const { valid, errors, warnings, info, metrics } = report;

    /* ─── Заголовок ──────────────────────────────────────────────── */
    console.group(
        '%c🏟️ Stadium Validation',
        'color:#4ea3ff;font-size:14px;font-weight:bold;'
    );

    /* ─── Итог ───────────────────────────────────────────────────── */
    if (valid) {
        console.log(
            '%c✓ Конфигурация валидна',
            'color:#4caf50;font-weight:bold;font-size:13px;'
        );
    } else {
        console.log(
            `%c✗ Найдено ошибок: ${errors.length}`,
            'color:#f44336;font-weight:bold;font-size:13px;'
        );
    }

    /* ─── Ошибки ─────────────────────────────────────────────────── */
    if (errors.length) {
        console.group(
            `%c🚫 Ошибки (${errors.length})`,
            'color:#f44336;font-weight:bold;'
        );
        for (const e of errors) {
            console.error(`[${e.check}] ${e.message}`);
        }
        console.groupEnd();
    }

    /* ─── Предупреждения ────────────────────────────────────────── */
    if (warnings.length) {
        console.group(
            `%c⚠️ Предупреждения (${warnings.length})`,
            'color:#ff9800;font-weight:bold;'
        );
        for (const w of warnings) {
            console.warn(`[${w.check}] ${w.message}`);
        }
        console.groupEnd();
    }

    /* ─── Информация ─────────────────────────────────────────────── */
    if (info.length) {
        console.group(
            `%cℹ️ Метрики (${info.length})`,
            'color:#4ea3ff;font-weight:bold;'
        );
        for (const i of info) {
            console.log(`[${i.check}] ${i.message}`);
        }
        console.groupEnd();
    }

    /* ─── Сводные метрики ───────────────────────────────────────── */
    console.group(
        '%c📊 Сводка',
        'color:#9c27b0;font-weight:bold;'
    );
    console.table({
        'Ярусов':               metrics.tierCount,
        'Радиус фасада X':      metrics.facadeRadiusX,
        'Радиус фасада Z':      metrics.facadeRadiusZ,
        'Высота фасада':        metrics.facadeHeight,
        'Внешний радиус X':     metrics.roofOuterRadiusX,
        'Высота крыши':         metrics.roofHeight,
        'Зазор X (от поля)':    metrics.pitchClearanceX,
        'Зазор Z (от поля)':    metrics.pitchClearanceZ,
        'Угол ступени (°)':     metrics.rowStepAngleDeg,
        'Колонн':               metrics.pillarCount,
        'Проходов':             metrics.aisleCount,
        'Общая вместимость':    metrics.totalCapacity,
    });
    console.groupEnd();

    console.groupEnd();
}


/**
 * Удобная обёртка: валидирует и сразу логирует.
 * Возвращает отчёт.
 *
 * @returns {Object} report
 */
export function validateAndLog() {
    const report = validateStadium();
    logValidation(report);
    return report;
}


/**
 * Кидает исключение, если конфигурация невалидна.
 * Полезно на старте приложения — быстрый fail при неправильном конфиге.
 */
export function assertValidStadium() {
    const report = validateStadium();
    if (!report.valid) {
        const messages = report.errors.map(
            (e, i) => `${i + 1}. [${e.check}] ${e.message}`
        ).join('\n');
        throw new Error(
            `StadiumConfig невалиден:\n${messages}`
        );
    }
    return report;
}