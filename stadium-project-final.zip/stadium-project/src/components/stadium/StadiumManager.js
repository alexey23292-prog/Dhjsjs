/**
 * src/components/stadium/StadiumManager.js
 *
 * ══════════════════════════════════════════════════════════════════════════
 *  ГЛАВНЫЙ ОРКЕСТРАТОР СТАДИОНА
 *
 *  ─── ОТВЕТСТВЕННОСТЬ ─────────────────────────────────────────────────────
 *    1. Создание сцены, камеры, рендерера, контролов
 *    2. Валидация конфигурации ДО генерации геометрии
 *    3. Последовательный вызов всех модулей сборки
 *    4. Управление анимационным циклом (requestAnimationFrame)
 *    5. Публичный API для интеграции с игровыми системами
 *    6. Управление памятью и очистка ресурсов
 *
 *  ─── ЧТО НЕ ДЕЛАЕТ ───────────────────────────────────────────────────────
 *    • Не создаёт футбольное поле — это ответственность игры
 *    • Не управляет мячом, игроками, воротами — это игровая логика
 *    • Не рисует UI — это отдельный слой приложения
 *
 *  ─── ПОРЯДОК ИСПОЛЬЗОВАНИЯ ───────────────────────────────────────────────
 *
 *    const stadium = new StadiumManager({
 *      container: document.getElementById('app'),
 *      debug: false,
 *      timeOfDay: 0.0,
 *    });
 *
 *    await stadium.init();
 *    stadium.start();
 *
 *    // Позже:
 *    const anchor = stadium.getPitchAnchor();
 *    anchor.add(footballPitch);
 *
 *    // В конце:
 *    stadium.dispose();
 *
 *  ─── ИНТЕГРАЦИЯ С СУЩЕСТВУЮЩИМ ПРОЕКТОМ ──────────────────────────────────
 *    Если в проекте уже есть scene/renderer/camera, их можно передать
 *    через опции — StadiumManager не будет создавать новые:
 *
 *    const stadium = new StadiumManager({
 *      scene: existingScene,
 *      renderer: existingRenderer,
 *      camera: existingCamera,
 *    });
 * ══════════════════════════════════════════════════════════════════════════
 */

import * as THREE from 'three';
import { OrbitControls } from 'three/addons/controls/OrbitControls.js';
import { RoomEnvironment } from 'three/addons/environments/RoomEnvironment.js';

import { STADIUM_CONFIG } from './StadiumConfig.js';
import { disposeAll as disposeMaterials, getGround } from './StadiumMaterials.js';

import {
    validateAndLog,
} from './StadiumValidation.js';

import {
    createStadiumLighting,
    updateFloodlights,
    blendDayNight,
    disposeStadiumLighting,
} from './StadiumLighting.js';

import { buildStands, getStandsMetrics } from './modules/StandsModule.js';
import { buildRoof, getRoofMetrics } from './modules/RoofModule.js';
import { buildFacade, getFacadeMetrics } from './modules/FacadeModule.js';
import {
    buildInfrastructure,
    getInfrastructureMetrics,
} from './modules/InfrastructureModule.js';
import {
    createPitchAnchor,
    createPitchClearanceMarker,
    getPitchClearanceMetrics,
} from './modules/PitchClearance.js';
import { createStadiumPitch } from './modules/PitchModule.js';
import { createStadiumGoals } from './modules/GoalModule.js';


/* ══════════════════════════════════════════════════════════════════════════
 *  § 1. КОНСТАНТЫ
 * ══════════════════════════════════════════════════════════════════════════ */

/** Дефолтные опции. */
const DEFAULT_OPTIONS = Object.freeze({
    /* Контейнер для рендерера. */
    container: null,

    /* Опционально — если есть в проекте. */
    scene: null,
    renderer: null,
    camera: null,
    controls: null,

    /* Качество. */
    pixelRatio: Math.min(window.devicePixelRatio || 1, 2),
    antialias: true,
    shadows: true,

    /* Настройки камеры (если не передана). */
    cameraPosition: [180, 90, 180],
    cameraTarget:   [0, 5, 0],
    cameraFov:      45,
    cameraNear:     1.0,
    cameraFar:      1500,

    /* Режим отладки — логирует валидацию (+ маркер поля, см. showPitchMarker). */
    debug: false,

    /* Газон (pole2.txt) и беговая дорожка внутри стадиона. */
    pitch: true,
    track: true,
    fence: true,        // белое панельное ограждение вокруг газона
    adFence: true,      // серый рекламный забор по внешнему краю дорожки

    /* Ворота на линиях ворот (football_goal_viewer.html). */
    goals: true,
    goalNetPhysics: false,   // true — упругая сетка, считается после goal.launchBall()

    /* Полупрозрачный отладочный маркер поля. Выключен по умолчанию:
     * при наличии настоящего газона он только тонирует поле. */
    showPitchMarker: false,

    /* Время суток: 0 = день, 1 = ночь. */
    timeOfDay: 0.0,

    /* Обновлять ли контролы (если переданы снаружи — можно отключить). */
    autoUpdate: true,

    /* Автоматически добавлять всё в сцену. */
    autoAddToScene: true,
});


/* ══════════════════════════════════════════════════════════════════════════
 *  § 2. ГЛАВНЫЙ КЛАСС
 * ══════════════════════════════════════════════════════════════════════════ */

export class StadiumManager {

    /**
     * @param {Object} [options] — параметры инициализации
     */
    constructor(options = {}) {
        /* ─── Мерджим опции с дефолтами ─────────────────────────── */
        this.options = { ...DEFAULT_OPTIONS, ...options };

        /* ─── Ссылки на инфраструктуру рендера ─────────────────── */
        this.scene = null;
        this.renderer = null;
        this.camera = null;
        this.controls = null;

        /* ─── Ссылки на модули стадиона ─────────────────────────── */
        this.lighting = null;
        this.stands = null;
        this.roof = null;
        this.facade = null;
        this.infrastructure = null;
        this.pitchAnchor = null;
        this.pitchMarker = null;
        this.pitch = null;
        this.goals = null;
        this.ground = null;

        /* ─── Состояние ────────────────────────────────────────── */
        this.initialized = false;
        this.animating = false;
        this.animationFrameId = null;
        this.clock = null;
        this.elapsedTime = 0;

        /* ─── Метрики ──────────────────────────────────────────── */
        this.stats = {
            totalBuildTime: 0,
            totalVertices: 0,
            totalTriangles: 0,
            totalDrawCallsEstimate: 0,
            seats: 0,
            fps: 0,
        };

        /* ─── Внутренний FPS counter ───────────────────────────── */
        this._fpsAccum = 0;
        this._fpsFrames = 0;
        this._currentFps = 0;

        /* ─── Флаг: рендерер создан нами (нужно ли dispose) ─────── */
        this._ownsRenderer = false;
        this._ownsScene = false;
        this._ownsCamera = false;
        this._ownsControls = false;
    }


    /* ══════════════════════════════════════════════════════════════════
     *  § 3. ИНИЦИАЛИЗАЦИЯ
     * ══════════════════════════════════════════════════════════════════ */

    /**
     * Основной метод инициализации.
     *
     * @returns {Promise<StadiumManager>} this
     */
    async init() {
        if (this.initialized) {
            console.warn('[StadiumManager] Уже инициализирован.');
            return this;
        }

        const t0 = performance.now();

        /* ─── § 3.1. Валидация конфига ─────────────────────────── */
        const report = validateAndLog();
        if (!report.valid && this.options.debug) {
            console.warn(
                '[StadiumManager] Конфиг имеет ошибки, но продолжаем. ' +
                `Ошибок: ${report.errors.length}`
            );
        }

        /* ─── § 3.2. Рендер-инфраструктура ─────────────────────── */
        this._initRenderer();
        this._initScene();
        this._initCamera();
        this._initControls();

        /* ─── § 3.3. Окружение (IBL) ───────────────────────────── */
        this._initEnvironment();

        /* ─── § 3.4. Свет ──────────────────────────────────────── */
        this._initLighting();

        /* ─── § 3.5. Земля ─────────────────────────────────────── */
        this._initGround();

        /* ─── § 3.6. Anchor для поля ───────────────────────────── */
        this.pitchAnchor = createPitchAnchor();
        if (this.options.autoAddToScene) {
            this.scene.add(this.pitchAnchor);
        }

        /* ─── § 3.7. Сборка стадиона ───────────────────────────── */
        this._buildStands();
        this._buildInfrastructure();
        this._buildRoof();
        this._buildFacade();

        /* ─── § 3.7b. Газон и беговая дорожка ──────────────────── */
        if (this.options.pitch) {
            this.pitch = createStadiumPitch({
                track: this.options.track,
                fence: this.options.fence,
                adFence: this.options.adFence,
            });
            if (this.options.autoAddToScene) {
                this.scene.add(this.pitch.group);
            }
        }

        /* ─── § 3.7c. Ворота ───────────────────────────────────── */
        if (this.options.goals) {
            this.goals = createStadiumGoals({
                pitchLength: STADIUM_CONFIG.pitch.length,
                netPhysics: this.options.goalNetPhysics,
            });
            if (this.options.autoAddToScene) {
                this.scene.add(this.goals.group);
            }
        }

        /* ─── § 3.8. Отладочный маркер поля ────────────────────── */
        if (this.options.debug && this.options.showPitchMarker) {
            this.pitchMarker = createPitchClearanceMarker();
            if (this.options.autoAddToScene) {
                this.scene.add(this.pitchMarker);
            }
        }

        /* ─── § 3.9. Режим дня/ночи ───────────────────────────── */
        this.setTimeOfDay(this.options.timeOfDay);

        /* ─── § 3.10. Финальные метрики ────────────────────────── */
        this._collectStats();

        const t1 = performance.now();
        this.stats.totalBuildTime = t1 - t0;

        this.clock = new THREE.Clock(true);
        this.initialized = true;

        if (this.options.debug) {
            console.log(
                `%c[StadiumManager] Инициализация завершена за ${this.stats.totalBuildTime.toFixed(0)} мс`,
                'color:#4caf50;font-weight:bold;'
            );
            this._logStats();
        }

        return this;
    }


    /* ══════════════════════════════════════════════════════════════════
     *  § 4. ИНИЦИАЛИЗАЦИЯ ПОДСИСТЕМ
     * ══════════════════════════════════════════════════════════════════ */

    /**
     * Создаёт или использует внешний WebGLRenderer.
     */
    _initRenderer() {
        if (this.options.renderer) {
            /* Используем существующий рендерер проекта. */
            this.renderer = this.options.renderer;
            this._ownsRenderer = false;
            return;
        }

        /* Создаём собственный. */
        this.renderer = new THREE.WebGLRenderer({
            antialias: this.options.antialias,
            powerPreference: 'high-performance',
            stencil: false,
            depth: true,
        });

        this.renderer.setPixelRatio(this.options.pixelRatio);
        this.renderer.setSize(window.innerWidth, window.innerHeight);
        this.renderer.setClearColor(STADIUM_CONFIG.scene.clearColor, 1.0);

        this.renderer.shadowMap.enabled = this.options.shadows;
        this.renderer.shadowMap.type = THREE.PCFSoftShadowMap;

        this.renderer.toneMapping = THREE.ACESFilmicToneMapping;
        this.renderer.toneMappingExposure = 1.02;
        this.renderer.outputColorSpace = THREE.SRGBColorSpace;

        /* Добавляем canvas в контейнер. */
        const container = this.options.container || document.body;
        container.appendChild(this.renderer.domElement);

        this._ownsRenderer = true;
    }


    /**
     * Создаёт или использует внешнюю сцену.
     */
    _initScene() {
        if (this.options.scene) {
            this.scene = this.options.scene;
            this._ownsScene = false;
            return;
        }

        this.scene = new THREE.Scene();
        this.scene.background = new THREE.Color(STADIUM_CONFIG.scene.clearColor);
        this.scene.fog = new THREE.FogExp2(
            STADIUM_CONFIG.scene.fogColor,
            STADIUM_CONFIG.scene.fogDensity
        );

        this._ownsScene = true;
    }


    /**
     * Создаёт или использует внешнюю камеру.
     */
    _initCamera() {
        if (this.options.camera) {
            this.camera = this.options.camera;
            this._ownsCamera = false;
            return;
        }

        const aspect = window.innerWidth / window.innerHeight;
        this.camera = new THREE.PerspectiveCamera(
            this.options.cameraFov,
            aspect,
            this.options.cameraNear,
            this.options.cameraFar
        );

        this.camera.position.set(
            this.options.cameraPosition[0],
            this.options.cameraPosition[1],
            this.options.cameraPosition[2]
        );

        this.camera.lookAt(
            this.options.cameraTarget[0],
            this.options.cameraTarget[1],
            this.options.cameraTarget[2]
        );

        this._ownsCamera = true;
    }


    /**
     * Создаёт или использует внешние контролы.
     */
    _initControls() {
        if (this.options.controls) {
            this.controls = this.options.controls;
            this._ownsControls = false;
            return;
        }

        this.controls = new OrbitControls(
            this.camera,
            this.renderer.domElement
        );

        this.controls.target.set(
            this.options.cameraTarget[0],
            this.options.cameraTarget[1],
            this.options.cameraTarget[2]
        );

        this.controls.enableDamping = true;
        this.controls.dampingFactor = 0.07;
        this.controls.rotateSpeed = 0.5;
        this.controls.zoomSpeed = 1.0;
        this.controls.panSpeed = 0.8;
        this.controls.minDistance = 30.0;
        this.controls.maxDistance = 500.0;
        this.controls.maxPolarAngle = Math.PI * 0.5 - 0.02;
        this.controls.minPolarAngle = 0.08;
        this.controls.screenSpacePanning = false;

        this.controls.update();
        this._ownsControls = true;
    }


    /**
     * Настраивает IBL через RoomEnvironment.
     */
    _initEnvironment() {
        const pmrem = new THREE.PMREMGenerator(this.renderer);
        const env = pmrem.fromScene(new RoomEnvironment(), 0.04).texture;
        this.scene.environment = env;
        pmrem.dispose();
    }


    /**
     * Создаёт освещение через StadiumLighting.
     */
    _initLighting() {
        this.lighting = createStadiumLighting(this.scene);
    }


    /**
     * Создаёт землю под стадионом.
     */
    _initGround() {
        const size = STADIUM_CONFIG.scene.groundSize;
        const geo = new THREE.PlaneGeometry(size, size, 1, 1);
        const mat = getGround();

        this.ground = new THREE.Mesh(geo, mat);
        this.ground.rotation.x = -Math.PI * 0.5;
        this.ground.position.y = -0.02;
        this.ground.receiveShadow = true;
        this.ground.name = 'stadium_ground';

        if (this.options.autoAddToScene) {
            this.scene.add(this.ground);
        }
    }


    /* ══════════════════════════════════════════════════════════════════
     *  § 5. СБОРКА МОДУЛЕЙ
     * ══════════════════════════════════════════════════════════════════ */

    /**
     * Строит трибуны со всеми местами.
     */
    _buildStands() {
        this.stands = buildStands();
        if (this.options.autoAddToScene) {
            this.scene.add(this.stands.group);
        }
    }


    /**
     * Строит инфраструктуру (колонны, лестницы, ворота).
     */
    _buildInfrastructure() {
        this.infrastructure = buildInfrastructure();
        if (this.options.autoAddToScene) {
            this.scene.add(this.infrastructure.group);
        }
    }


    /**
     * Строит крышу.
     */
    _buildRoof() {
        this.roof = buildRoof();
        if (this.options.autoAddToScene) {
            this.scene.add(this.roof.group);
        }
    }


    /**
     * Строит фасад.
     */
    _buildFacade() {
        this.facade = buildFacade();
        if (this.options.autoAddToScene) {
            this.scene.add(this.facade.group);
        }
    }


    /* ══════════════════════════════════════════════════════════════════
     *  § 6. МЕТРИКИ
     * ══════════════════════════════════════════════════════════════════ */

    /**
     * Собирает метрики со всех модулей в один объект.
     */
    _collectStats() {
        let verts = 0;
        let tris = 0;
        let drawCalls = 0;

        /* ─── Трибуны ───────────────────────────────────────────── */
        if (this.stands) {
            const m = getStandsMetrics(this.stands);
            verts += m.totalVertices || 0;
            tris += m.totalTriangles || 0;
            drawCalls += m.drawCalls || 0;
            this.stats.seats = m.totalSeats || 0;
        }

        /* ─── Крыша ─────────────────────────────────────────────── */
        if (this.roof) {
            const m = getRoofMetrics(this.roof);
            verts += m.totalVertices || 0;
            tris += m.totalTriangles || 0;
            drawCalls += 50;   // приблизительно активных
        }

        /* ─── Фасад ─────────────────────────────────────────────── */
        if (this.facade) {
            const m = getFacadeMetrics(this.facade);
            verts += m.totalVertices || 0;
            tris += m.totalTriangles || 0;
            drawCalls += m.estimatedDrawCalls || 0;
        }

        /* ─── Инфраструктура ────────────────────────────────────── */
        if (this.infrastructure) {
            const m = getInfrastructureMetrics(this.infrastructure);
            verts += m.totalVertices || 0;
            tris += m.totalTriangles || 0;
            drawCalls += m.estimatedDrawCalls || 0;
        }

        this.stats.totalVertices = verts;
        this.stats.totalTriangles = tris;
        this.stats.totalDrawCallsEstimate = drawCalls;
    }


    /**
     * Выводит метрики в консоль.
     */
    _logStats() {
        console.group(
            '%c🏟️ Стадион построен',
            'color:#4ea3ff;font-size:14px;font-weight:bold;'
        );

        console.log(
            `%cВремя сборки: ${this.stats.totalBuildTime.toFixed(0)} мс`,
            'color:#4caf50;font-weight:bold;'
        );

        console.table({
            'Вершин':            this.stats.totalVertices.toLocaleString(),
            'Треугольников':     this.stats.totalTriangles.toLocaleString(),
            'Draw calls (est.)': this.stats.totalDrawCallsEstimate,
            'Зрительских мест':  this.stats.seats.toLocaleString(),
        });

        /* ─── По модулям ─────────────────────────────────────────── */
        if (this.stands) {
            const m = getStandsMetrics(this.stands);
            console.log(
                `%c  Трибуны: ${m.totalSeats.toLocaleString()} мест, ${m.drawCalls} draw calls`,
                'color:#9c27b0;'
            );
        }

        if (this.roof) {
            const m = getRoofMetrics(this.roof);
            console.log(
                `%c  Крыша: ${m.pillarCount} колонн, ${m.trussCount} ферм`,
                'color:#9c27b0;'
            );
        }

        if (this.facade) {
            const m = getFacadeMetrics(this.facade);
            console.log(
                `%c  Фасад: ${m.ribCount} рёбер, ${m.beltCount} поясов`,
                'color:#9c27b0;'
            );
        }

        if (this.infrastructure) {
            const m = getInfrastructureMetrics(this.infrastructure);
            console.log(
                `%c  Инфраструктура: ${m.pillars} колонн, ${m.stairSteps} ступеней, ${m.vomitoria} ворот`,
                'color:#9c27b0;'
            );
        }

        /* ─── Метрики поля ───────────────────────────────────────── */
        const pitchMetrics = getPitchClearanceMetrics();
        console.log(
            `%c  Поле: ${pitchMetrics.pitchLength} × ${pitchMetrics.pitchWidth} м, ` +
            `зазор X=${pitchMetrics.clearanceInsetX.toFixed(1)} м, ` +
            `Z=${pitchMetrics.clearanceInsetZ.toFixed(1)} м`,
            'color:#4ea3ff;'
        );

        console.groupEnd();
    }


    /**
     * Возвращает полный объект метрик стадиона.
     *
     * @returns {Object}
     */
    getStats() {
        return {
            ...this.stats,
            /* Детальные разбивки. */
            breakdown: {
                stands: this.stands ? getStandsMetrics(this.stands) : null,
                roof: this.roof ? getRoofMetrics(this.roof) : null,
                facade: this.facade ? getFacadeMetrics(this.facade) : null,
                infrastructure: this.infrastructure
                    ? getInfrastructureMetrics(this.infrastructure)
                    : null,
                pitch: getPitchClearanceMetrics(),
            },
        };
    }


    /* ══════════════════════════════════════════════════════════════════
     *  § 7. ПУБЛИЧНЫЙ API — ИНТЕГРАЦИЯ С ИГРОВЫМИ СИСТЕМАМИ
     * ══════════════════════════════════════════════════════════════════ */

    /**
     * Возвращает anchor-маркер для размещения поля.
     *
     * ─── ИСПОЛЬЗОВАНИЕ ─────────────────────────────────────────────────
     *    const anchor = stadium.getPitchAnchor();
     *    anchor.add(footballPitch);
     *
     * Маркер находится в центре арены (0, 0, 0) с метаданными
     * в userData (границы поля, полуразмеры).
     *
     * @returns {THREE.Group}
     */
    getPitchAnchor() {
        return this.pitchAnchor;
    }

    /**
     * Газон + беговая дорожка (см. modules/PitchModule.js):
     * getSurfaceAt(x, z), isOnTrack(x, z), getLanePoint(lane, s), ...
     * @returns {Object|null}
     */
    getPitch() {
        return this.pitch;
    }

    /**
     * Ворота: { left, right, update(dt) }; у каждых — group, sim,
     * launchBall(x,y,z,vx,vy,vz) в локальных координатах ворот.
     * @returns {Object|null}
     */
    getGoals() {
        return this.goals;
    }


    /**
     * Возвращает полные границы зарезервированной зоны под поле.
     *
     * @returns {Object}
     */
    getPitchBounds() {
        return getPitchClearanceMetrics();
    }


    /**
     * Возвращает ссылку на сцену.
     * @returns {THREE.Scene}
     */
    getScene() {
        return this.scene;
    }


    /**
     * Возвращает ссылку на рендерер.
     * @returns {THREE.WebGLRenderer}
     */
    getRenderer() {
        return this.renderer;
    }


    /**
     * Возвращает ссылку на камеру.
     * @returns {THREE.PerspectiveCamera}
     */
    getCamera() {
        return this.camera;
    }


    /**
     * Возвращает ссылку на контролы.
     * @returns {OrbitControls}
     */
    getControls() {
        return this.controls;
    }


    /**
     * Возвращает ссылку на модуль трибун.
     * @returns {Object}
     */
    getStands() {
        return this.stands;
    }


    /**
     * Возвращает ссылку на модуль крыши.
     * @returns {Object}
     */
    getRoof() {
        return this.roof;
    }


    /**
     * Возвращает ссылку на модуль фасада.
     * @returns {Object}
     */
    getFacade() {
        return this.facade;
    }


    /**
     * Возвращает ссылку на модуль инфраструктуры.
     * @returns {Object}
     */
    getInfrastructure() {
        return this.infrastructure;
    }


    /**
     * Возвращает ссылку на модуль освещения.
     * @returns {Object}
     */
    getLighting() {
        return this.lighting;
    }


    /* ══════════════════════════════════════════════════════════════════
     *  § 8. УПРАВЛЕНИЕ ВРЕМЕНЕМ СУТОК
     * ══════════════════════════════════════════════════════════════════ */

    /**
     * Устанавливает время суток.
     *
     * @param {number} t — 0 = день, 1 = ночь
     */
    setTimeOfDay(t) {
        if (!this.lighting) return;

        const k = Math.max(0, Math.min(1, t));
        blendDayNight(this.lighting, k);

        /* Обновляем фон неба, если это наша сцена. */
        if (this._ownsScene && this.scene.background) {
            const dayColor = new THREE.Color(0xc8d8e8);
            const nightColor = new THREE.Color(0x0a0e12);

            const color = new THREE.Color().copy(dayColor).lerp(nightColor, k);
            this.scene.background.copy(color);
        }
    }


    /* ══════════════════════════════════════════════════════════════════
     *  § 9. АНИМАЦИОННЫЙ ЦИКЛ
     * ══════════════════════════════════════════════════════════════════ */

    /**
     * Запускает рендер-цикл.
     */
    start() {
        if (this.animating) {
            console.warn('[StadiumManager] Уже анимируется.');
            return;
        }

        this.animating = true;
        this._animateLoop();
    }


    /**
     * Останавливает рендер-цикл.
     */
    stop() {
        this.animating = false;
        if (this.animationFrameId !== null) {
            cancelAnimationFrame(this.animationFrameId);
            this.animationFrameId = null;
        }
    }


    /**
     * Внутренний цикл.
     */
    _animateLoop() {
        if (!this.animating) return;

        this.animationFrameId = requestAnimationFrame(
            () => this._animateLoop()
        );

        const delta = Math.min(this.clock.getDelta(), 0.05);
        this.elapsedTime += delta;

        /* ─── Обновление контролов ──────────────────────────────── */
        if (this.options.autoUpdate && this.controls) {
            this.controls.update();
        }

        /* ─── Сетка ворот (только если включена физика) ────────── */
        if (this.goals) {
            this.goals.update(delta);
        }

        /* ─── Мерцание прожекторов ──────────────────────────────── */
        if (this.lighting) {
            updateFloodlights(this.lighting, this.elapsedTime);
        }

        /* ─── FPS counter ───────────────────────────────────────── */
        this._fpsAccum += delta;
        this._fpsFrames++;
        if (this._fpsAccum >= 0.5) {
            this._currentFps = this._fpsFrames / this._fpsAccum;
            this.stats.fps = Math.round(this._currentFps);
            this._fpsAccum = 0;
            this._fpsFrames = 0;
        }

        /* ─── Рендер ────────────────────────────────────────────── */
        this.renderer.render(this.scene, this.camera);
    }


    /* ══════════════════════════════════════════════════════════════════
     *  § 10. ОБРАБОТКА РЕСАЙЗА
     * ══════════════════════════════════════════════════════════════════ */

    /**
     * Обновляет размеры рендерера и камеры.
     * Вызывать из window.onresize или ResizeObserver.
     */
    onResize() {
        const w = window.innerWidth;
        const h = window.innerHeight;

        if (this.camera && this._ownsCamera) {
            this.camera.aspect = w / h;
            this.camera.updateProjectionMatrix();
        }

        if (this.renderer && this._ownsRenderer) {
            this.renderer.setSize(w, h);
            this.renderer.setPixelRatio(this.options.pixelRatio);
        }
    }


    /* ══════════════════════════════════════════════════════════════════
     *  § 11. ОЧИСТКА РЕСУРСОВ
     * ══════════════════════════════════════════════════════════════════ */

    /**
     * Полная очистка ресурсов.
     * Вызывать при удалении сцены или перезагрузке стадиона.
     */
    dispose() {
        /* ─── Останавливаем цикл ──────────────────────────────── */
        this.stop();

        /* ─── Удаляем модули из сцены ─────────────────────────── */
        const toRemove = [
            this.stands && this.stands.group,
            this.infrastructure && this.infrastructure.group,
            this.roof && this.roof.group,
            this.facade && this.facade.group,
            this.pitchAnchor,
            this.pitchMarker,
            this.ground,
        ];

        for (const obj of toRemove) {
            if (!obj) continue;
            if (obj.parent) obj.parent.remove(obj);
            this._disposeObject(obj);
        }

        /* ─── Ворота ───────────────────────────────────────────── */
        if (this.goals) {
            this.goals.dispose();
            this.goals = null;
        }

        /* ─── Газон и дорожка (геометрии, материалы, текстуры) ──── */
        if (this.pitch) {
            this.pitch.dispose();
            this.pitch = null;
        }

        /* ─── Освещение ────────────────────────────────────────── */
        if (this.lighting) {
            disposeStadiumLighting(this.scene, this.lighting);
            this.lighting = null;
        }

        /* ─── Материалы ────────────────────────────────────────── */
        disposeMaterials();

        /* ─── Контролы (если наши) ─────────────────────────────── */
        if (this.controls && this._ownsControls) {
            this.controls.dispose();
            this.controls = null;
        }

        /* ─── Рендерер (если наш) ──────────────────────────────── */
        if (this.renderer && this._ownsRenderer) {
            const canvas = this.renderer.domElement;
            if (canvas && canvas.parentNode) {
                canvas.parentNode.removeChild(canvas);
            }
            this.renderer.dispose();
            this.renderer = null;
        }

        /* ─── Сцена (если наша) ────────────────────────────────── */
        if (this.scene && this._ownsScene) {
            this.scene.clear();
            this.scene = null;
        }

        /* ─── Обнуляем ссылки ──────────────────────────────────── */
        this.stands = null;
        this.infrastructure = null;
        this.roof = null;
        this.facade = null;
        this.pitchAnchor = null;
        this.pitchMarker = null;
        this.pitch = null;
        this.goals = null;
        this.ground = null;
        this.camera = null;
        this.clock = null;

        this.initialized = false;
        this.animating = false;
        this.animationFrameId = null;
        this.elapsedTime = 0;
    }


    /**
     * Рекурсивно освобождает геометрию и материалы объекта.
     *
     * @param {THREE.Object3D} obj
     */
    _disposeObject(obj) {
        if (!obj) return;

        obj.traverse(child => {
            if (child.geometry) {
                child.geometry.dispose();
            }
            if (child.material) {
                if (Array.isArray(child.material)) {
                    child.material.forEach(m => {
                        if (m && m.dispose) m.dispose();
                    });
                } else if (child.material.dispose) {
                    child.material.dispose();
                }
            }
        });
    }
}


/* ══════════════════════════════════════════════════════════════════════════
 *  § 12. ХЕЛПЕРЫ
 * ══════════════════════════════════════════════════════════════════════════ */

/**
 * Быстрое создание стадиона в контейнере.
 * Удобно для демонстраций и тестов.
 *
 * @param {HTMLElement|string} container — element или CSS-селектор
 * @param {Object} [options]
 * @returns {Promise<StadiumManager>}
 */
export async function createStadiumIn(container, options = {}) {
    const el = typeof container === 'string'
        ? document.querySelector(container)
        : container;

    if (!el) {
        throw new Error(`[StadiumManager] Контейнер не найден: ${container}`);
    }

    const stadium = new StadiumManager({ container: el, ...options });
    await stadium.init();
    stadium.start();

    /* Автоматический ресайз. */
    const onResize = () => stadium.onResize();
    window.addEventListener('resize', onResize, { passive: true });

    /* Возвращаем оригинальный метод с дополнительной очисткой слушателя. */
    const originalDispose = stadium.dispose.bind(stadium);
    stadium.dispose = function () {
        window.removeEventListener('resize', onResize);
        originalDispose();
    };

    return stadium;
}