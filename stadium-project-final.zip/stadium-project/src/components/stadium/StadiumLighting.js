/**
 * src/components/stadium/StadiumLighting.js
 *
 * ══════════════════════════════════════════════════════════════════════════
 *  ОСВЕЩЕНИЕ СТАДИОНА
 *
 *  ─── АРХИТЕКТУРА СВЕТА ───────────────────────────────────────────────────
 *    1. AmbientLight        — базовый общий свет (не даёт чёрных провалов)
 *    2. HemisphereLight     — мягкое разделение: небо сверху, отражение снизу
 *    3. DirectionalLight    — «солнце», единственный с тенями (для произв.)
 *    4. DirectionalLight fill — контровой свет с противоположной стороны
 *    5. SpotLight × 24      — прожекторы на крыше, имитация стадионных
 *
 *  ─── ПОЧЕМУ ОДИН ИСТОЧНИК С ТЕНЯМИ ──────────────────────────────────────
 *    24 SpotLight с castShadow = 24 shadow map = 24 × 2048² = ~100 МБ VRAM.
 *    GPU захлебнётся. Один DirectionalLight с большой shadow camera
 *    отлично справляется с задачей дать читаемые тени — этого достаточно.
 *
 *  ─── УПРАВЛЕНИЕ ─────────────────────────────────────────────────────────
 *    createStadiumLighting(scene) → возвращает объект с ссылками
 *    updateFloodlights(lighting, time) — анимация мерцания
 *    setDayMode(lighting) / setNightMode(lighting) — переключение режимов
 *    disposeStadiumLighting(lighting) — очистка
 * ══════════════════════════════════════════════════════════════════════════
 */

import * as THREE from 'three';
import {
    STADIUM_CONFIG,
    superEllipsePoint,
    superEllipseEvenAngles,
    getFloodlightContour,
} from './StadiumConfig.js';
import {
    getFloodlightHousing,
    getFloodlightLens,
} from './StadiumMaterials.js';


/* ══════════════════════════════════════════════════════════════════════════
 *  § 1. КОНСТАНТЫ
 * ══════════════════════════════════════════════════════════════════════════ */

const L = STADIUM_CONFIG.lighting;

/** Размер shadow map для «солнца» — 2048² достаточно для всей арены. */
const SUN_SHADOW_MAP_SIZE = 2048;

/** Начало / конец frustum теневой камеры (м). */
const SUN_SHADOW_NEAR = 20.0;
const SUN_SHADOW_FAR  = 500.0;

/** Полуразмер ортогональной камеры тени — покрывает арену с запасом. */
const SUN_SHADOW_EXTENT = 200.0;

/** Смещение теней — борьба с z-fighting и «acne». */
const SUN_SHADOW_BIAS      = -0.0005;
const SUN_SHADOW_NORMAL_BIAS = 0.05;

/** Параметры прожекторов (spot). */
const FLOODLIGHT_ANGLE = Math.PI / 5.0;   // ~36° конус
const FLOODLIGHT_PENUMBRA = 0.55;         // мягкость края (0 = резко, 1 = очень мягко)
const FLOODLIGHT_DECAY = 1.5;             // физическое затухание

/** Размеры визуального корпуса прожектора (м). */
const HOUSING_WIDTH  = 1.4;
const HOUSING_HEIGHT = 0.6;
const HOUSING_DEPTH  = 0.9;

/** Размер линзы внутри корпуса. */
const LENS_SIZE = 1.2;


/* ══════════════════════════════════════════════════════════════════════════
 *  § 2. СОЗДАНИЕ ОСВЕЩЕНИЯ
 * ══════════════════════════════════════════════════════════════════════════ */

/**
 * Создаёт полный комплект источников света и добавляет их в сцену.
 *
 * @param {THREE.Scene} scene — корневая сцена
 * @returns {Object} объект с ссылками на все источники + группы
 */
export function createStadiumLighting(scene) {
    const lighting = {
        ambient:    null,
        hemisphere: null,
        sun:        null,
        fill:       null,
        floodlights: [],       // массив { light, housing, lens, angle, ... }
        floodlightGroup: null, // Group со всеми визуальными корпусами
        group: new THREE.Group(),
    };

    lighting.group.name = 'stadium_lighting';

    /* ─── § 2.1. AmbientLight ──────────────────────────────────────── */
    /*
     * Минимальный базовый свет. Он не создаёт теней и объёма —
     * только гарантирует, что ничто не проваливается в абсолютную черноту.
     */
    lighting.ambient = new THREE.AmbientLight(
        L.ambientColor,
        L.ambientIntensity
    );
    lighting.ambient.name = 'stadium_ambient';
    lighting.group.add(lighting.ambient);

    /* ─── § 2.2. HemisphereLight ───────────────────────────────────── */
    /*
     * Симулирует отражённый свет: сверху — холодный небесный,
     * снизу — тёплый отражённый от земли. Даёт мягкий объём без
     * дорогих вычислений.
     */
    lighting.hemisphere = new THREE.HemisphereLight(
        L.hemisphereSky,
        L.hemisphereGround,
        L.hemisphereIntensity
    );
    lighting.hemisphere.name = 'stadium_hemisphere';
    lighting.hemisphere.position.set(0, 200, 0);
    lighting.group.add(lighting.hemisphere);

    /* ─── § 2.3. Sun (DirectionalLight с тенями) ───────────────────── */
    /*
     * Единственный источник с тенями. Ортогональная shadow camera
     * размером 400×400 м покрывает всю арену (300 м в диаметре).
     */
    const sun = new THREE.DirectionalLight(0xfff2e0, L.sunIntensity);
    sun.name = 'stadium_sun';
    sun.position.set(
        L.sunPosition[0],
        L.sunPosition[1],
        L.sunPosition[2]
    );

    sun.castShadow = true;
    sun.shadow.mapSize.set(SUN_SHADOW_MAP_SIZE, SUN_SHADOW_MAP_SIZE);
    sun.shadow.camera.near = SUN_SHADOW_NEAR;
    sun.shadow.camera.far  = SUN_SHADOW_FAR;
    sun.shadow.camera.left   = -SUN_SHADOW_EXTENT;
    sun.shadow.camera.right  =  SUN_SHADOW_EXTENT;
    sun.shadow.camera.top    =  SUN_SHADOW_EXTENT;
    sun.shadow.camera.bottom = -SUN_SHADOW_EXTENT;
    sun.shadow.bias = SUN_SHADOW_BIAS;
    sun.shadow.normalBias = SUN_SHADOW_NORMAL_BIAS;

    /*
     * Sun должен смотреть в центр арены. Ставим target в (0,0,0),
     * добавляем target в группу, чтобы он двигался вместе с солнцем.
     */
    sun.target.position.set(0, 0, 0);
    lighting.group.add(sun);
    lighting.group.add(sun.target);
    lighting.sun = sun;

    /* ─── § 2.4. Fill (контровой свет) ─────────────────────────────── */
    /*
     * Второй DirectionalLight без теней с противоположной стороны.
     * Заполняет тени, которые создаёт sun, — иначе они кажутся
     * «выжженными в чёрное».
     */
    const fill = new THREE.DirectionalLight(0x9fc0e8, 0.35);
    fill.name = 'stadium_fill';
    fill.position.set(-80, 80, -60);
    lighting.group.add(fill);
    lighting.fill = fill;

    /* ─── § 2.5. Прожекторы на крыше ───────────────────────────────── */
    /*
     * 24 SpotLight по кольцу на высоте крыши. Светят вниз на поле.
     * Без теней — их тени не нужны, а производительность критична.
     */
    const floodlightGroup = new THREE.Group();
    floodlightGroup.name = 'stadium_floodlights';

    /* Материалы для визуального корпуса. */
    const housingMat = getFloodlightHousing();
    const lensMat    = getFloodlightLens();

    /* Геометрия корпуса — параллелепипед. */
    const housingGeo = new THREE.BoxGeometry(
        HOUSING_WIDTH,
        HOUSING_HEIGHT,
        HOUSING_DEPTH
    );

    /* Геометрия линзы — сфера чуть сплющенная. */
    const lensGeo = new THREE.SphereGeometry(LENS_SIZE * 0.5, 16, 12);

    /* Контур установки прожекторов — середина плиты крыши
     * (тот же, что у визуальных корпусов в RoofModule). Прожекторы стоят
     * равномерно по длине дуги суперэллипса. */
    const ring = getFloodlightContour();
    const radius = ring.rx;   // сохраняем в записи для совместимости
    const y = STADIUM_CONFIG.roof.baseHeight + L.floodlightHeight;
    const ringAngles = superEllipseEvenAngles(
        L.floodlightCount, ring.rx, ring.rz, STADIUM_CONFIG.shape.power
    );

    for (let i = 0; i < L.floodlightCount; i++) {
        const angle = ringAngles[i];
        const { x, z } = superEllipsePoint(
            angle, ring.rx, ring.rz, STADIUM_CONFIG.shape.power
        );

        /* ─── Источник света ─────────────────────────────────────── */
        const spot = new THREE.SpotLight(
            0xfff8e8,
            L.floodlightIntensity,
            L.floodlightDistance,
            FLOODLIGHT_ANGLE,
            FLOODLIGHT_PENUMBRA,
            FLOODLIGHT_DECAY
        );
        spot.name = `floodlight_${i}`;
        spot.position.set(x, y, z);
        spot.target.position.set(0, 0, 0);
        spot.castShadow = false;   // критично для производительности
        floodlightGroup.add(spot);
        floodlightGroup.add(spot.target);

        /* ─── Визуальный корпус — повернут «лицом» к центру ──────── */
        const housing = new THREE.Mesh(housingGeo, housingMat);
        housing.position.set(x, y, z);
        /* Ориентируем: корпус смотрит на центр арены. */
        housing.lookAt(0, 0, 0);
        /* Наклоняем корпус вниз — прожектор целится в поле. */
        housing.rotateX(-Math.PI * 0.35);
        housing.castShadow = false;
        housing.receiveShadow = false;
        floodlightGroup.add(housing);

        /* ─── Линза — светящийся элемент ─────────────────────────── */
        const lens = new THREE.Mesh(lensGeo, lensMat);
        /* Смещаем линзу вперёд от корпуса — по направлению света. */
        const lensOffset = new THREE.Vector3(0, 0, -HOUSING_DEPTH * 0.55);
        lensOffset.applyEuler(housing.rotation);
        lens.position.set(
            x + lensOffset.x,
            y + lensOffset.y,
            z + lensOffset.z
        );
        lens.castShadow = false;
        lens.receiveShadow = false;
        floodlightGroup.add(lens);

        /* ─── Сохраняем ссылки ──────────────────────────────────── */
        lighting.floodlights.push({
            light: spot,
            housing,
            lens,
            angle,
            radius,
            y,
            /* Базовая интенсивность — для анимации мерцания. */
            baseIntensity: L.floodlightIntensity,
        });
    }

    lighting.floodlightGroup = floodlightGroup;
    lighting.group.add(floodlightGroup);

    /* ─── Добавляем всю группу в сцену ─────────────────────────────── */
    scene.add(lighting.group);

    return lighting;
}


/* ══════════════════════════════════════════════════════════════════════════
 *  § 3. АНИМАЦИЯ МЕРЦАНИЯ ПРОЖЕКТОРОВ
 * ══════════════════════════════════════════════════════════════════════════ */

/**
 * Обновляет яркость прожекторов. Лёгкое фазовое мерцание
 * (±3% от базовой интенсивности), чтобы арена «дышала».
 *
 * Вызывается каждый кадр из основного цикла.
 *
 * @param {Object} lighting — результат createStadiumLighting
 * @param {number} time     — текущее время в секундах
 */
export function updateFloodlights(lighting, time) {
    if (!lighting || !lighting.floodlights) return;

    const list = lighting.floodlights;
    for (let i = 0; i < list.length; i++) {
        const f = list[i];
        /* Каждый прожектор мерцает со своей фазой — не синхронно. */
        const phase = i * 0.71 + time * 0.6;
        /* Амплитуда 3% — едва заметно, но оживляет картинку. */
        const mod = 1.0 + 0.03 * Math.sin(phase);
        f.light.intensity = f.baseIntensity * mod;
    }
}


/* ══════════════════════════════════════════════════════════════════════════
 *  § 4. РЕЖИМЫ ДЕНЬ / НОЧЬ
 * ══════════════════════════════════════════════════════════════════════════ */

/**
 * Переключает сцену в «ночной матч».
 *   • Солнце слабее, тёплый оттенок
 *   • Ambient гаснет
 *   • Hemisphere гаснет
 *   • Прожекторы включаются на максимум
 *
 * @param {Object} lighting — результат createStadiumLighting
 */
export function setNightMode(lighting) {
    if (!lighting) return;

    lighting.ambient.intensity = 0.10;
    lighting.hemisphere.intensity = 0.15;

    lighting.sun.intensity = 0.20;
    lighting.sun.color.setHex(0x9cb4d8);
    lighting.sun.position.set(-40, 60, -30);

    lighting.fill.intensity = 0.15;

    /* Прожекторы в максимум. */
    for (const f of lighting.floodlights) {
        f.baseIntensity = L.floodlightIntensity * 1.2;
        f.light.intensity = f.baseIntensity;
        /* Линзы ярче светятся в ночном режиме. */
        f.lens.material.emissiveIntensity = 1.6;
    }
}

/**
 * Переключает сцену в «дневной матч».
 *   • Солнце яркое сверху
 *   • Ambient средний
 *   • Hemisphere работает
 *   • Прожекторы приглушены (дежурный свет)
 *
 * @param {Object} lighting — результат createStadiumLighting
 */
export function setDayMode(lighting) {
    if (!lighting) return;

    lighting.ambient.intensity = L.ambientIntensity;
    lighting.hemisphere.intensity = L.hemisphereIntensity;

    lighting.sun.intensity = L.sunIntensity;
    lighting.sun.color.setHex(0xfff2e0);
    lighting.sun.position.set(
        L.sunPosition[0],
        L.sunPosition[1],
        L.sunPosition[2]
    );

    lighting.fill.intensity = 0.35;

    /* Прожекторы — дежурный свет (30%). */
    for (const f of lighting.floodlights) {
        f.baseIntensity = L.floodlightIntensity * 0.3;
        f.light.intensity = f.baseIntensity;
        f.lens.material.emissiveIntensity = 0.4;
    }
}

/**
 * Плавная интерполяция между днём и ночью.
 * t = 0 → день, t = 1 → ночь.
 *
 * Полезно для интро-анимации (рассвет/закат) или переключения сцены.
 *
 * @param {Object} lighting — результат createStadiumLighting
 * @param {number} t        — коэффициент [0..1]
 */
export function blendDayNight(lighting, t) {
    if (!lighting) return;

    const k = Math.max(0, Math.min(1, t));

    /* Ambient: 0.35 → 0.10. */
    lighting.ambient.intensity = 0.35 + (0.10 - 0.35) * k;

    /* Hemisphere: 0.55 → 0.15. */
    lighting.hemisphere.intensity = 0.55 + (0.15 - 0.55) * k;

    /* Sun: 1.15 → 0.20. */
    lighting.sun.intensity = 1.15 + (0.20 - 1.15) * k;

    /* Sun color: тёплое → холодное. */
    const warmR = 1.0,  warmG = 0.949, warmB = 0.878;   // 0xfff2e0
    const coolR = 0.612, coolG = 0.706, coolB = 0.847;  // 0x9cb4d8
    lighting.sun.color.setRGB(
        warmR + (coolR - warmR) * k,
        warmG + (coolG - warmG) * k,
        warmB + (coolB - warmB) * k
    );

    /* Sun position: интерполируем по дуге. */
    const angle = Math.PI * (0.25 + 0.35 * k);   // от 45° к 108°
    const radius = 120.0;
    lighting.sun.position.set(
        Math.cos(angle) * radius,
        Math.sin(angle) * radius,
        -30 * (1 - k) + 40 * k
    );

    /* Fill: 0.35 → 0.15. */
    lighting.fill.intensity = 0.35 + (0.15 - 0.35) * k;

    /* Прожекторы: 30% → 120%. */
    for (const f of lighting.floodlights) {
        f.baseIntensity = L.floodlightIntensity * (0.3 + 0.9 * k);
        f.light.intensity = f.baseIntensity;
        f.lens.material.emissiveIntensity = 0.4 + 1.2 * k;
    }
}


/* ══════════════════════════════════════════════════════════════════════════
 *  § 5. УПРАВЛЕНИЕ РЕСУРСАМИ
 * ══════════════════════════════════════════════════════════════════════════ */

/**
 * Освобождает все ресурсы освещения.
 * Вызывать при уничтожении сцены.
 *
 * @param {THREE.Scene} scene
 * @param {Object}      lighting — результат createStadiumLighting
 */
export function disposeStadiumLighting(scene, lighting) {
    if (!lighting) return;

    /* Удаляем всю группу из сцены. */
    if (lighting.group && lighting.group.parent) {
        scene.remove(lighting.group);
    }

    /* Очищаем массив прожекторов. */
    lighting.floodlights = [];

    /* Sun target также в группе — удалится вместе с ней. */
}


/* ══════════════════════════════════════════════════════════════════════════
 *  § 6. ОТЛАДКА
 * ══════════════════════════════════════════════════════════════════════════ */

/**
 * Возвращает информацию о состоянии освещения — для логов и метрик.
 *
 * @param {Object} lighting
 * @returns {Object}
 */
export function getLightingInfo(lighting) {
    if (!lighting) return null;

    return {
        ambientIntensity: lighting.ambient.intensity,
        hemisphereIntensity: lighting.hemisphere.intensity,
        sunIntensity: lighting.sun.intensity,
        sunPosition: lighting.sun.position.toArray(),
        fillIntensity: lighting.fill.intensity,
        floodlightCount: lighting.floodlights.length,
        floodlightIntensity: lighting.floodlights[0]
            ? lighting.floodlights[0].light.intensity
            : 0,
    };
}