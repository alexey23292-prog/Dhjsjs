/**
 * src/components/stadium/geometry/BowlGeometry.js
 *
 * ══════════════════════════════════════════════════════════════════════════
 *  ГЕОМЕТРИЧЕСКИЕ ПРИМИТИВЫ ЧАШИ СТАДИОНА
 *
 *  ─── ИДЕЯ ────────────────────────────────────────────────────────────────
 *    Чаша стадиона = «тело вращения». Профиль (набор точек [R, Y]) разворачивается
 *    вокруг вертикальной оси не по кругу, а по СУПЕРЭЛЛИПСУ (прямоугольник
 *    со скруглёнными углами, показатель — STADIUM_CONFIG.shape.power). Это позволяет:
 *      • Строить все 3 яруса одной функцией
 *      • Получить идеально гладкую поверхность из одного BufferGeometry
 *      • Обойтись БЕЗ сотен тысяч отдельных BoxGeometry для ступеней
 *
 *  ─── ПРОИЗВОДИТЕЛЬНОСТЬ ──────────────────────────────────────────────────
 *    Трибунный ярус (24 ряда × 96 сегментов) → ~30 000 вершин
 *    Тот же ярус из отдельных коробок → ~700 000 вершин
 *    Выигрыш: 23×, при визуально идентичном результате.
 *
 *  ─── UV-МАППИНГ ──────────────────────────────────────────────────────────
 *    U = угол вокруг арены (0..1)
 *    V = позиция вдоль профиля (0..1)
 *    Это позволяет использовать бесшовные текстуры бетона на ступенях.
 * ══════════════════════════════════════════════════════════════════════════
 */

import * as THREE from 'three';
import { STADIUM_CONFIG, superEllipsePoint } from '../StadiumConfig.js';


/* ══════════════════════════════════════════════════════════════════════════
 *  § 1. ПРОФИЛЬ ЯРУСА
 * ══════════════════════════════════════════════════════════════════════════ */

/**
 * Строит профиль яруса — упорядоченный список точек (rOffset, y).
 *
 *  rOffset — смещение наружу от базового радиуса яруса (в метрах),
 *  y       — абсолютная высота над полем (в метрах).
 *
 * Профиль описывает «срез» трибуны поперёк: от внутреннего края
 * до внешнего, с деталями каждой ступени.
 *
 * ─── СХЕМА ПРОФИЛЯ ────────────────────────────────────────────────────────
 *
 *    Y
 *    ▲
 *    │           ┌──┐  ┌──┐  ┌──┐    ← внешняя стенка
 *    │           │  │  │  │  │  │
 *    │        ┌──┘  └──┘  └──┘  └──┐
 *    │        │  row N-1            │
 *    │     ┌──┘                     │
 *    │     │  row 1                 │
 *    │  ┌──┘                        │
 *    │  │  row 0                    │
 *    │  └───┐                       │
 *    │      │                       │
 *    │      │ внутренняя стенка     │
 *    │      └─────────────────────────► R
 *    │
 *  0 └───────────────────────────────────
 *     startR                       endR
 *
 * ─── ПАРАМЕТРЫ ────────────────────────────────────────────────────────────
 * @param {Object} opts
 * @param {number} opts.rows            — количество рядов
 * @param {number} opts.depth           — глубина одного ряда (м)
 * @param {number} opts.height          — высота подступенка (м)
 * @param {number} opts.outerWallHeight — высота бортика после последнего ряда
 * @returns {Array<[number, number]>} массив точек [rOffset, y]
 */
export function buildTierProfile({
    rows,
    depth,
    height,
    outerWallHeight = 0.0,
}) {
    const profile = [];

    /* ─── 1. Внутренняя стенка ──────────────────────────────────── */
    /*
     * От уровня земли (0) до первого ряда. Вертикальная стенка,
     * которая «держит» всю трибуну. Визуально — цоколь.
     */
    profile.push([0.0, 0.0]);
    profile.push([0.0, height]);

    /* ─── 2. Ступени ряда ───────────────────────────────────────── */
    /*
     * Каждая ступень = (tread) + (riser):
     *   tread — горизонтальная площадка, где стоят сиденья
     *   riser — вертикальный подъём к следующему ряду
     *
     * Мы генерируем их как единый непрерывный профиль.
     */
    for (let k = 0; k < rows; k++) {
        const r = (k + 1) * depth;
        const y = (k + 1) * height;

        /* Площадка (tread) — от (r, y_prev) до (r+depth, y_prev)... */
        /* В нашей схеме — сначала подъём, потом площадка. */

        /* Вертикальный подъём на текущий ряд. */
        profile.push([k * depth, y]);

        /* Горизонтальная площадка на текущем ряду. */
        profile.push([(k + 1) * depth, y]);
    }

    /* ─── 3. Внешняя стенка (бортик) ────────────────────────────── */
    /*
     * После последнего ряда — вертикальный бортик или стенка,
     * отделяющая ярус от разделительного пояса.
     */
    if (outerWallHeight > 0.0) {
        profile.push([
            rows * depth,
            rows * height + outerWallHeight,
        ]);
    }

    return profile;
}


/* ══════════════════════════════════════════════════════════════════════════
 *  § 2. РАЗВЁРТКА ПРОФИЛЯ ВОКРУГ ЭЛЛИПСА (ГЛАВНАЯ ФУНКЦИЯ)
 * ══════════════════════════════════════════════════════════════════════════ */

/**
 * Разворачивает профиль вокруг эллипса, образуя поверхность чаши.
 *
 * ─── АЛГОРИТМ ─────────────────────────────────────────────────────────────
 *   Для каждой точки профиля [rOffset, y]:
 *     Для каждого сегмента s вокруг эллипса (0..segments):
 *       угол = s / segments × 2π
 *       R_x = rBaseX + rOffset
 *       R_z = rBaseZ + rOffset
 *       (x, z) = superEllipsePoint(угол, R_x, R_z, power)
 *       y = y (без изменений)
 *
 *   → Результат — регулярная сетка (профиль × окружность).
 *
 * ─── ОСОБЕННОСТИ ──────────────────────────────────────────────────────────
 *   • 1-й и последний сегмент совпадают по позиции, но разные по UV —
 *     это позволяет шву текстуры быть невидимым.
 *   • Нормали вычисляются автоматически (computeVertexNormals).
 *   • UV: U = угол (0..1), V = позиция в профиле (0..1).
 *
 * ─── ВАЖНО ────────────────────────────────────────────────────────────────
 *   Возвращённая геометрия центрирована относительно (0, baseY, 0).
 *   Мы НЕ смещаем по Y — все высоты абсолютные.
 *
 * @param {Array<[number, number]>} profile  — из buildTierProfile()
 * @param {number} rBaseX                    — базовый радиус по X
 * @param {number} rBaseZ                    — базовый радиус по Z
 * @param {number} segments                  — сегментов вокруг
 * @returns {THREE.BufferGeometry}
 */
export function loftProfileAroundEllipse(
    profile,
    rBaseX,
    rBaseZ,
    segments = STADIUM_CONFIG.performance.tierRadialSegments
) {
    if (!profile || profile.length < 2) {
        throw new Error('[BowlGeometry] Профиль должен иметь минимум 2 точки.');
    }
    if (segments < 8) {
        throw new Error('[BowlGeometry] Сегментов должно быть минимум 8.');
    }

    const profileLen = profile.length;
    const ringCols = segments + 1;   // +1 для шва UV
    const vertexCount = ringCols * profileLen;

    /* ─── Буферы ────────────────────────────────────────────────── */
    const positions = new Float32Array(vertexCount * 3);
    const uvs       = new Float32Array(vertexCount * 2);

    /* ─── Предвычисляем единичный суперэллипс по кольцу ─────────── */
    /*
     * superEllipsePoint(a, 1, 1, n) даёт «единичную» форму контура,
     * дальше достаточно умножить на полуоси (rx, rz) каждой точки профиля.
     * Математически это то же самое, что superEllipsePoint(a, rx, rz, n),
     * но считаем pow() один раз на сегмент, а не на каждую вершину.
     */
    const shapePower = STADIUM_CONFIG.shape.power;
    const unitX = new Float64Array(ringCols);
    const unitZ = new Float64Array(ringCols);
    for (let i = 0; i < ringCols; i++) {
        const a = (i / segments) * Math.PI * 2;
        const u = superEllipsePoint(a, 1, 1, shapePower);
        unitX[i] = u.x;
        unitZ[i] = u.z;
    }

    /* ─── Заполняем вершины ─────────────────────────────────────── */
    let vIdx = 0;
    for (let p = 0; p < profileLen; p++) {
        const rOffset = profile[p][0];
        const y       = profile[p][1];

        const rx = rBaseX + rOffset;
        const rz = rBaseZ + rOffset;

        /* V-координата — нормализованная позиция вдоль профиля. */
        const v = p / (profileLen - 1);

        for (let i = 0; i < ringCols; i++) {
            const px = unitX[i] * rx;
            const pz = unitZ[i] * rz;

            positions[vIdx * 3    ] = px;
            positions[vIdx * 3 + 1] = y;
            positions[vIdx * 3 + 2] = pz;

            uvs[vIdx * 2    ] = i / segments;
            uvs[vIdx * 2 + 1] = v;

            vIdx++;
        }
    }

    /* ─── Индексы ───────────────────────────────────────────────── */
    /*
     * Между двумя соседними профильными точками (p, p+1) и соседними
     * сегментами (i, i+1) образуется квад → 2 треугольника.
     *
     * Общее число квадов: (profileLen - 1) × segments
     * Общее число треугольников: ×2
     * Общее число индексов: ×3
     */
    const quadCount = (profileLen - 1) * segments;
    const indices = new Uint32Array(quadCount * 6);

    let iIdx = 0;
    for (let p = 0; p < profileLen - 1; p++) {
        const rowA = p * ringCols;
        const rowB = (p + 1) * ringCols;

        for (let i = 0; i < segments; i++) {
            const a = rowA + i;
            const b = a + 1;
            const c = rowB + i;
            const d = c + 1;

            /* Два треугольника (CCW порядок — нормаль наружу). */
            indices[iIdx++] = a;
            indices[iIdx++] = c;
            indices[iIdx++] = b;

            indices[iIdx++] = b;
            indices[iIdx++] = c;
            indices[iIdx++] = d;
        }
    }

    /* ─── Собираем BufferGeometry ──────────────────────────────── */
    const geo = new THREE.BufferGeometry();
    geo.setAttribute('position', new THREE.BufferAttribute(positions, 3));
    geo.setAttribute('uv',       new THREE.BufferAttribute(uvs, 2));
    geo.setIndex(new THREE.BufferAttribute(indices, 1));

    /* Автоматические нормали — Three.js сам считает cross product
     * для каждого треугольника и усредняет для вершин. */
    geo.computeVertexNormals();
    geo.computeBoundingSphere();

    return geo;
}


/* ══════════════════════════════════════════════════════════════════════════
 *  § 3. ГОТОВЫЕ ФУНКЦИИ ДЛЯ ЯРУСОВ
 * ══════════════════════════════════════════════════════════════════════════ */

/**
 * Строит полную геометрию одного яруса трибун.
 *
 * Комбинирует:
 *   • buildTierProfile  — профиль ряда
 *   • loftProfileAroundEllipse  — развёртка
 *   • Смещение по Y     — на baseY яруса
 *
 * @param {Object} tier — объект яруса из STADIUM_CONFIG.tiers
 * @param {number} [segments]
 * @returns {THREE.BufferGeometry}
 */
export function buildTierGeometry(
    tier,
    segments = STADIUM_CONFIG.performance.tierRadialSegments
) {
    const { row } = STADIUM_CONFIG;

    const profile = buildTierProfile({
        rows: tier.rows,
        depth: row.depth,
        height: row.height,
        outerWallHeight: tier.outerWallHeight,
    });

    const geo = loftProfileAroundEllipse(
        profile,
        tier.startRadiusX,
        tier.startRadiusZ,
        segments
    );

    /* Смещаем весь ярус на его baseY. */
    geo.translate(0, tier.baseY, 0);

    return geo;
}


/* ══════════════════════════════════════════════════════════════════════════
 *  § 4. ВСПОМОГАТЕЛЬНЫЕ КОЛЬЦА
 * ══════════════════════════════════════════════════════════════════════════ */

/**
 * Строит кольцо по суперэллипсу (плоский диск с отверстием).
 * Используется для:
 *   • Пола на уровне земли
 *   • Внутренних площадок и переходов
 *   • Основания чаши
 *
 * Отверстие внутри кольца — «дно» арены, где будет поле.
 *
 * @param {number} rxInner
 * @param {number} rzInner
 * @param {number} rxOuter
 * @param {number} rzOuter
 * @param {number} [segments]
 * @returns {THREE.BufferGeometry}
 */
export function buildEllipseRing(
    rxInner,
    rzInner,
    rxOuter,
    rzOuter,
    segments = STADIUM_CONFIG.performance.radialSegments
) {
    if (rxOuter <= rxInner || rzOuter <= rzInner) {
        throw new Error('[BowlGeometry] Внешний радиус должен быть больше внутреннего.');
    }

    const ringCols = segments + 1;
    const vertexCount = ringCols * 2;   // 2 кольца: inner + outer

    const positions = new Float32Array(vertexCount * 3);
    const uvs       = new Float32Array(vertexCount * 2);

    /* ─── Заполняем ─────────────────────────────────────────────── */
    const shapePower = STADIUM_CONFIG.shape.power;

    let vIdx = 0;
    for (let i = 0; i < ringCols; i++) {
        const a = (i / segments) * Math.PI * 2;
        const ptIn  = superEllipsePoint(a, rxInner, rzInner, shapePower);
        const ptOut = superEllipsePoint(a, rxOuter, rzOuter, shapePower);

        /* Внутренняя точка. */
        positions[vIdx * 3    ] = ptIn.x;
        positions[vIdx * 3 + 1] = 0;
        positions[vIdx * 3 + 2] = ptIn.z;
        uvs[vIdx * 2    ] = i / segments;
        uvs[vIdx * 2 + 1] = 0;
        vIdx++;

        /* Внешняя точка. */
        positions[vIdx * 3    ] = ptOut.x;
        positions[vIdx * 3 + 1] = 0;
        positions[vIdx * 3 + 2] = ptOut.z;
        uvs[vIdx * 2    ] = i / segments;
        uvs[vIdx * 2 + 1] = 1;
        vIdx++;
    }

    /* ─── Индексы ───────────────────────────────────────────────── */
    const indices = new Uint32Array(segments * 6);
    let iIdx = 0;
    for (let i = 0; i < segments; i++) {
        const a = i * 2;
        const b = a + 1;
        const c = a + 2;
        const d = a + 3;

        /* Нормаль наружу (сверху смотрим — CCW). */
        indices[iIdx++] = a;
        indices[iIdx++] = b;
        indices[iIdx++] = c;

        indices[iIdx++] = b;
        indices[iIdx++] = d;
        indices[iIdx++] = c;
    }

    const geo = new THREE.BufferGeometry();
    geo.setAttribute('position', new THREE.BufferAttribute(positions, 3));
    geo.setAttribute('uv',       new THREE.BufferAttribute(uvs, 2));
    geo.setIndex(new THREE.BufferAttribute(indices, 1));
    geo.computeVertexNormals();
    geo.computeBoundingSphere();

    return geo;
}


/**
 * Строит «пояс» по суперэллипсу — вертикальная стенка заданной высоты.
 * Используется для:
 *   • Разделительных полос между ярусами
 *   • Внешней оболочки без стекла
 *   • Оснований под рёбра фасада
 *
 * @param {number} rxBase
 * @param {number} rzBase
 * @param {number} height
 * @param {number} [yBase=0]
 * @param {number} [segments]
 * @returns {THREE.BufferGeometry}
 */
export function buildEllipseBand(
    rxBase,
    rzBase,
    height,
    yBase = 0,
    segments = STADIUM_CONFIG.performance.radialSegments
) {
    const bandCols = segments + 1;
    const vertexCount = bandCols * 2;   // 2 кольца: bottom + top

    const positions = new Float32Array(vertexCount * 3);
    const uvs       = new Float32Array(vertexCount * 2);

    const shapePower = STADIUM_CONFIG.shape.power;

    let vIdx = 0;
    for (let i = 0; i < bandCols; i++) {
        const a = (i / segments) * Math.PI * 2;
        const pt = superEllipsePoint(a, rxBase, rzBase, shapePower);

        const x = pt.x;
        const z = pt.z;

        /* Низ. */
        positions[vIdx * 3    ] = x;
        positions[vIdx * 3 + 1] = yBase;
        positions[vIdx * 3 + 2] = z;
        uvs[vIdx * 2    ] = i / segments;
        uvs[vIdx * 2 + 1] = 0;
        vIdx++;

        /* Верх. */
        positions[vIdx * 3    ] = x;
        positions[vIdx * 3 + 1] = yBase + height;
        positions[vIdx * 3 + 2] = z;
        uvs[vIdx * 2    ] = i / segments;
        uvs[vIdx * 2 + 1] = 1;
        vIdx++;
    }

    /* ─── Индексы ───────────────────────────────────────────────── */
    const indices = new Uint32Array(segments * 6);
    let iIdx = 0;
    for (let i = 0; i < segments; i++) {
        const a = i * 2;
        const b = a + 1;
        const c = a + 2;
        const d = a + 3;

        /* Нормаль наружу (CCW). */
        indices[iIdx++] = a;
        indices[iIdx++] = c;
        indices[iIdx++] = b;

        indices[iIdx++] = b;
        indices[iIdx++] = c;
        indices[iIdx++] = d;
    }

    const geo = new THREE.BufferGeometry();
    geo.setAttribute('position', new THREE.BufferAttribute(positions, 3));
    geo.setAttribute('uv',       new THREE.BufferAttribute(uvs, 2));
    geo.setIndex(new THREE.BufferAttribute(indices, 1));
    geo.computeVertexNormals();
    geo.computeBoundingSphere();

    return geo;
}


/* ══════════════════════════════════════════════════════════════════════════
 *  § 5. ПРОИЗВОДСТВО СТУПЕНЕЙ (ИНФО)
 * ══════════════════════════════════════════════════════════════════════════ */

/**
 * Возвращает массив позиций ступеней яруса.
 * Используется для расстановки мест и для отладки.
 *
 * @param {Object} tier — объект яруса
 * @returns {Array<{rOffsetX, rOffsetZ, y, angle}>}
 */
export function computeTierRowPositions(tier) {
    const { row } = STADIUM_CONFIG;
    const positions = [];

    for (let k = 0; k < tier.rows; k++) {
        positions.push({
            /* Смещение от базового радиуса яруса. */
            rOffsetX: (k + 0.5) * row.depth,
            rOffsetZ: (k + 0.5) * row.depth,
            /* Высота сиденья (середина площадки). */
            y: tier.baseY + (k + 1) * row.height,
            /* Номер ряда (для отладки). */
            rowIndex: k,
        });
    }

    return positions;
}


/**
 * Вычисляет общее число вершин в геометрии яруса.
 * Для метрик производительности.
 *
 * @param {number} rows
 * @param {number} segments
 * @returns {number}
 */
export function estimateTierVertexCount(rows, segments) {
    const profileLen = 2 + rows * 2;   // внутренняя стенка + N ступеней
    const ringCols = segments + 1;
    return profileLen * ringCols;
}


/**
 * Вычисляет общее число треугольников в геометрии яруса.
 *
 * @param {number} rows
 * @param {number} segments
 * @returns {number}
 */
export function estimateTierTriangleCount(rows, segments) {
    const profileLen = 2 + rows * 2;
    return (profileLen - 1) * segments * 2;
}