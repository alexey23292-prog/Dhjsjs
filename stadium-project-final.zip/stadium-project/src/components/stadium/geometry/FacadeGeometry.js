/**
 * src/components/stadium/geometry/FacadeGeometry.js
 *
 * ══════════════════════════════════════════════════════════════════════════
 *  ГЕОМЕТРИЯ ВНЕШНЕГО ФАСАДА
 *
 *  ─── СОСТАВНЫЕ ЧАСТИ ФАСАДА ──────────────────────────────────────────────
 *    1. Вертикальные рёбра (72 шт)   — рёбра жёсткости по кругу
 *    2. Горизонтальные пояса         — каждые 6 м по высоте
 *    3. Стеклянная оболочка          — между рёбрами
 *    4. Кольцо венчающего карниза    — верх фасада
 *
 *  ─── АРХИТЕКТУРНАЯ СХЕМА ─────────────────────────────────────────────────
 *
 *      ╔═══════════════════════════════════════╗ ← венчающий карниз
 *      ║  ┌──┐    ┌──┐    ┌──┐    ┌──┐    ┌──┐ ║ ← вертикальные рёбра
 *      ║  │  │    │  │    │  │    │  │    │  │ ║
 *      ║  │  │╔═══╬═══╗  │  │    │  │    │  │ ║ ← горизонтальный пояс
 *      ║  │  │║▒▒▒║▒▒▒║  │  │    │  │    │  │ ║
 *      ║  │  │╠═══╬═══╣  │  │    │  │    │  │ ║ ← стекло между
 *      ║  │  │║▒▒▒║▒▒▒║  │  │    │  │    │  │ ║
 *      ║  │  │╠═══╬═══╣  │  │    │  │    │  │ ║
 *      ║  │  │║▒▒▒║▒▒▒║  │  │    │  │    │  │ ║
 *      ║  │  │╚═══╬═══╝  │  │    │  │    │  │ ║
 *      ║  └──┘    └──┘    └──┘    └──┘    └──┘ ║
 *      ╚═══════════════════════════════════════╝
 *        ────────────── земля ──────────────
 *
 *  ─── ОПТИМИЗАЦИЯ ─────────────────────────────────────────────────────────
 *    • 72 ребра → 1 InstancedMesh (все одинаковые)
 *    • 7 поясов  → 7 разных геометрий (эллипс разной высоты)
 *    • Стекло    → 1 ExtrudeGeometry
 *    • Итого ~9 объектов вместо 80
 * ══════════════════════════════════════════════════════════════════════════
 */

import * as THREE from 'three';
import {
    STADIUM_CONFIG,
    superEllipsePoint,
    superEllipseFrame,
    superEllipseEvenAngles,
} from '../StadiumConfig.js';


/* ══════════════════════════════════════════════════════════════════════════
 *  § 1. ВЕРТИКАЛЬНЫЕ РЁБРА
 * ══════════════════════════════════════════════════════════════════════════ */

/**
 * Создаёт базовую геометрию одного вертикального ребра.
 * Все 72 ребра идентичны, поэтому используется InstancedMesh.
 *
 * ─── ГЕОМЕТРИЯ ────────────────────────────────────────────────────────────
 *   Простой параллелепипед шириной ribWidth × глубиной ribDepth ×
 *   высотой ribHeight. Начало координат — в центре нижней грани,
 *   чтобы легко позиционировать по земле.
 *
 * @returns {THREE.BufferGeometry}
 */
export function buildFacadeRibGeometry() {
    const { ribWidth, ribDepth, height } = STADIUM_CONFIG.facade;

    /* BoxGeometry центрирован в начале координат. */
    const geo = new THREE.BoxGeometry(ribWidth, height, ribDepth);

    /* Сдвигаем так, чтобы основание было в y = 0. */
    geo.translate(0, height * 0.5, 0);

    return geo;
}


/**
 * Вычисляет позиции и ориентации всех рёбер вокруг суперэллипса фасада.
 *
 * ─── РАССТАНОВКА ──────────────────────────────────────────────────────────
 *   Параметр t суперэллипса шагает по кривой неравномерно (на прямых
 *   сторонах — крупно, в углах — мелко), поэтому рёбра ставятся не через
 *   равные Δt, а через равные доли ДЛИНЫ ДУГИ (superEllipseEvenAngles).
 *
 * ─── ОРИЕНТАЦИЯ ───────────────────────────────────────────────────────────
 *   Широкая грань ребра (локальная ось +Z) смотрит по ВНЕШНЕЙ НОРМАЛИ
 *   к суперэллипсу. Нормаль считается численной производной
 *   (superEllipseFrame): касательная = (dx, dz)/|·|, нормаль = (tz, −tx).
 *   Формула «нормаль эллипса» (cos/a, sin/b) здесь неприменима.
 *
 * @returns {Array<{x, z, rotationY}>}
 */
export function computeFacadeRibPositions() {
    const { radiusX, radiusZ, ribCount } = STADIUM_CONFIG.facade;
    const shapePower = STADIUM_CONFIG.shape.power;

    const angles = superEllipseEvenAngles(ribCount, radiusX, radiusZ, shapePower);
    const positions = [];

    for (let i = 0; i < ribCount; i++) {
        const t = angles[i];

        /* Точка на суперэллипсе. */
        const pt = superEllipsePoint(t, radiusX, radiusZ, shapePower);

        /* Нормаль по численной производной контура. */
        const frame = superEllipseFrame(t, radiusX, radiusZ, shapePower);

        positions.push({ x: pt.x, z: pt.z, rotationY: frame.rotationY });
    }

    return positions;
}


/**
 * Строит единый InstancedMesh со всеми вертикальными рёбрами фасада.
 *
 * ─── ПРОИЗВОДИТЕЛЬНОСТЬ ───────────────────────────────────────────────────
 *   InstancedMesh рисует 72 ребра одним вызовом.
 *   Draw calls: 1 вместо 72.
 *   Matrix обновляется один раз — больше не трогаем.
 *
 * @param {THREE.Material} material
 * @returns {THREE.InstancedMesh}
 */
export function buildFacadeRibGroup(material) {
    const geometry = buildFacadeRibGeometry();
    const positions = computeFacadeRibPositions();
    const count = positions.length;

    const mesh = new THREE.InstancedMesh(geometry, material, count);
    mesh.name = 'facade_ribs';
    mesh.castShadow = true;
    mesh.receiveShadow = true;

    /* ─── Заполняем матрицы ─────────────────────────────────────── */
    const dummy = new THREE.Object3D();

    for (let i = 0; i < count; i++) {
        const p = positions[i];

        dummy.position.set(p.x, 0, p.z);
        dummy.rotation.set(0, p.rotationY, 0);
        dummy.scale.set(1, 1, 1);
        dummy.updateMatrix();

        mesh.setMatrixAt(i, dummy.matrix);
    }

    mesh.instanceMatrix.needsUpdate = true;

    /* Frustum culling отключаем — 72 ребра разбросаны по всему фасаду,
     * и bounding sphere всё равно покрывает всю арену. */
    mesh.frustumCulled = false;

    return mesh;
}


/* ══════════════════════════════════════════════════════════════════════════
 *  § 2. ГОРИЗОНТАЛЬНЫЕ ПОЯСА
 * ══════════════════════════════════════════════════════════════════════════ */

/**
 * Строит одно кольцо-пояс (эллиптический аннулус малой высоты).
 *
 * ─── ПРОФИЛЬ ──────────────────────────────────────────────────────────────
 *
 *     Y
 *     ▲
 *     │   ┌────────────────┐  ← верх
 *     │   │                │
 *     │   │  пояс (0.5 м)  │
 *     │   │                │
 *     │   └────────────────┘  ← низ
 *     │
 *     └──────────────────────► R
 *         R_inner   R_outer
 *
 * Толщина пояса: beltDepth = 0.3 м.
 * Высота пояса:  beltHeight = 0.5 м.
 *
 * @returns {THREE.BufferGeometry}
 */
export function buildFacadeBeltGeometry() {
    const { radiusX, radiusZ, beltHeight, beltDepth } = STADIUM_CONFIG.facade;
    const segments = STADIUM_CONFIG.performance.radialSegments;
    const shapePower = STADIUM_CONFIG.shape.power;

    const ringCols = segments + 1;

    /* Профиль пояса: 4 точки (прямоугольник в разрезе). */
    const profilePoints = [
        { rx: radiusX - beltDepth, rz: radiusZ - beltDepth, y: 0             }, // внутр. низ
        { rx: radiusX,             rz: radiusZ,             y: 0             }, // внеш. низ
        { rx: radiusX,             rz: radiusZ,             y: beltHeight    }, // внеш. верх
        { rx: radiusX - beltDepth, rz: radiusZ - beltDepth, y: beltHeight    }, // внутр. верх
        { rx: radiusX - beltDepth, rz: radiusZ - beltDepth, y: 0             }, // замыкание
    ];

    const profileLen = profilePoints.length;
    const vertexCount = ringCols * profileLen;

    const positions = new Float32Array(vertexCount * 3);
    const uvs = new Float32Array(vertexCount * 2);

    let vIdx = 0;
    for (let p = 0; p < profileLen; p++) {
        const pt = profilePoints[p];
        const v = p / (profileLen - 1);

        for (let i = 0; i < ringCols; i++) {
            const a = (i / segments) * Math.PI * 2;
            const sp = superEllipsePoint(a, pt.rx, pt.rz, shapePower);

            positions[vIdx * 3    ] = sp.x;
            positions[vIdx * 3 + 1] = pt.y;
            positions[vIdx * 3 + 2] = sp.z;

            uvs[vIdx * 2    ] = i / segments;
            uvs[vIdx * 2 + 1] = v;

            vIdx++;
        }
    }

    /* Индексы. */
    const quadCount = (profileLen - 1) * segments;
    const indices = new Uint32Array(quadCount * 6);

    let iIdx = 0;
    for (let p = 0; p < profileLen - 1; p++) {
        const rowA = p * ringCols;
        const rowB = (p + 1) * ringCols;

        for (let i = 0; i < segments; i++) {
            const a = rowA + i;
            const b = a + 1;
            const c = rowB + i;
            const d = c + 1;

            indices[iIdx++] = a;
            indices[iIdx++] = c;
            indices[iIdx++] = b;

            indices[iIdx++] = b;
            indices[iIdx++] = c;
            indices[iIdx++] = d;
        }
    }

    const geo = new THREE.BufferGeometry();
    geo.setAttribute('position', new THREE.BufferAttribute(positions, 3));
    geo.setAttribute('uv',       new THREE.BufferAttribute(uvs, 2));
    geo.setIndex(new THREE.BufferAttribute(indices, 1));
    geo.computeVertexNormals();
    geo.computeBoundingSphere();

    return geo;
}


/**
 * Строит все горизонтальные пояса фасада как единый Group.
 *
 * Пояса идут каждые `beltSpacing` метров от 0 до `height`.
 *
 * @param {THREE.Material} material
 * @returns {THREE.Group}
 */
export function buildFacadeBelts(material) {
    const { height, beltSpacing } = STADIUM_CONFIG.facade;

    const group = new THREE.Group();
    group.name = 'facade_belts';

    /* Одну геометрию переиспользуем для всех поясов — они идентичны. */
    const beltGeo = buildFacadeBeltGeometry();

    /* Количество поясов: от beltSpacing до height (шаг beltSpacing). */
    const ringCount = Math.floor(height / beltSpacing);

    for (let i = 1; i <= ringCount; i++) {
        const y = i * beltSpacing;

        /* Не выходим за верхнюю границу фасада. */
        if (y + STADIUM_CONFIG.facade.beltHeight > height) break;

        const mesh = new THREE.Mesh(beltGeo, material);
        mesh.position.y = y;
        mesh.castShadow = true;
        mesh.receiveShadow = true;
        group.add(mesh);
    }

    return group;
}


/* ══════════════════════════════════════════════════════════════════════════
 *  § 3. СТЕКЛЯННАЯ ОБОЛОЧКА
 * ══════════════════════════════════════════════════════════════════════════ */

/**
 * Строит стеклянную оболочку фасада — «цилиндр» по суперэллипсу
 * без верха и низа.
 *
 * ─── ГЕОМЕТРИЯ ────────────────────────────────────────────────────────────
 *   Боковая поверхность цилиндра с сечением-суперэллипсом. Не замкнутая сверху/снизу,
 *   потому что стекло примыкает к поясам и карнизу.
 *
 * @returns {THREE.BufferGeometry}
 */
export function buildFacadeGlassGeometry() {
    const { radiusX, radiusZ, height } = STADIUM_CONFIG.facade;
    const segments = STADIUM_CONFIG.performance.radialSegments;
    const shapePower = STADIUM_CONFIG.shape.power;

    /* Немного уменьшаем радиусы, чтобы стекло было чуть внутри рёбер. */
    const glassInset = 0.05;
    const rx = radiusX - glassInset;
    const rz = radiusZ - glassInset;

    const ringCols = segments + 1;
    const vertexCount = ringCols * 2;   // низ + верх

    const positions = new Float32Array(vertexCount * 3);
    const uvs = new Float32Array(vertexCount * 2);

    let vIdx = 0;
    for (let i = 0; i < ringCols; i++) {
        const a = (i / segments) * Math.PI * 2;
        const gp = superEllipsePoint(a, rx, rz, shapePower);

        const x = gp.x;
        const z = gp.z;

        /* Низ. */
        positions[vIdx * 3    ] = x;
        positions[vIdx * 3 + 1] = 0;
        positions[vIdx * 3 + 2] = z;
        uvs[vIdx * 2    ] = i / segments;
        uvs[vIdx * 2 + 1] = 0;
        vIdx++;

        /* Верх. */
        positions[vIdx * 3    ] = x;
        positions[vIdx * 3 + 1] = height;
        positions[vIdx * 3 + 2] = z;
        uvs[vIdx * 2    ] = i / segments;
        uvs[vIdx * 2 + 1] = 1;
        vIdx++;
    }

    /* Индексы. */
    const indices = new Uint32Array(segments * 6);
    let iIdx = 0;
    for (let i = 0; i < segments; i++) {
        const a = i * 2;
        const b = a + 1;
        const c = a + 2;
        const d = a + 3;

        indices[iIdx++] = a;
        indices[iIdx++] = c;
        indices[iIdx++] = b;

        indices[iIdx++] = b;
        indices[iIdx++] = c;
        indices[iIdx++] = d;
    }

    const geo = new THREE.BufferGeometry();
    geo.setAttribute('position', new THREE.BufferAttribute(positions, 3));
    geo.setAttribute('uv',       new THREE.BufferAttribute(uvs, 2));
    geo.setIndex(new THREE.BufferAttribute(indices, 1));
    geo.computeVertexNormals();
    geo.computeBoundingSphere();

    return geo;
}


/**
 * Строит меш со стеклянной оболочкой.
 *
 * @param {THREE.Material} material
 * @returns {THREE.Mesh}
 */
export function buildFacadeGlass(material) {
    const geo = buildFacadeGlassGeometry();
    const mesh = new THREE.Mesh(geo, material);
    mesh.name = 'facade_glass';
    /* Стекло не отбрасывает и не принимает тени —
     * это разрушило бы визуальный слой. */
    mesh.castShadow = false;
    mesh.receiveShadow = false;
    /* Внутри видно и через перед, и через зад. */
    mesh.renderOrder = 1;
    return mesh;
}


/* ══════════════════════════════════════════════════════════════════════════
 *  § 4. ВЕНЧАЮЩИЙ КАРНИЗ
 * ══════════════════════════════════════════════════════════════════════════ */

/**
 * Строит венчающий карниз — кольцо на самом верху фасада.
 *
 * ─── АРХИТЕКТУРНАЯ РОЛЬ ───────────────────────────────────────────────────
 *   Завершает вертикаль фасада, скрывает стык фасад-крыша,
 *   визуально утяжеляет верх — как в настоящих аренах.
 *
 * @param {THREE.Material} material
 * @returns {THREE.Mesh}
 */
export function buildCornice(material) {
    const { radiusX, radiusZ, height } = STADIUM_CONFIG.facade;
    const segments = STADIUM_CONFIG.performance.radialSegments;
    const shapePower = STADIUM_CONFIG.shape.power;

    /* ─── Профиль карниза — выступ наружу ─────────────────────── */
    const corniceHeight = 1.2;
    const corniceDepth = 0.5;

    const profilePoints = [
        { rx: radiusX,               rz: radiusZ,               y: 0                    },
        { rx: radiusX + corniceDepth, rz: radiusZ + corniceDepth, y: 0                    },
        { rx: radiusX + corniceDepth, rz: radiusZ + corniceDepth, y: corniceHeight       },
        { rx: radiusX,               rz: radiusZ,               y: corniceHeight       },
        { rx: radiusX,               rz: radiusZ,               y: 0                    }, // замыкание
    ];

    const profileLen = profilePoints.length;
    const ringCols = segments + 1;
    const vertexCount = ringCols * profileLen;

    const positions = new Float32Array(vertexCount * 3);
    const uvs = new Float32Array(vertexCount * 2);

    let vIdx = 0;
    for (let p = 0; p < profileLen; p++) {
        const pt = profilePoints[p];
        const v = p / (profileLen - 1);

        for (let i = 0; i < ringCols; i++) {
            const a = (i / segments) * Math.PI * 2;
            const sp = superEllipsePoint(a, pt.rx, pt.rz, shapePower);

            positions[vIdx * 3    ] = sp.x;
            positions[vIdx * 3 + 1] = pt.y;
            positions[vIdx * 3 + 2] = sp.z;

            uvs[vIdx * 2    ] = i / segments;
            uvs[vIdx * 2 + 1] = v;

            vIdx++;
        }
    }

    const quadCount = (profileLen - 1) * segments;
    const indices = new Uint32Array(quadCount * 6);

    let iIdx = 0;
    for (let p = 0; p < profileLen - 1; p++) {
        const rowA = p * ringCols;
        const rowB = (p + 1) * ringCols;

        for (let i = 0; i < segments; i++) {
            const a = rowA + i;
            const b = a + 1;
            const c = rowB + i;
            const d = c + 1;

            indices[iIdx++] = a;
            indices[iIdx++] = c;
            indices[iIdx++] = b;

            indices[iIdx++] = b;
            indices[iIdx++] = c;
            indices[iIdx++] = d;
        }
    }

    const geo = new THREE.BufferGeometry();
    geo.setAttribute('position', new THREE.BufferAttribute(positions, 3));
    geo.setAttribute('uv',       new THREE.BufferAttribute(uvs, 2));
    geo.setIndex(new THREE.BufferAttribute(indices, 1));
    geo.computeVertexNormals();
    geo.computeBoundingSphere();

    const mesh = new THREE.Mesh(geo, material);
    mesh.name = 'facade_cornice';
    mesh.position.y = height - corniceHeight;
    mesh.castShadow = true;
    mesh.receiveShadow = true;
    return mesh;
}


/* ══════════════════════════════════════════════════════════════════════════
 *  § 5. МЕТРИКИ
 * ══════════════════════════════════════════════════════════════════════════ */

/**
 * Считает приблизительные метрики геометрии фасада.
 *
 * @returns {Object}
 */
export function estimateFacadeComplexity() {
    const cfg = STADIUM_CONFIG.facade;
    const segments = STADIUM_CONFIG.performance.radialSegments;

    /* Рёбра: 72 × 12 вершин (BoxGeometry = 12 треугольников × 3). */
    const ribVerts = 72 * 24;   // Box имеет 24 вершины (6 граней × 4)
    const ribTris = 72 * 12;

    /* Пояса: 7 × (5 профильных точек × 129 кольцевых столбцов). */
    const beltCount = Math.floor(cfg.height / cfg.beltSpacing);
    const beltVerts = beltCount * 5 * (segments + 1);
    const beltTris = beltCount * 4 * segments * 2;

    /* Стекло: 2 × 129 вершин. */
    const glassVerts = 2 * (segments + 1);
    const glassTris = 2 * segments;

    /* Карниз: как пояс. */
    const corniceVerts = 5 * (segments + 1);
    const corniceTris = 4 * segments * 2;

    return {
        ribs:    { count: 72, vertices: ribVerts, triangles: ribTris, drawCalls: 1 },
        belts:   { count: beltCount, vertices: beltVerts, triangles: beltTris, drawCalls: beltCount },
        glass:   { vertices: glassVerts, triangles: glassTris, drawCalls: 1 },
        cornice: { vertices: corniceVerts, triangles: corniceTris, drawCalls: 1 },
        summary: {
            totalVertices:  ribVerts + beltVerts + glassVerts + corniceVerts,
            totalTriangles: ribTris + beltTris + glassTris + corniceTris,
            totalDrawCalls: 1 + beltCount + 1 + 1,
        },
    };
}