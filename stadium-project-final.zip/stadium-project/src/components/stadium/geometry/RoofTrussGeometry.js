/**
 * src/components/stadium/geometry/RoofTrussGeometry.js
 *
 * ══════════════════════════════════════════════════════════════════════════
 *  ГЕОМЕТРИЯ КРЫШИ СТАДИОНА — COMPACT EDITION
 *
 *  ─── ВЕРСИЯ ──────────────────────────────────────────────────────────────
 *    Адаптирован под уменьшенный стадион (крыша на 17 м):
 *      • Высота ферм: 2.4 → 1.2 м (не торчат над крышей 0.7 м)
 *      • Радиус прутьев: 0.09 → 0.06 м
 *      • Радиус рёбер жёсткости: 0.18 → 0.13 м
 *      • Все размеры пропорциональны Compact Edition
 *
 *  ─── СОСТАВНЫЕ ЧАСТИ ─────────────────────────────────────────────────────
 *    1. Кольцевая плита навеса (buildRoofRing)
 *    2. Фермы — решётчатые балки (buildRoofTruss)
 *    3. Опорные колонны (buildRoofPillar)
 *    4. Кольцевые рёбра жёсткости (buildRoofRibRing)
 *    5. Диагональные подкосы (buildDiagonalBrace)
 * ══════════════════════════════════════════════════════════════════════════
 */

import * as THREE from 'three';
import {
    STADIUM_CONFIG,
    superEllipsePoint,
    superEllipseEvenAngles,
} from '../StadiumConfig.js';


/* ══════════════════════════════════════════════════════════════════════════
 *  § 1. КОНСТАНТЫ — COMPACT EDITION
 * ══════════════════════════════════════════════════════════════════════════ */

/** Радиус прутьев решётки фермы (м). */
const TRUSS_STRUT_RADIUS = 0.06;

/** Количество ячеек в одной ферме. */
const TRUSS_SEGMENTS = 6;

/**
 * Высота фермы (расстояние между нижним и верхним поясом), м.
 * ⚠️ Уменьшено с 2.4 до 1.2 — теперь ферма ниже крыши (0.7 м)
 * и не торчит над ней.
 */
const TRUSS_HEIGHT = 1.2;

/** Высота опорного хомута у основания колонны (м). */
const PILLAR_BASE_HEIGHT = 0.4;

/** Радиус базы колонны (× радиус самой колонны). */
const PILLAR_BASE_SCALE_BOTTOM = 2.5;
const PILLAR_BASE_SCALE_TOP    = 2.0;

/** Количество рёбер жёсткости под крышей. */
const ROOF_RIB_COUNT = 24;

/** Радиус рёбер жёсткости (м). */
const ROOF_RIB_RADIUS = 0.13;


/* ══════════════════════════════════════════════════════════════════════════
 *  § 2. КОЛЬЦЕВАЯ ПЛИТА НАВЕСА
 * ══════════════════════════════════════════════════════════════════════════ */

/**
 * Строит кольцевую плиту крыши.
 *
 * @returns {THREE.BufferGeometry}
 */
export function buildRoofRing() {
    const {
        innerRadiusX, innerRadiusZ,
        outerRadiusX, outerRadiusZ,
        baseHeight, innerDrop, thickness,
    } = STADIUM_CONFIG.roof;

    const segments = STADIUM_CONFIG.performance.radialSegments;
    const shapePower = STADIUM_CONFIG.shape.power;

    const ringCols = segments + 1;
    const profileLen = 5;
    const vertexCount = ringCols * profileLen;

    const positions = new Float32Array(vertexCount * 3);
    const uvs = new Float32Array(vertexCount * 2);

    const rX_inner = innerRadiusX;
    const rZ_inner = innerRadiusZ;
    const rX_outer = outerRadiusX;
    const rZ_outer = outerRadiusZ;

    const yInnerTop    = baseHeight - innerDrop;
    const yOuterTop    = baseHeight;
    const yOuterBottom = baseHeight - thickness;
    const yInnerBottom = baseHeight - innerDrop - thickness;

    const profilePoints = [
        { rx: rX_inner, rz: rZ_inner, y: yInnerTop    },
        { rx: rX_outer, rz: rZ_outer, y: yOuterTop    },
        { rx: rX_outer, rz: rZ_outer, y: yOuterBottom },
        { rx: rX_inner, rz: rZ_inner, y: yInnerBottom },
        { rx: rX_inner, rz: rZ_inner, y: yInnerTop    },
    ];

    let vIdx = 0;
    for (let p = 0; p < profileLen; p++) {
        const pt = profilePoints[p];
        const v = p / (profileLen - 1);

        for (let i = 0; i < ringCols; i++) {
            const a = (i / segments) * Math.PI * 2;
            const sp = superEllipsePoint(a, pt.rx, pt.rz, shapePower);

            positions[vIdx * 3    ] = sp.x;
            positions[vIdx * 3 + 1] = pt.y;
            positions[vIdx * 3 + 2] = sp.z;

            uvs[vIdx * 2    ] = i / segments;
            uvs[vIdx * 2 + 1] = v;

            vIdx++;
        }
    }

    const quadCount = (profileLen - 1) * segments;
    const indices = new Uint32Array(quadCount * 6);

    let iIdx = 0;
    for (let p = 0; p < profileLen - 1; p++) {
        const rowA = p * ringCols;
        const rowB = (p + 1) * ringCols;

        for (let i = 0; i < segments; i++) {
            const a = rowA + i;
            const b = a + 1;
            const c = rowB + i;
            const d = c + 1;

            indices[iIdx++] = a;
            indices[iIdx++] = c;
            indices[iIdx++] = b;

            indices[iIdx++] = b;
            indices[iIdx++] = c;
            indices[iIdx++] = d;
        }
    }

    const geo = new THREE.BufferGeometry();
    geo.setAttribute('position', new THREE.BufferAttribute(positions, 3));
    geo.setAttribute('uv',       new THREE.BufferAttribute(uvs, 2));
    geo.setIndex(new THREE.BufferAttribute(indices, 1));
    geo.computeVertexNormals();
    geo.computeBoundingSphere();

    return geo;
}


/* ══════════════════════════════════════════════════════════════════════════
 *  § 3. РЕШЁТЧАТАЯ ФЕРМА
 * ══════════════════════════════════════════════════════════════════════════ */

/**
 * Строит одну решётчатую ферму.
 *
 * @param {number} length
 * @returns {THREE.Group}
 */
export function buildRoofTruss(length) {
    const group = new THREE.Group();
    group.name = 'roof_truss';

    if (length <= 0) {
        console.warn('[RoofTruss] Длина фермы должна быть > 0.');
        return group;
    }

    const makeStrut = (ax, ay, az, bx, by, bz) => {
        const dx = bx - ax;
        const dy = by - ay;
        const dz = bz - az;
        const len = Math.sqrt(dx * dx + dy * dy + dz * dz);

        if (len < 1e-6) return null;

        const geo = new THREE.CylinderGeometry(
            TRUSS_STRUT_RADIUS,
            TRUSS_STRUT_RADIUS,
            len,
            6,
            1,
            false
        );

        const mesh = new THREE.Mesh(geo);
        mesh.position.set(
            (ax + bx) * 0.5,
            (ay + by) * 0.5,
            (az + bz) * 0.5
        );
        mesh.quaternion.setFromUnitVectors(
            new THREE.Vector3(0, 1, 0),
            new THREE.Vector3(dx, dy, dz).normalize()
        );
        return mesh;
    };

    const H = TRUSS_HEIGHT;
    const N = TRUSS_SEGMENTS;

    /* Нижний пояс. */
    const bottomChord = makeStrut(0, 0, 0, length, 0, 0);
    if (bottomChord) group.add(bottomChord);

    /* Верхний пояс. */
    const topChord = makeStrut(0, H, 0, length, H, 0);
    if (topChord) group.add(topChord);

    /* Раскосы и стойки. */
    const segLen = length / N;

    for (let i = 0; i < N; i++) {
        const x1 = i * segLen;
        const x2 = (i + 1) * segLen;

        if (i === 0 || i === N - 1) {
            const strut = makeStrut(x1, 0, 0, x1, H, 0);
            if (strut) group.add(strut);
        }

        const diagA = makeStrut(x1, 0, 0, x2, H, 0);
        if (diagA) group.add(diagA);

        const diagB = makeStrut(x1, H, 0, x2, 0, 0);
        if (diagB) group.add(diagB);
    }

    const endStrut = makeStrut(length, 0, 0, length, H, 0);
    if (endStrut) group.add(endStrut);

    return group;
}


/* ══════════════════════════════════════════════════════════════════════════
 *  § 4. ОПОРНАЯ КОЛОННА КРЫШИ
 * ══════════════════════════════════════════════════════════════════════════ */

/**
 * Строит опорную колонну крыши.
 *
 * @param {Object} opts
 * @param {number} opts.height
 * @param {number} opts.radius
 * @returns {THREE.Group}
 */
export function buildRoofPillar({ height, radius }) {
    const group = new THREE.Group();
    group.name = 'roof_pillar';

    if (height <= 0 || radius <= 0) {
        console.warn('[RoofPillar] Некорректные параметры колонны.');
        return group;
    }

    const radialSegments = STADIUM_CONFIG.roof.pillarSegments;

    /* ─── Основной ствол ────────────────────────────────────────── */
    const trunkHeight = height - PILLAR_BASE_HEIGHT;

    if (trunkHeight > 0.1) {
        const trunkGeo = new THREE.CylinderGeometry(
            radius, radius,
            trunkHeight,
            radialSegments,
            1,
            false
        );
        const trunk = new THREE.Mesh(trunkGeo);
        trunk.position.y = PILLAR_BASE_HEIGHT + trunkHeight * 0.5;
        trunk.castShadow = true;
        trunk.receiveShadow = true;
        group.add(trunk);
    }

    /* ─── База ─────────────────────────────────────────────────── */
    const baseGeo = new THREE.CylinderGeometry(
        radius * PILLAR_BASE_SCALE_TOP,
        radius * PILLAR_BASE_SCALE_BOTTOM,
        PILLAR_BASE_HEIGHT,
        radialSegments,
        1,
        false
    );
    const base = new THREE.Mesh(baseGeo);
    base.position.y = PILLAR_BASE_HEIGHT * 0.5;
    base.castShadow = true;
    base.receiveShadow = true;
    group.add(base);

    /* ─── Капитель ─────────────────────────────────────────────── */
    const capGeo = new THREE.CylinderGeometry(
        radius * 1.5,
        radius * 1.3,
        0.18,
        radialSegments,
        1,
        false
    );
    const cap = new THREE.Mesh(capGeo);
    cap.position.y = height - 0.09;
    cap.castShadow = true;
    cap.receiveShadow = true;
    group.add(cap);

    return group;
}


/* ══════════════════════════════════════════════════════════════════════════
 *  § 5. КОЛЬЦЕВЫЕ РЁБРА ЖЁСТКОСТИ
 * ══════════════════════════════════════════════════════════════════════════ */

/**
 * Строит кольцо из рёбер жёсткости под крышей.
 *
 * @param {Object} opts
 * @param {number} opts.radiusX
 * @param {number} opts.radiusZ
 * @param {number} opts.y
 * @param {number} [opts.count=24]
 * @param {number} [opts.ribRadius=0.13]
 * @returns {THREE.Group}
 */
export function buildRoofRibRing({
    radiusX,
    radiusZ,
    y,
    count = ROOF_RIB_COUNT,
    ribRadius = ROOF_RIB_RADIUS,
}) {
    const group = new THREE.Group();
    group.name = 'roof_rib_ring';

    if (count < 8) {
        console.warn('[RoofRibRing] Минимум 8 рёбер.');
        return group;
    }

    /* Точки равномерно по длине дуги суперэллипса — тогда звенья рёбер
     * получаются одинаковой длины и в углах не «срезают» контур сильнее,
     * чем на прямых сторонах. */
    const shapePower = STADIUM_CONFIG.shape.power;
    const angles = superEllipseEvenAngles(count, radiusX, radiusZ, shapePower);

    const points = [];
    for (let i = 0; i < count; i++) {
        const pt = superEllipsePoint(angles[i], radiusX, radiusZ, shapePower);
        points.push({ x: pt.x, z: pt.z });
    }

    points.push({ x: points[0].x, z: points[0].z });

    const upAxis = new THREE.Vector3(0, 1, 0);

    for (let i = 0; i < count; i++) {
        const a = points[i];
        const b = points[i + 1];

        const dx = b.x - a.x;
        const dz = b.z - a.z;
        const len = Math.sqrt(dx * dx + dz * dz);

        if (len < 1e-4) continue;

        const geo = new THREE.CylinderGeometry(
            ribRadius, ribRadius, len, 6, 1, false
        );
        const mesh = new THREE.Mesh(geo);
        mesh.position.set(
            (a.x + b.x) * 0.5,
            y,
            (a.z + b.z) * 0.5
        );
        mesh.quaternion.setFromUnitVectors(
            upAxis,
            new THREE.Vector3(dx, 0, dz).normalize()
        );
        mesh.castShadow = true;
        mesh.receiveShadow = true;
        group.add(mesh);
    }

    return group;
}


/* ══════════════════════════════════════════════════════════════════════════
 *  § 6. ДИАГОНАЛЬНЫЕ ПОДКОСЫ
 * ══════════════════════════════════════════════════════════════════════════ */

/**
 * Строит диагональный подкос между двумя точками.
 *
 * @param {Object} opts
 * @param {THREE.Vector3} opts.from
 * @param {THREE.Vector3} opts.to
 * @param {number} [opts.radius=0.06]
 * @returns {THREE.Mesh|null}
 */
export function buildDiagonalBrace({ from, to, radius = 0.06 }) {
    const dx = to.x - from.x;
    const dy = to.y - from.y;
    const dz = to.z - from.z;
    const len = Math.sqrt(dx * dx + dy * dy + dz * dz);

    if (len < 1e-4) return null;

    const geo = new THREE.CylinderGeometry(radius, radius, len, 6, 1, false);
    const mesh = new THREE.Mesh(geo);
    mesh.position.set(
        (from.x + to.x) * 0.5,
        (from.y + to.y) * 0.5,
        (from.z + to.z) * 0.5
    );
    mesh.quaternion.setFromUnitVectors(
        new THREE.Vector3(0, 1, 0),
        new THREE.Vector3(dx, dy, dz).normalize()
    );
    mesh.castShadow = true;
    mesh.receiveShadow = true;
    return mesh;
}


/* ══════════════════════════════════════════════════════════════════════════
 *  § 7. МЕТРИКИ
 * ══════════════════════════════════════════════════════════════════════════ */

/**
 * Оценка сложности геометрии крыши.
 *
 * @returns {Object}
 */
export function estimateRoofComplexity() {
    const cfg = STADIUM_CONFIG.roof;
    const segments = STADIUM_CONFIG.performance.radialSegments;

    const ringVerts = 5 * (segments + 1);
    const ringTris = 4 * segments * 2;

    const strutsPerTruss = 2 + TRUSS_SEGMENTS * 2 + 2;
    const trussCount = cfg.pillarCount;

    const pillarParts = 3;
    const ribCount = ROOF_RIB_COUNT;

    return {
        roofRing: {
            vertices: ringVerts,
            triangles: ringTris,
        },
        trusses: {
            count: trussCount,
            strutsEach: strutsPerTruss,
            totalStruts: trussCount * strutsPerTruss,
        },
        pillars: {
            count: trussCount,
            partsEach: pillarParts,
            totalParts: trussCount * pillarParts,
        },
        ribs: {
            count: ribCount,
        },
        summary: {
            totalMeshes: 1 + trussCount * strutsPerTruss +
                         trussCount * pillarParts + ribCount,
            note: 'Фермы и колонны — это Group с внутренними мешами.',
        },
    };
}