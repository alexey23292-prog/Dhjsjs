/**
 * src/components/stadium/modules/FacadeModule.js
 *
 * ══════════════════════════════════════════════════════════════════════════
 *  МОДУЛЬ ВНЕШНЕГО ФАСАДА
 *
 *  ─── СОБИРАЕТ ────────────────────────────────────────────────────────────
 *    1. 72 вертикальных ребра (InstancedMesh) — «скелет» фасада
 *    2. 7 горизонтальных поясов — каждые 6 м по высоте
 *    3. Стеклянная оболочка между рёбрами
 *    4. Венчающий карниз — завершает вертикаль
 *    5. Дополнительно: нижний цоколь из тёмного бетона
 *
 *  ─── АРХИТЕКТУРНАЯ РОЛЬ ФАСАДА ───────────────────────────────────────────
 *    • Скрывает внутреннюю конструкцию трибун от взгляда снаружи
 *    • Формирует узнаваемый силуэт арены
 *    • Несёт стеклянные поверхности — связь интерьера и экстерьера
 *    • Даёт место для брендинга (в реальности — логотипы на карнизе)
 *
 *  ─── ЭТАЖИ ФАСАДА ────────────────────────────────────────────────────────
 *
 *        ┌──────────────────────┐  ← венчающий карниз (y = 40.8-42)
 *        │                      │
 *        │   стекло + рёбра     │  ← верхняя часть
 *        │   + пояса            │
 *        │   (y = 4-40)         │
 *        │                      │
 *        ├──────────────────────┤  ← последний пояс
 *        │                      │
 *        │   цоколь из бетона   │  ← основание (y = 0-4)
 *        │   (закрывает низ)    │
 *        │                      │
 *        └──────────────────────┘
 *        ────── земля ──────
 *
 *  ─── ПРОИЗВОДИТЕЛЬНОСТЬ ──────────────────────────────────────────────────
 *    • 72 ребра → 1 InstancedMesh (1 draw call)
 *    • 7 поясов → 7 отдельных Mesh с общей геометрией
 *    • Стекло → 1 Mesh
 *    • Карниз → 1 Mesh
 *    • Цоколь → 1 Mesh
 *    • Итого: ~11 draw calls на весь фасад
 * ══════════════════════════════════════════════════════════════════════════
 */

import * as THREE from 'three';
import { STADIUM_CONFIG, superEllipsePoint } from '../StadiumConfig.js';
import {
    buildFacadeRibGroup,
    buildFacadeBelts,
    buildFacadeGlass,
    buildCornice,
} from '../geometry/FacadeGeometry.js';
import {
    getSteel,
    getDarkSteel,
    getGlass,
    getConcrete,
    getDarkConcrete,
} from '../StadiumMaterials.js';


/* ══════════════════════════════════════════════════════════════════════════
 *  § 1. КОНСТАНТЫ
 * ══════════════════════════════════════════════════════════════════════════ */

/** Высота цоколя (основание фасада) — м. */
const PLINTH_HEIGHT = 4.0;

/** Толщина цоколя — м (ширина стенки наружу). */
const PLINTH_THICKNESS = 0.8;

/** Отступ цоколя внутрь от основной плоскости фасада — м. */
const PLINTH_INSET = 0.15;

/** Высота первой панели стекла над цоколем — м. */
const GLASS_START_Y = PLINTH_HEIGHT;

/** Высота последней панели стекла — м (до карниза). */
const GLASS_END_Y = STADIUM_CONFIG.facade.height -
                    STADIUM_CONFIG.facade.beltHeight * 2;


/* ══════════════════════════════════════════════════════════════════════════
 *  § 2. ЦОКОЛЬ (ОСНОВАНИЕ ФАСАДА)
 * ══════════════════════════════════════════════════════════════════════════ */

/**
 * Строит цоколь — нижнюю часть фасада от земли до первой панели стекла.
 *
 * ─── РОЛЬ ────────────────────────────────────────────────────────────────
 *   • Визуально «утяжеляет» здание снизу
 *   • Скрывает подсобные помещения у основания
 *   • Даёт «посадку» арены — без него здание кажется висящим в воздухе
 *
 * ─── ГЕОМЕТРИЯ ────────────────────────────────────────────────────────────
 *   Эллиптическая лента с четырьмя точками профиля:
 *     • Внутренняя вертикальная стенка
 *     • Верх (плоский)
 *     • Внешняя вертикальная стенка
 *     • Низ (по земле)
 *
 *   Отступ PLINTH_INSET делает цоколь чуть уже основной плоскости
 *   фасада — визуальный «разрыв» между цоколем и стеклом.
 *
 * @returns {THREE.Mesh}
 */
function buildPlinth() {
    const facade = STADIUM_CONFIG.facade;

    /* ─── Радиусы цоколя ──────────────────────────────────────── */
    const rX_outer = facade.radiusX - PLINTH_INSET;
    const rZ_outer = facade.radiusZ - PLINTH_INSET;
    const rX_inner = rX_outer - PLINTH_THICKNESS;
    const rZ_inner = rZ_outer - PLINTH_THICKNESS;

    const segments = STADIUM_CONFIG.performance.radialSegments;

    /* ─── Профиль цоколя ──────────────────────────────────────── */
    const profile = [
        { rx: rX_inner, rz: rZ_inner, y: 0                }, // внутр. низ
        { rx: rX_outer, rz: rZ_outer, y: 0                }, // внеш. низ
        { rx: rX_outer, rz: rZ_outer, y: PLINTH_HEIGHT    }, // внеш. верх
        { rx: rX_inner, rz: rZ_inner, y: PLINTH_HEIGHT    }, // внутр. верх
        { rx: rX_inner, rz: rZ_inner, y: 0                }, // замыкание
    ];

    const geo = buildEllipticalLoft(profile, segments);

    /* ─── Материал — тёмный бетон ─────────────────────────────── */
    const mat = getDarkConcrete();

    const mesh = new THREE.Mesh(geo, mat);
    mesh.name = 'facade_plinth';
    mesh.castShadow = true;
    mesh.receiveShadow = true;

    return mesh;
}


/* ══════════════════════════════════════════════════════════════════════════
 *  § 3. ВСПОМОГАТЕЛЬНАЯ ГЕОМЕТРИЯ
 * ══════════════════════════════════════════════════════════════════════════ */

/**
 * Универсальная развёртка профиля вокруг суперэллипса.
 *
 * Профиль — массив точек { rx, rz, y }, каждая из которых описывает
 * точку в радиальном сечении цоколя. Развёртка даёт полноценную
 * поверхность вращения.
 *
 * @param {Array<{rx, rz, y}>} profile
 * @param {number} segments
 * @returns {THREE.BufferGeometry}
 */
function buildEllipticalLoft(profile, segments) {
    const shapePower = STADIUM_CONFIG.shape.power;
    const ringCols = segments + 1;
    const profileLen = profile.length;
    const vertexCount = ringCols * profileLen;

    const positions = new Float32Array(vertexCount * 3);
    const uvs = new Float32Array(vertexCount * 2);

    let vIdx = 0;
    for (let p = 0; p < profileLen; p++) {
        const pt = profile[p];
        const v = p / (profileLen - 1);

        for (let i = 0; i < ringCols; i++) {
            const a = (i / segments) * Math.PI * 2;
            const sp = superEllipsePoint(a, pt.rx, pt.rz, shapePower);

            positions[vIdx * 3    ] = sp.x;
            positions[vIdx * 3 + 1] = pt.y;
            positions[vIdx * 3 + 2] = sp.z;

            uvs[vIdx * 2    ] = i / segments;
            uvs[vIdx * 2 + 1] = v;

            vIdx++;
        }
    }

    /* Индексы. */
    const quadCount = (profileLen - 1) * segments;
    const indices = new Uint32Array(quadCount * 6);

    let iIdx = 0;
    for (let p = 0; p < profileLen - 1; p++) {
        const rowA = p * ringCols;
        const rowB = (p + 1) * ringCols;

        for (let i = 0; i < segments; i++) {
            const a = rowA + i;
            const b = a + 1;
            const c = rowB + i;
            const d = c + 1;

            indices[iIdx++] = a;
            indices[iIdx++] = c;
            indices[iIdx++] = b;

            indices[iIdx++] = b;
            indices[iIdx++] = c;
            indices[iIdx++] = d;
        }
    }

    const geo = new THREE.BufferGeometry();
    geo.setAttribute('position', new THREE.BufferAttribute(positions, 3));
    geo.setAttribute('uv',       new THREE.BufferAttribute(uvs, 2));
    geo.setIndex(new THREE.BufferAttribute(indices, 1));
    geo.computeVertexNormals();
    geo.computeBoundingSphere();

    return geo;
}


/* ══════════════════════════════════════════════════════════════════════════
 *  § 4. ОТДЕЛЬНЫЕ СЛОИ ФАСАДА
 * ══════════════════════════════════════════════════════════════════════════ */

/**
 * Строит группу вертикальных рёбер.
 * Использует InstancedMesh из FacadeGeometry.
 *
 * @returns {THREE.InstancedMesh}
 */
function buildRibs() {
    const mat = getSteel();
    return buildFacadeRibGroup(mat);
}


/**
 * Строит группу горизонтальных поясов.
 *
 * @returns {THREE.Group}
 */
function buildBelts() {
    const mat = getDarkSteel();
    return buildFacadeBelts(mat);
}


/**
 * Строит стеклянную оболочку.
 *
 * @returns {THREE.Mesh}
 */
function buildGlassShell() {
    const mat = getGlass();
    return buildFacadeGlass(mat);
}


/**
 * Строит венчающий карниз.
 *
 * @returns {THREE.Mesh}
 */
function buildTopCornice() {
    const mat = getConcrete();
    return buildCornice(mat);
}


/* ══════════════════════════════════════════════════════════════════════════
 *  § 5. ПУБЛИЧНЫЙ API
 * ══════════════════════════════════════════════════════════════════════════ */

/**
 * Строит весь фасад стадиона.
 *
 * ─── ВОЗВРАЩАЕТ ───────────────────────────────────────────────────────────
 *   {
 *     group:        THREE.Group,        // весь фасад как один узел
 *     ribs:         THREE.InstancedMesh, // 72 ребра
 *     belts:        THREE.Group,        // 7 поясов
 *     glass:        THREE.Mesh,         // стекло
 *     cornice:      THREE.Mesh,         // карниз
 *     plinth:       THREE.Mesh,         // цоколь
 *     ribCount:     number,
 *     beltCount:    number,
 *   }
 *
 * @returns {Object}
 */
export function buildFacade() {
    const group = new THREE.Group();
    group.name = 'facade';

    /* ─── 1. Цоколь (основание) ─────────────────────────────── */
    const plinth = buildPlinth();
    group.add(plinth);

    /* ─── 2. Вертикальные рёбра ────────────────────────────── */
    const ribs = buildRibs();
    group.add(ribs);

    /* ─── 3. Горизонтальные пояса ──────────────────────────── */
    const belts = buildBelts();
    group.add(belts);

    /* ─── 4. Стеклянная оболочка ───────────────────────────── */
    const glass = buildGlassShell();
    group.add(glass);

    /* ─── 5. Венчающий карниз ──────────────────────────────── */
    const cornice = buildTopCornice();
    group.add(cornice);

    /* ─── Считаем метрики ──────────────────────────────────── */
    let beltCount = 0;
    belts.children.forEach(child => {
        if (child.isMesh) beltCount++;
    });

    const ribCount = STADIUM_CONFIG.facade.ribCount;

    return {
        group,
        ribs,
        belts,
        glass,
        cornice,
        plinth,
        ribCount,
        beltCount,
    };
}


/* ══════════════════════════════════════════════════════════════════════════
 *  § 6. УПРАВЛЕНИЕ
 * ══════════════════════════════════════════════════════════════════════════ */

/**
 * Переключает прозрачность стекла фасада.
 *
 * ─── ПРИМЕНЕНИЕ ───────────────────────────────────────────────────────────
 *   • День / ночь — стекло темнее ночью
 *   • Спецэффекты — «тонирование» всего фасада
 *   • Отладка — сделать стекло полупрозрачным для осмотра трибун
 *
 * @param {Object} facade — результат buildFacade()
 * @param {number} alpha  — новая прозрачность 0..1
 */
export function setFacadeGlassOpacity(facade, alpha) {
    if (!facade || !facade.glass) return;

    const mat = facade.glass.material;
    if (mat) {
        mat.opacity = Math.max(0, Math.min(1, alpha));
        mat.transparent = true;
        mat.needsUpdate = true;
    }
}


/**
 * Показывает или скрывает стеклянную оболочку.
 * Полезно для осмотра интерьера арены.
 *
 * @param {Object} facade — результат buildFacade()
 * @param {boolean} visible
 */
export function setFacadeGlassVisible(facade, visible) {
    if (!facade || !facade.glass) return;
    facade.glass.visible = visible;
}


/**
 * Красит вертикальные рёбра фасада в заданный цвет.
 * Использует InstancedMesh с instanceColor.
 *
 * @param {Object} facade — результат buildFacade()
 * @param {number} hex    — цвет в формате 0xRRGGBB
 */
export function tintFacadeRibs(facade, hex) {
    if (!facade || !facade.ribs) return;

    const mesh = facade.ribs;
    const count = mesh.count;

    const tmpColor = new THREE.Color(hex);
    const colors = new Float32Array(count * 3);

    for (let i = 0; i < count; i++) {
        colors[i * 3    ] = tmpColor.r;
        colors[i * 3 + 1] = tmpColor.g;
        colors[i * 3 + 2] = tmpColor.b;
    }

    mesh.instanceColor = new THREE.InstancedBufferAttribute(colors, 3);
    mesh.instanceColor.needsUpdate = true;
    mesh.material.needsUpdate = true;
}


/* ══════════════════════════════════════════════════════════════════════════
 *  § 7. МЕТРИКИ
 * ══════════════════════════════════════════════════════════════════════════ */

/**
 * Возвращает метрики модуля фасада.
 *
 * @param {Object} facade — результат buildFacade()
 * @returns {Object}
 */
export function getFacadeMetrics(facade) {
    if (!facade) {
        return { error: 'Фасад не построен. Вызовите buildFacade() сначала.' };
    }

    /* Обход дерева для подсчёта. */
    let totalMeshes = 0;
    let totalVerts = 0;
    let totalTris = 0;
    let instancedMeshes = 0;
    let instancedInstances = 0;

    facade.group.traverse(child => {
        if (!child.isMesh && !child.isInstancedMesh) return;

        totalMeshes++;

        const g = child.geometry;
        if (!g) return;

        const verts = g.attributes.position.count;
        const tris = g.index ? g.index.count / 3 : verts / 3;
        const instCount = child.isInstancedMesh ? child.count : 1;

        if (child.isInstancedMesh) {
            instancedMeshes++;
            instancedInstances += child.count;
        }

        totalVerts += verts * instCount;
        totalTris += tris * instCount;
    });

    const cfg = STADIUM_CONFIG.facade;

    return {
        /* Ключевые элементы. */
        ribCount: facade.ribCount,
        beltCount: facade.beltCount,

        /* Общая геометрия. */
        totalMeshes,
        totalVertices: totalVerts,
        totalTriangles: totalTris,

        /* Инстансинг. */
        instancedMeshes,
        instancedInstances,

        /* Параметры фасада. */
        radiusX: cfg.radiusX,
        radiusZ: cfg.radiusZ,
        height: cfg.height,

        /* Производительность. */
        estimatedDrawCalls: 1 + facade.beltCount + 1 + 1 + 1,
        /*             ребра ↑   пояса ↑   стекло ↑ карниз ↑ цоколь ↑ */

        /* Резюме. */
        summary: `Фасад: ${facade.ribCount} рёбер, ${facade.beltCount} поясов, ` +
                 `${cfg.height} м высоты.`,
    };
}