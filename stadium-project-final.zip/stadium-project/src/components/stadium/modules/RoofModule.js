/**
 * src/components/stadium/modules/RoofModule.js
 *
 * ══════════════════════════════════════════════════════════════════════════
 *  МОДУЛЬ КРЫШИ СТАДИОНА
 *
 *  ─── СОБИРАЕТ ────────────────────────────────────────────────────────────
 *    1. Кольцевая плита навеса (RoofTrussGeometry.buildRoofRing)
 *    2. 48 опорных колонн по фасаду
 *    3. 48 решётчатых ферм от колонн к центру
 *    4. Диагональные подкосы крест-накрест между колоннами
 *    5. Два кольцевых пояса рёбер жёсткости под плитой
 *    6. Каналы прожекторов в плите (для освещения)
 *    7. Такелажные балки — для обслуживания
 *    8. Сливные желоба по внешнему краю
 *
 *  ─── АРХИТЕКТУРНАЯ СХЕМА (вид сбоку) ─────────────────────────────────────
 *
 *                                      ╔═══════════════════════╗  ← плита
 *                                      ║  ◯  ◯  ◯  ◯  ◯  ◯  ◯  ║     (прожекторы)
 *                                      ╚═════╤═══════════╤═════╝
 *                                            │           │
 *                     ферма ════════════════>│           │<════ ферма
 *                                            │  ╳     ╳  │
 *                                            │     ╳     │
 *                                            │  ╳     ╳  │  ← подкосы
 *                                            │     ╳     │
 *                                            ●           ●  ← колонны
 *                                            │           │
 *                                            │           │
 *                                            ▼           ▼
 *                          ──────────── земля ────────────
 *
 *  ─── ПОРЯДОК СБОРКИ ──────────────────────────────────────────────────────
 *    1. Плита навеса (главный элемент)
 *    2. Опорные колонны (по фасаду)
 *    3. Фермы (опираются на колонны и держат плиту)
 *    4. Подкосы (связывают колонны)
 *    5. Кольцевые рёбра (усиливают плиту)
 *    6. Прожекторы (уже в плите)
 *    7. Такелаж (для обслуживания)
 *    8. Слив (по краю)
 *
 *  ─── ПРОИЗВОДИТЕЛЬНОСТЬ ──────────────────────────────────────────────────
 *    • Плита: 1 Extrude-геометрия
 *    • Колонны: 48 × 3 части = 144 меша
 *    • Фермы: 48 × ~28 struts = ~1350 мешей
 *    • Подкосы: 96 мешей
 *    • Рёбра: 84 меша
 *    • Прожекторы: 48 мешей (корпуса + линзы)
 *    • Такелаж: 12 × 4 = 48 мешей
 *    • Слив: 1 меш
 *    Итого: ~1800 мешей в иерархии. Реально рисуется ~50-100
 *    благодаря frustum culling.
 * ══════════════════════════════════════════════════════════════════════════
 */

import * as THREE from 'three';
import {
    STADIUM_CONFIG,
    superEllipsePoint,
    superEllipseFrame,
    superEllipseEvenAngles,
    getFloodlightContour,
} from '../StadiumConfig.js';
import {
    buildRoofRing,
    buildRoofTruss,
    buildRoofPillar,
    buildRoofRibRing,
    buildDiagonalBrace,
} from '../geometry/RoofTrussGeometry.js';
import {
    getSteel,
    getDarkSteel,
    getRoofTop,
    getConcrete,
    getDarkConcrete,
} from '../StadiumMaterials.js';


/* ══════════════════════════════════════════════════════════════════════════
 *  § 1. КОНСТАНТЫ
 * ══════════════════════════════════════════════════════════════════════════ */

/** Радиус диагональных подкосов между колоннами (м). */
const DIAGONAL_BRACE_RADIUS = 0.07;

/** Доля высоты колонны, на которой начинается подкос (снизу). */
const BRACE_LOWER_T = 0.35;

/** Доля высоты колонны, где заканчивается подкос (сверху). */
const BRACE_UPPER_T = 0.85;

/** Y-координата кольцевых рёбер жёсткости (под плитой). */
const RIB_RING_OFFSET_Y = -0.8;

/** Количество прожекторов в крыше — для их визуальных корпусов. */
const FLOODLIGHT_VISUAL_COUNT = 24;

/** Радиус чаши прожектора (м). */
const FLOODLIGHT_BOWL_RADIUS = 0.55;

/** Длина такелажной балки (м). */
const SERVICE_BEAM_LENGTH = 3.0;

/** Радиус такелажной балки (м). */
const SERVICE_BEAM_RADIUS = 0.10;

/** Количество такелажных узлов по кругу. */
const SERVICE_BEAM_COUNT = 12;

/** Высота желоба слива (м). */
const GUTTER_HEIGHT = 0.35;

/** Толщина желоба слива (м). */
const GUTTER_THICKNESS = 0.25;


/* ══════════════════════════════════════════════════════════════════════════
 *  § 2. ВСПОМОГАТЕЛЬНЫЕ ФУНКЦИИ
 * ══════════════════════════════════════════════════════════════════════════ */

/**
 * Точка на контуре (суперэллипс).
 *
 * @param {number} angle — параметр t
 * @param {number} rx
 * @param {number} rz
 * @returns {{x: number, z: number}}
 */
function contourPoint(angle, rx, rz) {
    return superEllipsePoint(angle, rx, rz, STADIUM_CONFIG.shape.power);
}


/**
 * Внешняя единичная нормаль контура (численная производная).
 *
 * @param {number} angle
 * @param {number} rx
 * @param {number} rz
 * @returns {{nx: number, nz: number}}
 */
function contourNormal(angle, rx, rz) {
    const { nx, nz } = superEllipseFrame(angle, rx, rz, STADIUM_CONFIG.shape.power);
    return { nx, nz };
}


/* ══════════════════════════════════════════════════════════════════════════
 *  § 3. КОЛЬЦЕВАЯ ПЛИТА НАВЕСА
 * ══════════════════════════════════════════════════════════════════════════ */

/**
 * Собирает кольцевую плиту навеса.
 *
 * ─── ИСПОЛЬЗУЕТ ───────────────────────────────────────────────────────────
 *   buildRoofRing() из RoofTrussGeometry — даёт монолитную
 *   Extrude-геометрию с наклоном внутрь чаши.
 *
 * ─── МАТЕРИАЛ ─────────────────────────────────────────────────────────────
 *   getRoofTop() — светлая сторона сверху, тёмная снизу (за счёт
 *   того что DoubleSide + естественное освещение).
 *
 * @returns {THREE.Mesh}
 */
function buildRoofPlate() {
    const geo = buildRoofRing();
    const mat = getRoofTop();

    const mesh = new THREE.Mesh(geo, mat);
    mesh.name = 'roof_plate';
    mesh.castShadow = true;
    mesh.receiveShadow = true;

    return mesh;
}


/* ══════════════════════════════════════════════════════════════════════════
 *  § 4. ОПОРНЫЕ КОЛОННЫ
 * ══════════════════════════════════════════════════════════════════════════ */

/**
 * Строит 48 опорных колонн по кольцу фасада.
 *
 * Каждая колонна — отдельная Group со стволом, базой и капителью.
 * Так как колонн всего 48 — не нужен InstancedMesh, накладные
 * расходы на Group минимальны.
 *
 * ─── ВОЗВРАЩАЕТ ───────────────────────────────────────────────────────────
 *   { group, positions } — группу и массив { x, z, angle } для
 *   дальнейшего использования (фермы, подкосы).
 *
 * @returns {{group: THREE.Group, positions: Array}}
 */
function buildPillars() {
    const group = new THREE.Group();
    group.name = 'roof_pillars';

    const cfg = STADIUM_CONFIG.roof;
    const facade = STADIUM_CONFIG.facade;

    const positions = [];

    /* Материал — светлая сталь. */
    const steelMat = getSteel();

    /* Колонны — равномерно по ДЛИНЕ ДУГИ контура фасада
     * (равные Δt дали бы разреженные прямые стороны и тесные углы). */
    const pillarAngles = superEllipseEvenAngles(
        cfg.pillarCount,
        facade.radiusX,
        facade.radiusZ,
        STADIUM_CONFIG.shape.power
    );

    for (let i = 0; i < cfg.pillarCount; i++) {
        const angle = pillarAngles[i];

        const { x, z } = contourPoint(
            angle,
            facade.radiusX,
            facade.radiusZ
        );

        /* Строим колонну через готовую функцию. */
        const pillar = buildRoofPillar({
            height: cfg.baseHeight,
            radius: cfg.pillarRadius,
        });

        /* Применяем материал ко всем мешам внутри колонны. */
        pillar.traverse(child => {
            if (child.isMesh) {
                child.material = steelMat;
            }
        });

        pillar.position.set(x, 0, z);
        group.add(pillar);

        positions.push({
            x, z,
            angle,
            index: i,
        });
    }

    return { group, positions };
}


/* ══════════════════════════════════════════════════════════════════════════
 *  § 5. РЕШЁТЧАТЫЕ ФЕРМЫ
 * ══════════════════════════════════════════════════════════════════════════ */

/**
 * Строит решётчатые фермы от опорных колонн к внутреннему краю крыши.
 *
 * ─── ГЕОМЕТРИЯ ────────────────────────────────────────────────────────────
 *   Каждая ферма идёт ОТ точки на контуре фасада (опорная колонна)
 *   ДО точки на внутреннем контуре крыши — при ТОМ ЖЕ параметре t.
 *
 *   У суперэллипса расстояние между контурами зависит от t
 *   (на коротких и длинных сторонах оно разное, в углах — по диагонали),
 *   поэтому длина и поворот считаются ДЛЯ КАЖДОЙ фермы отдельно.
 *
 * ─── ОРИЕНТАЦИЯ ───────────────────────────────────────────────────────────
 *   Ферма строится вдоль +X. Поворот rotation.y = φ переводит локальную
 *   +X в (cos φ, 0, −sin φ). Нужное направление — (dx, dz)/L от внешней
 *   точки к внутренней, откуда:
 *       cos φ = dx/L,  −sin φ = dz/L   →   φ = atan2(−dz, dx).
 *
 * @param {Array} pillarPositions
 * @returns {{group: THREE.Group, count: number}}
 */
function buildTrusses(pillarPositions) {
    const group = new THREE.Group();
    group.name = 'roof_trusses';

    const cfg = STADIUM_CONFIG.roof;
    const facade = STADIUM_CONFIG.facade;

    /* Высота установки — под нижней стороной крыши. */
    const trussY = cfg.baseHeight - cfg.thickness - 0.05;

    /* Материал. */
    const steelMat = getSteel();

    let built = 0;

    for (let i = 0; i < pillarPositions.length; i++) {
        const p = pillarPositions[i];

        /* Внешняя точка (колонна) и внутренняя точка при том же t. */
        const outerPt = contourPoint(p.angle, facade.radiusX, facade.radiusZ);
        const innerPt = contourPoint(p.angle, cfg.innerRadiusX, cfg.innerRadiusZ);

        const dx = innerPt.x - outerPt.x;
        const dz = innerPt.z - outerPt.z;
        const trussLength = Math.hypot(dx, dz);

        if (trussLength <= 0.5) {
            console.warn(
                '[RoofModule] Ферма слишком короткая — проверьте радиусы. ' +
                `Индекс: ${i}, длина: ${trussLength.toFixed(2)} м.`
            );
            continue;
        }

        /* Строим ферму нужной длины. */
        const truss = buildRoofTruss(trussLength);

        /* Применяем материал. */
        truss.traverse(child => {
            if (child.isMesh) {
                child.material = steelMat;
            }
        });

        /* Ориентация: локальная +X → направление к внутреннему контуру. */
        truss.position.set(outerPt.x, trussY, outerPt.z);
        truss.rotation.y = Math.atan2(-dz, dx);

        group.add(truss);
        built++;
    }

    return { group, count: built };
}


/* ══════════════════════════════════════════════════════════════════════════
 *  § 6. ДИАГОНАЛЬНЫЕ ПОДКОСЫ
 * ══════════════════════════════════════════════════════════════════════════ */

/**
 * Строит диагональные подкосы крест-накрест между соседними колоннами.
 *
 * ─── СХЕМА ────────────────────────────────────────────────────────────────
 *   Для каждой пары соседних колонн (i, i+1) — два подкоса:
 *     • Прямой:  (i, lower) → (i+1, upper)
 *     • Обратный: (i, upper) → (i+1, lower)
 *
 *   Результат — крестовая связь (Vierendeel), дающая максимальную
 *   жёсткость при минимальном расходе металла.
 *
 * @param {Array} pillarPositions
 * @returns {THREE.Group}
 */
function buildDiagonalBraces(pillarPositions) {
    const group = new THREE.Group();
    group.name = 'roof_braces';

    if (pillarPositions.length < 2) return group;

    const cfg = STADIUM_CONFIG.roof;

    const yLower = cfg.baseHeight * BRACE_LOWER_T;
    const yUpper = cfg.baseHeight * BRACE_UPPER_T;

    /* Материал. */
    const steelMat = getSteel();

    for (let i = 0; i < pillarPositions.length; i++) {
        const cur = pillarPositions[i];
        const next = pillarPositions[(i + 1) % pillarPositions.length];

        /* Прямой подкос. */
        const from1 = new THREE.Vector3(cur.x, yLower, cur.z);
        const to1 = new THREE.Vector3(next.x, yUpper, next.z);

        const brace1 = buildDiagonalBrace({
            from: from1,
            to: to1,
            radius: DIAGONAL_BRACE_RADIUS,
        });

        if (brace1) {
            brace1.material = steelMat;
            group.add(brace1);
        }

        /* Обратный подкос. */
        const from2 = new THREE.Vector3(cur.x, yUpper, cur.z);
        const to2 = new THREE.Vector3(next.x, yLower, next.z);

        const brace2 = buildDiagonalBrace({
            from: from2,
            to: to2,
            radius: DIAGONAL_BRACE_RADIUS,
        });

        if (brace2) {
            brace2.material = steelMat;
            group.add(brace2);
        }
    }

    return group;
}


/* ══════════════════════════════════════════════════════════════════════════
 *  § 7. КОЛЬЦЕВЫЕ РЁБРА ЖЁСТКОСТИ
 * ══════════════════════════════════════════════════════════════════════════ */

/**
 * Строит два кольцевых пояса рёбер жёсткости под плитой.
 *
 * ─── НАЗНАЧЕНИЕ ───────────────────────────────────────────────────────────
 *   Кольцевые рёбра связывают фермы поперёк, распределяя нагрузку
 *   и предотвращая независимые колебания отдельных ферм.
 *
 *   Два кольца (внутреннее и внешнее) образуют «сэндвич» — фиксируют
 *   фермы с двух сторон.
 *
 * @returns {THREE.Group}
 */
function buildRibRings() {
    const group = new THREE.Group();
    group.name = 'roof_rib_rings';

    const cfg = STADIUM_CONFIG.roof;
    const facade = STADIUM_CONFIG.facade;

    const yRibs = cfg.baseHeight - cfg.thickness + RIB_RING_OFFSET_Y;

    /* Материал — тёмная сталь. */
    const steelMat = getDarkSteel();

    /* ─── Внутреннее кольцо ─────────────────────────────────── */
    const innerRing = buildRoofRibRing({
        radiusX: cfg.innerRadiusX + 4.0,
        radiusZ: cfg.innerRadiusZ + 4.0,
        y: 0,
        count: 36,
        ribRadius: 0.18,
    });
    innerRing.traverse(child => {
        if (child.isMesh) child.material = steelMat;
    });
    innerRing.position.y = yRibs;
    group.add(innerRing);

    /* ─── Внешнее кольцо ────────────────────────────────────── */
    const outerRing = buildRoofRibRing({
        radiusX: facade.radiusX - 3.0,
        radiusZ: facade.radiusZ - 3.0,
        y: 0,
        count: 48,
        ribRadius: 0.20,
    });
    outerRing.traverse(child => {
        if (child.isMesh) child.material = steelMat;
    });
    outerRing.position.y = yRibs;
    group.add(outerRing);

    return group;
}


/* ══════════════════════════════════════════════════════════════════════════
 *  § 8. ВИЗУАЛЬНЫЕ ПРОЖЕКТОРЫ В ПЛИТЕ
 * ══════════════════════════════════════════════════════════════════════════ */

/**
 * Строит визуальные корпуса прожекторов, встроенные в плиту крыши.
 *
 * ─── ВАЖНО ────────────────────────────────────────────────────────────────
 *   Это ТОЛЬКО визуальные корпуса, без источников света.
 *   Сами источники (SpotLight) создаются в StadiumLighting.js.
 *
 *   Такой подход разделяет:
 *     • Визуал (RoofModule)
 *     • Освещение (StadiumLighting)
 *
 * @returns {THREE.Group}
 */
function buildFloodlightHousings() {
    const group = new THREE.Group();
    group.name = 'roof_floodlight_housings';

    const cfg = STADIUM_CONFIG.roof;

    /* Y-координата корпусов — над плитой. */
    const yBase = cfg.baseHeight + 0.6;

    /* Материал — тёмная сталь. */
    const housingMat = getDarkSteel();

    /* Контур установки прожекторов — середина плиты крыши. */
    const ring = getFloodlightContour();
    const ringAngles = superEllipseEvenAngles(
        FLOODLIGHT_VISUAL_COUNT, ring.rx, ring.rz, STADIUM_CONFIG.shape.power
    );

    /* Геометрия одной чаши прожектора — полусфера. */
    const bowlGeo = new THREE.SphereGeometry(
        FLOODLIGHT_BOWL_RADIUS,
        14,
        10,
        0, Math.PI * 2,
        0, Math.PI * 0.5
    );

    for (let i = 0; i < FLOODLIGHT_VISUAL_COUNT; i++) {
        const { x, z } = contourPoint(ringAngles[i], ring.rx, ring.rz);

        /* Корпус — полусфера, направленная вниз. */
        const bowl = new THREE.Mesh(bowlGeo, housingMat);
        bowl.position.set(x, yBase, z);
        bowl.rotation.x = Math.PI;   // переворачиваем вниз
        bowl.castShadow = true;
        bowl.receiveShadow = false;
        group.add(bowl);

        /* Подставка под корпус — цилиндр. */
        const standGeo = new THREE.CylinderGeometry(
            0.12, 0.15, 0.5, 10
        );
        const stand = new THREE.Mesh(standGeo, housingMat);
        stand.position.set(x, yBase + 0.55, z);
        stand.castShadow = true;
        group.add(stand);
    }

    return group;
}


/* ══════════════════════════════════════════════════════════════════════════
 *  § 9. ТАКЕЛАЖНЫЕ БАЛКИ (ДЛЯ ОБСЛУЖИВАНИЯ)
 * ══════════════════════════════════════════════════════════════════════════ */

/**
 * Строит такелажные балки под плитой — для обслуживания и монтажа.
 *
 * ─── НАЗНАЧЕНИЕ ───────────────────────────────────────────────────────────
 *   В реальных стадионах под крышей есть рельсы для монтажа
 *   прожекторов, акустики, камер. Мы симулируем это
 *   короткими балками-консолями.
 *
 * @returns {THREE.Group}
 */
function buildServiceBeams() {
    const group = new THREE.Group();
    group.name = 'roof_service_beams';

    const cfg = STADIUM_CONFIG.roof;

    /* Y-координата балок — под плитой. */
    const yBeam = cfg.baseHeight - cfg.thickness - 0.3;

    /* Материал. */
    const steelMat = getSteel();

    /* Геометрия одной балки. */
    const beamGeo = new THREE.CylinderGeometry(
        SERVICE_BEAM_RADIUS,
        SERVICE_BEAM_RADIUS,
        SERVICE_BEAM_LENGTH,
        6,
        1,
        false
    );

    /* Полуоси — средний контур между внутренним и внешним краем плиты. */
    const rx = (cfg.innerRadiusX + cfg.outerRadiusX) * 0.5;
    const rz = (cfg.innerRadiusZ + cfg.outerRadiusZ) * 0.5;

    const beamAngles = superEllipseEvenAngles(
        SERVICE_BEAM_COUNT, rx, rz, STADIUM_CONFIG.shape.power
    );

    for (let i = 0; i < SERVICE_BEAM_COUNT; i++) {
        const angle = beamAngles[i];

        const { x, z } = contourPoint(angle, rx, rz);

        /* Балка лежит вдоль радиального направления. */
        const beam = new THREE.Mesh(beamGeo, steelMat);

        /* Поворот: балка по умолчанию вдоль Y, разворачиваем в XZ. */
        beam.rotation.z = Math.PI * 0.5;

        /*
         * Балка — вдоль НОРМАЛИ к контуру (консоль). После rotation.z = π/2
         * ось цилиндра лежит вдоль локальной X; rotation.y = φ переводит
         * её в направление (cos φ, −sin φ) → φ = atan2(−nz, nx).
         */
        const { nx, nz } = contourNormal(angle, rx, rz);
        beam.rotation.y = Math.atan2(-nz, nx);

        beam.position.set(x, yBeam, z);
        beam.castShadow = true;
        beam.receiveShadow = false;

        group.add(beam);

        /* Небольшая люстра-подвес под балкой. */
        const hookGeo = new THREE.SphereGeometry(0.12, 8, 6);
        const hook = new THREE.Mesh(hookGeo, steelMat);
        hook.position.set(x, yBeam - 0.25, z);
        hook.castShadow = true;
        group.add(hook);
    }

    return group;
}


/* ══════════════════════════════════════════════════════════════════════════
 *  § 10. СЛИВНОЙ ЖЕЛОБ
 * ══════════════════════════════════════════════════════════════════════════ */

/**
 * Строит сливной желоб по внешнему краю крыши.
 *
 * ─── НАЗНАЧЕНИЕ ───────────────────────────────────────────────────────────
 *   В реальности собирает дождевую воду с навеса и направляет
 *   в водосточные трубы фасада.
 *
 *   Визуально — тонкая горизонтальная полоса по краю крыши,
 *   подчёркивающая её толщину.
 *
 * @returns {THREE.Mesh}
 */
function buildGutter() {
    const cfg = STADIUM_CONFIG.roof;
    const segments = STADIUM_CONFIG.performance.radialSegments;

    /* Радиусы желоба — точно по внешнему краю плиты. */
    const rx = cfg.outerRadiusX + 0.1;
    const rz = cfg.outerRadiusZ + 0.1;
    const rxInner = rx - GUTTER_THICKNESS;
    const rzInner = rz - GUTTER_THICKNESS;
    const shapePower = STADIUM_CONFIG.shape.power;

    /* Y-координата — под внешним краем. */
    const yBase = cfg.baseHeight - cfg.thickness - 0.5;

    /* ─── Профиль желоба ──────────────────────────────────────── */
    const profile = [
        { rx: rxInner, rz: rzInner, y: 0                    },
        { rx: rx,      rz: rz,      y: 0                    },
        { rx: rx,      rz: rz,      y: GUTTER_HEIGHT        },
        { rx: rxInner, rz: rzInner, y: GUTTER_HEIGHT        },
        { rx: rxInner, rz: rzInner, y: 0                    },  // замыкание
    ];

    const ringCols = segments + 1;
    const profileLen = profile.length;
    const vertexCount = ringCols * profileLen;

    const positions = new Float32Array(vertexCount * 3);
    const uvs = new Float32Array(vertexCount * 2);

    let vIdx = 0;
    for (let p = 0; p < profileLen; p++) {
        const pt = profile[p];
        const v = p / (profileLen - 1);

        for (let i = 0; i < ringCols; i++) {
            const a = (i / segments) * Math.PI * 2;
            const sp = superEllipsePoint(a, pt.rx, pt.rz, shapePower);

            positions[vIdx * 3    ] = sp.x;
            positions[vIdx * 3 + 1] = pt.y;
            positions[vIdx * 3 + 2] = sp.z;

            uvs[vIdx * 2    ] = i / segments;
            uvs[vIdx * 2 + 1] = v;

            vIdx++;
        }
    }

    const quadCount = (profileLen - 1) * segments;
    const indices = new Uint32Array(quadCount * 6);

    let iIdx = 0;
    for (let p = 0; p < profileLen - 1; p++) {
        const rowA = p * ringCols;
        const rowB = (p + 1) * ringCols;

        for (let i = 0; i < segments; i++) {
            const a = rowA + i;
            const b = a + 1;
            const c = rowB + i;
            const d = c + 1;

            indices[iIdx++] = a;
            indices[iIdx++] = c;
            indices[iIdx++] = b;

            indices[iIdx++] = b;
            indices[iIdx++] = c;
            indices[iIdx++] = d;
        }
    }

    const geo = new THREE.BufferGeometry();
    geo.setAttribute('position', new THREE.BufferAttribute(positions, 3));
    geo.setAttribute('uv',       new THREE.BufferAttribute(uvs, 2));
    geo.setIndex(new THREE.BufferAttribute(indices, 1));
    geo.computeVertexNormals();
    geo.computeBoundingSphere();

    /* Материал — тёмная сталь. */
    const mat = getDarkSteel();

    const mesh = new THREE.Mesh(geo, mat);
    mesh.name = 'roof_gutter';
    mesh.position.y = yBase;
    mesh.castShadow = true;
    mesh.receiveShadow = true;

    return mesh;
}


/* ══════════════════════════════════════════════════════════════════════════
 *  § 11. ПУБЛИЧНЫЙ API
 * ══════════════════════════════════════════════════════════════════════════ */

/**
 * Строит всю крышу стадиона.
 *
 * ─── ВОЗВРАЩАЕТ ───────────────────────────────────────────────────────────
 *   {
 *     group:              THREE.Group,   // вся крыша как один узел
 *     plate:              THREE.Mesh,    // кольцевая плита
 *     pillarsGroup:       THREE.Group,   // 48 колонн
 *     trussesGroup:       THREE.Group,   // 48 ферм
 *     bracesGroup:        THREE.Group,   // диагональные подкосы
 *     ribRings:           THREE.Group,   // кольцевые рёбра
 *     floodlightGroup:    THREE.Group,   // визуальные прожекторы
 *     serviceBeams:       THREE.Group,   // такелажные балки
 *     gutter:             THREE.Mesh,    // сливной желоб
 *     pillarCount:        number,
 *     trussCount:         number,
 *   }
 *
 * @returns {Object}
 */
export function buildRoof() {
    const group = new THREE.Group();
    group.name = 'roof';

    /* ─── 1. Кольцевая плита ────────────────────────────────── */
    const plate = buildRoofPlate();
    group.add(plate);

    /* ─── 2. Опорные колонны ────────────────────────────────── */
    const { group: pillarsGroup, positions: pillarPositions } =
        buildPillars();
    group.add(pillarsGroup);

    /* ─── 3. Решётчатые фермы ───────────────────────────────── */
    const { group: trussesGroup, count: trussCount } =
        buildTrusses(pillarPositions);
    group.add(trussesGroup);

    /* ─── 4. Диагональные подкосы ───────────────────────────── */
    const bracesGroup = buildDiagonalBraces(pillarPositions);
    group.add(bracesGroup);

    /* ─── 5. Кольцевые рёбра жёсткости ──────────────────────── */
    const ribRings = buildRibRings();
    group.add(ribRings);

    /* ─── 6. Визуальные прожекторы ─────────────────────────── */
    const floodlightGroup = buildFloodlightHousings();
    group.add(floodlightGroup);

    /* ─── 7. Такелажные балки ───────────────────────────────── */
    const serviceBeams = buildServiceBeams();
    group.add(serviceBeams);

    /* ─── 8. Сливной желоб ──────────────────────────────────── */
    const gutter = buildGutter();
    group.add(gutter);

    return {
        group,
        plate,
        pillarsGroup,
        trussesGroup,
        bracesGroup,
        ribRings,
        floodlightGroup,
        serviceBeams,
        gutter,
        pillarCount: pillarPositions.length,
        trussCount,
    };
}


/* ══════════════════════════════════════════════════════════════════════════
 *  § 12. МЕТРИКИ
 * ══════════════════════════════════════════════════════════════════════════ */

/**
 * Возвращает метрики модуля крыши.
 *
 * @param {Object} roof — результат buildRoof()
 * @returns {Object}
 */
export function getRoofMetrics(roof) {
    if (!roof) {
        return { error: 'Крыша не построена. Вызовите buildRoof() сначала.' };
    }

    let totalMeshes = 0;
    let totalVerts = 0;
    let totalTris = 0;
    let instancedCount = 0;

    /* Обходим всё дерево крыши и считаем. */
    roof.group.traverse(child => {
        if (!child.isMesh && !child.isInstancedMesh) return;

        totalMeshes++;

        const g = child.geometry;
        if (!g) return;

        const verts = g.attributes.position.count;
        const tris = g.index ? g.index.count / 3 : verts / 3;

        const instCount = child.isInstancedMesh ? child.count : 1;
        if (child.isInstancedMesh) instancedCount += child.count;

        totalVerts += verts * instCount;
        totalTris += tris * instCount;
    });

    return {
        /* Верхнеуровневая статистика. */
        pillarCount: roof.pillarCount,
        trussCount: roof.trussCount,

        /* Геометрия. */
        totalMeshes,
        totalVertices: totalVerts,
        totalTriangles: totalTris,
        instancedElements: instancedCount,

        /* Компоненты. */
        components: {
            plate: `Кольцевая плита навеса`,
            pillars: `${roof.pillarCount} опорных колонн`,
            trusses: `${roof.trussCount} решётчатых ферм`,
            braces: `Крестовые подкосы между колоннами`,
            ribRings: `2 кольцевых пояса рёбер жёсткости`,
            floodlights: `${FLOODLIGHT_VISUAL_COUNT} визуальных прожекторов`,
            serviceBeams: `${SERVICE_BEAM_COUNT} такелажных балок`,
            gutter: `Сливной желоб по краю`,
        },

        /* Резюме. */
        summary:
            `Крыша: ${roof.pillarCount} колонн, ${roof.trussCount} ферм, ` +
            `${FLOODLIGHT_VISUAL_COUNT} прожекторов, ` +
            `${SERVICE_BEAM_COUNT} такелажных балок.`,
    };
}