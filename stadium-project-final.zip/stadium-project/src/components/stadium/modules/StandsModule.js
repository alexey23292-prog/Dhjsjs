/**
 * src/components/stadium/modules/StandsModule.js
 *
 * ══════════════════════════════════════════════════════════════════════════
 *  МОДУЛЬ ТРИБУН
 *
 *  ─── СОБИРАЕТ ────────────────────────────────────────────────────────────
 *    1. Геометрия всех ярусов (buildTierGeometry из BowlGeometry)
 *    2. ~86 000 зрительских мест одним InstancedMesh
 *    3. Проходы (азимутальные щели) между секторами
 *    4. Разделительные пояса между ярусами
 *
 *  ─── ПРОИЗВОДИТЕЛЬНОСТЬ ──────────────────────────────────────────────────
 *    Дравим места не как 86 000 отдельных Mesh-объектов,
 *    а как ОДИН InstancedMesh:
 *      • 86 000 мешей = 86 000 draw calls = ~4 секунды на кадр
 *      • 1 InstancedMesh = 1 draw call = ~2 миллисекунды на кадр
 *    Разница — в 2 000 раз.
 *
 *  ─── ОРИЕНТАЦИЯ МЕСТ ─────────────────────────────────────────────────────
 *    Каждое место поворачивается вокруг Y по нормали к контуру
 *    суперэллипса (seat.rotationY). Результат: на длинных и коротких
 *    сторонах места стоят параллельно полю, в углах — плавно
 *    разворачиваются вместе с контуром.
 *
 *  ─── КЛАСТЕРИЗАЦИЯ ЦВЕТОВ ────────────────────────────────────────────────
 *    Цвета мест не случайные, а сгруппированные — как настоящие
 *    трибуны, где сектора выкрашены в свои оттенки. Это делается
 *    через палитру + функцию распределения индексов.
 * ══════════════════════════════════════════════════════════════════════════
 */

import * as THREE from 'three';
import {
    STADIUM_CONFIG,
    superEllipsePoint,
    superEllipseFrame,
    superEllipsePerimeter,
    superEllipseAngleAtFraction,
    superEllipseFractionAtAngle,
    getAisleAngles,
} from '../StadiumConfig.js';
import { buildTierGeometry } from '../geometry/BowlGeometry.js';
import { getConcrete, createSeatMaterial } from '../StadiumMaterials.js';


/* ══════════════════════════════════════════════════════════════════════════
 *  § 1. КОНСТАНТЫ
 * ══════════════════════════════════════════════════════════════════════════ */

/** Высота сиденья над ступенью (м). */
const SEAT_HEIGHT_OFFSET = 0.02;

/** Отступ сиденья от края ступени назад (м). */
const SEAT_BACK_OFFSET = 0.15;

/** Параметры геометрии одного сиденья. */
const SEAT_GEO = Object.freeze({
    width: 0.42,          // ширина «сидушки»
    depth: 0.40,          // глубина «сидушки»
    seatHeight: 0.06,     // толщина «сидушки»
    backHeight: 0.42,     // высота спинки
    backThickness: 0.06,  // толщина спинки
});

/** Ширина прохода вокруг арены (в метрах). */
const AISLE_WIDTH_METERS = 1.8;

/** Ширина одного прохода между рядами (в метрах). */
const CROSS_AISLE_WIDTH_METERS = 1.2;

/** Через каждые N рядов делать поперечный проход. */
const CROSS_AISLE_EVERY_ROWS = 8;


/* ══════════════════════════════════════════════════════════════════════════
 *  § 2. ГЕОМЕТРИЯ ОДНОГО СИДЕНЬЯ
 * ══════════════════════════════════════════════════════════════════════════ */

/**
 * Строит геометрию одного зрительского места.
 *
 * ─── КОНСТРУКЦИЯ ──────────────────────────────────────────────────────────
 *   Включает две части:
 *     1. «Сидушка» — горизонтальная плита
 *     2. «Спинка» — вертикальная плита
 *
 *   Обе части — BoxGeometry, объединённые в одну BufferGeometry
 *   через ручной merge. Это позволяет InstancedMesh работать
 *   с одним объектом вместо двух.
 *
 *   Начало координат — центр сиденья на уровне ступени (y = 0).
 *   Место «смотрит» в направлении −Z (стандартный forward в Three.js).
 *
 * ─── СХЕМА В РАЗРЕЗЕ ──────────────────────────────────────────────────────
 *
 *        ┌─┐  ← спинка (высота backHeight)
 *        │ │
 *        │ │
 *        └─┘
 *      ┌────┐  ← сидушка (толщина seatHeight)
 *      └────┘
 *      ◄───► depth
 *
 * @returns {THREE.BufferGeometry}
 */
function buildSeatGeometry() {
    const {
        width, depth,
        seatHeight, backHeight, backThickness,
    } = SEAT_GEO;

    /* ─── «Сидушка» ────────────────────────────────────────────── */
    const baseGeo = new THREE.BoxGeometry(width, seatHeight, depth);

    /* Разворачиваем сидушку в локальных координатах:
     * центр сиденья — в начале координат, сиденье чуть смещено вперёд. */
    baseGeo.translate(0, seatHeight * 0.5, SEAT_BACK_OFFSET);

    /* ─── «Спинка» ─────────────────────────────────────────────── */
    const backGeo = new THREE.BoxGeometry(width, backHeight, backThickness);

    /* Спинка стоит за «сидушкой», чуть приподнята. */
    backGeo.translate(
        0,
        backHeight * 0.5 + seatHeight,
        SEAT_BACK_OFFSET + depth * 0.5 - backThickness * 0.5
    );

    /* ─── Объединение в одну геометрию ────────────────────────── */
    const merged = mergeGeometries([baseGeo, backGeo]);

    /* Освобождаем исходные. */
    baseGeo.dispose();
    backGeo.dispose();

    return merged;
}


/**
 * Простой merge двух или более BufferGeometry.
 * Поддерживает только позиции и нормали — нам больше не нужно.
 *
 * @param {THREE.BufferGeometry[]} geometries
 * @returns {THREE.BufferGeometry}
 */
function mergeGeometries(geometries) {
    let totalVerts = 0;
    let totalIndices = 0;

    for (const g of geometries) {
        totalVerts += g.attributes.position.count;
        totalIndices += g.index.count;
    }

    const positions = new Float32Array(totalVerts * 3);
    const normals   = new Float32Array(totalVerts * 3);
    const uvs       = new Float32Array(totalVerts * 2);
    const indices   = new Uint32Array(totalIndices);

    let vOff = 0;   // смещение по вершинам
    let iOff = 0;   // смещение по индексам

    for (const g of geometries) {
        const p = g.attributes.position.array;
        const n = g.attributes.normal.array;
        const uv = g.attributes.uv ? g.attributes.uv.array : null;

        positions.set(p, vOff * 3);
        normals.set(n, vOff * 3);
        if (uv) {
            uvs.set(uv, vOff * 2);
        }

        const srcIndices = g.index.array;
        for (let i = 0; i < srcIndices.length; i++) {
            indices[iOff + i] = srcIndices[i] + vOff;
        }

        vOff += g.attributes.position.count;
        iOff += srcIndices.length;
    }

    const geo = new THREE.BufferGeometry();
    geo.setAttribute('position', new THREE.BufferAttribute(positions, 3));
    geo.setAttribute('normal',   new THREE.BufferAttribute(normals, 3));
    geo.setAttribute('uv',       new THREE.BufferAttribute(uvs, 2));
    geo.setIndex(new THREE.BufferAttribute(indices, 1));

    return geo;
}


/* ══════════════════════════════════════════════════════════════════════════
 *  § 3. ВЫЧИСЛЕНИЕ ПОЗИЦИЙ МЕСТ
 * ══════════════════════════════════════════════════════════════════════════ */

/**
 * Вычисляет все позиции мест для одного яруса.
 *
 * ─── АЛГОРИТМ ─────────────────────────────────────────────────────────────
 *   Для каждого ряда яруса:
 *     1. Определяем средний радиус эллипса
 *     2. Вычисляем периметр суперэллипса (численно)
 *     3. Делим на ширину места → количество мест в ряду
 *     4. Идём по длине дуги от 0 до периметра, пропуская азимутальные проходы
 *
 * ─── УЧЁТ ПРОХОДОВ ────────────────────────────────────────────────────────
 *   Проходы — это «щели» между секторами. Ширина щели — AISLE_WIDTH_METERS.
 *   На каждом проходе места не ставятся — там лестница.
 *
 * ─── ПОПЕРЕЧНЫЕ ПРОХОДЫ ───────────────────────────────────────────────────
 *   Каждые CROSS_AISLE_EVERY_ROWS рядов оставляем ряд без мест —
 *   это поперечный проход для эвакуации.
 *
 * @param {Object} tier — объект яруса
 * @param {number} tierIndex — индекс яруса (для кластеризации)
 * @returns {Array<{x, y, z, angle, paletteIndex}>}
 */
function computeTierSeatPositions(tier, tierIndex) {
    const { row, infrastructure } = STADIUM_CONFIG;

    const rows = tier.rows;
    const depth = row.depth;
    const height = row.height;
    const seatW = row.seatWidth;
    const aisleCount = infrastructure.aisleCount;

    const seats = [];

    /* ─── Азимутальные проходы ─────────────────────────────────── */
    /* Параметры t осей проходов — те же, что у лестниц в
     * InfrastructureModule (единый источник — getAisleAngles). */
    const aisleAngles = getAisleAngles();
    const shapePower = STADIUM_CONFIG.shape.power;

    /* ─── Идём по рядам ────────────────────────────────────────── */
    for (let r = 0; r < rows; r++) {
        /* Поперечный проход: пропускаем этот ряд. */
        if (r > 0 && r % CROSS_AISLE_EVERY_ROWS === 0) {
            continue;
        }

        /* Радиус текущего ряда. */
        const rx = tier.startRadiusX + (r + 0.5) * depth;
        const rz = tier.startRadiusZ + (r + 0.5) * depth;

        /* Высота ряда (центр сиденья). */
        const y = tier.baseY + (r + 1) * height + SEAT_HEIGHT_OFFSET;

        /* ─── Количество мест в ряду ─────────────────────────── */
        /* Периметр суперэллипса — численно (длина дуги). */
        const perimeter = superEllipsePerimeter(rx, rz, shapePower);

        const totalSlots = Math.floor(perimeter / seatW);
        if (totalSlots < 8) continue;   // слишком маленький ряд

        /* ─── Проходы этого ряда в долях периметра ────────────── */
        /* Ось прохода (параметр t) → доля длины дуги ЭТОГО ряда. */
        const aisleFractions = aisleAngles.map(
            t => superEllipseFractionAtAngle(t, rx, rz, shapePower)
        );
        const aisleHalfFraction = (AISLE_WIDTH_METERS * 0.5) / perimeter;

        /* ─── Расставляем места ──────────────────────────────── */
        /* Места идут РАВНОМЕРНО ПО ДЛИНЕ ДУГИ: на прямых сторонах ряд
         * идёт прямо с шагом seatW, а не «по дуге» с шагом по углу. */
        for (let s = 0; s < totalSlots; s++) {
            const fraction = s / totalSlots;

            /* Проверяем, попадает ли место в азимутальный проход. */
            if (isFractionInAnyAisle(fraction, aisleFractions, aisleHalfFraction)) {
                continue;
            }

            /* Параметр t, соответствующий этой доле длины дуги. */
            const angle = superEllipseAngleAtFraction(fraction, rx, rz, shapePower);

            const { x, z } = superEllipsePoint(angle, rx, rz, shapePower);

            /* Поворот вокруг Y: локальная +Z смотрит по ВНУТРЕННЕЙ нормали
             * (к полю). Раньше было «на центр арены» (lookAt) — для
             * суперэллипса на прямых сторонах это давало бы веер. */
            const frame = superEllipseFrame(angle, rx, rz, shapePower);
            const rotationY = Math.atan2(-frame.nx, -frame.nz);

            /* ─── Индекс палитры — кластеризация ─────────────── */
            const paletteIndex = computePaletteIndex(
                r, s, tierIndex, totalSlots
            );

            seats.push({
                x, y, z,
                angle,
                rotationY,
                paletteIndex,
            });
        }
    }

    return seats;
}


/**
 * Проверяет, попадает ли место в один из азимутальных проходов.
 * Всё считается в долях периметра ряда (0..1) — то есть в метрах
 * вдоль контура, а не в «угле», который у суперэллипса неравномерен.
 *
 * @param {number} fraction — положение места (доля периметра, 0..1)
 * @param {number[]} aisleFractions — центры проходов (доли периметра)
 * @param {number} halfFraction — половина ширины прохода (доля периметра)
 * @returns {boolean}
 */
function isFractionInAnyAisle(fraction, aisleFractions, halfFraction) {
    for (let i = 0; i < aisleFractions.length; i++) {
        let diff = fraction - aisleFractions[i];

        /* Нормализуем разницу в диапазон [−0.5, 0.5]. */
        while (diff >  0.5) diff -= 1;
        while (diff < -0.5) diff += 1;

        if (Math.abs(diff) < halfFraction) {
            return true;
        }
    }
    return false;
}


/**
 * Вычисляет индекс в палитре для конкретного места.
 *
 * ─── ЛОГИКА КЛАСТЕРИЗАЦИИ ────────────────────────────────────────────────
 *   Чтобы цвета выглядели как настоящие сектора стадиона,
 *   а не случайный шум, используем три измерения:
 *     • ряд (r)
 *     • позиция в ряду (s)
 *     • ярус (tierIndex)
 *
 *   Каждая комбинация даёт свой индекс в палитре.
 *   Частота чередования настроена так, чтобы на трибуне было
 *   ~8-12 крупных цветовых пятен.
 *
 * @param {number} r — номер ряда
 * @param {number} s — номер места в ряду
 * @param {number} tierIndex — индекс яруса
 * @param {number} totalSlots — всего мест в этом ряду
 * @returns {number} — индекс в STADIUM_CONFIG.seatPalette
 */
function computePaletteIndex(r, s, tierIndex, totalSlots) {
    const palette = STADIUM_CONFIG.seatPalette;
    const N = palette.length;

    /* Кластеры по сектору (азимут). */
    const sectorIndex = Math.floor(s / 20);   // каждые 20 мест — новая группа

    /* Кластеры по вертикали (ряды). */
    const rowCluster = Math.floor(r / 6);     // каждые 6 рядов — новая группа

    /* Примешиваем ярус. */
    const tierMix = tierIndex * 3;

    /* Формула: комбинация с простыми коэффициентами. */
    const idx = (
        sectorIndex * 3 +
        rowCluster * 5 +
        tierMix * 7
    ) % N;

    return idx;
}


/* ══════════════════════════════════════════════════════════════════════════
 *  § 4. INSTANCED MESH ДЛЯ ВСЕХ МЕСТ
 * ══════════════════════════════════════════════════════════════════════════ */

/**
 * Строит единый InstancedMesh со ВСЕМИ зрительскими местами.
 *
 * ─── ПРОИЗВОДИТЕЛЬНОСТЬ ──────────────────────────────────────────────────
 *   • 86 000 мест = 1 draw call
 *   • Матрица трансформации — 64 байта × 86 000 = ~5.5 МБ
 *   • Цвета инстансов — 12 байт × 86 000 = ~1 МБ
 *   • Итого ~6.5 МБ VRAM на все места
 *
 * ─── ОРИЕНТАЦИЯ ──────────────────────────────────────────────────────────
 *   Каждое место поворачивается вокруг Y на seat.rotationY — так, чтобы
 *   его локальная ось +Z смотрела по внутренней нормали контура
 *   (как и раньше смотрела на центр арены, но теперь корректно и на
 *   прямых сторонах).
 *
 * @param {Array} allSeatPositions — объединённый массив мест со всех ярусов
 * @returns {THREE.InstancedMesh}
 */
function buildSeatsInstancedMesh(allSeatPositions) {
    const count = allSeatPositions.length;

    if (count === 0) {
        console.warn('[Stands] Нет мест для отрисовки.');
        return null;
    }

    const geometry = buildSeatGeometry();
    const material = createSeatMaterial();

    const mesh = new THREE.InstancedMesh(geometry, material, count);
    mesh.name = 'stadium_seats';
    mesh.castShadow = false;      // критично — 86 000 × shadow map = смерть FPS
    mesh.receiveShadow = false;   // тоже не нужно
    mesh.frustumCulled = false;   // bounding sphere покрывает всю арену

    /* ─── Матрица трансформации ──────────────────────────────── */
    const dummy = new THREE.Object3D();

    /* ─── Цвета инстансов ────────────────────────────────────── */
    const palette = STADIUM_CONFIG.seatPalette;
    const colors = new Float32Array(count * 3);
    const tmpColor = new THREE.Color();

    /* ─── Заполняем ──────────────────────────────────────────── */
    for (let i = 0; i < count; i++) {
        const seat = allSeatPositions[i];

        /* ─── Ориентация: по нормали к контуру ───────────────── */
        dummy.rotation.set(0, seat.rotationY, 0);

        /* ─── Позиция и масштаб ──────────────────────────────── */
        dummy.position.set(seat.x, seat.y, seat.z);
        dummy.scale.set(1, 1, 1);

        /* ─── Применяем трансформ ────────────────────────────── */
        dummy.updateMatrix();
        mesh.setMatrixAt(i, dummy.matrix);

        /* ─── Цвет из палитры ─────────────────────────────────── */
        const c = palette[seat.paletteIndex];
        tmpColor.setHex(c);

        colors[i * 3    ] = tmpColor.r;
        colors[i * 3 + 1] = tmpColor.g;
        colors[i * 3 + 2] = tmpColor.b;
    }

    mesh.instanceMatrix.needsUpdate = true;
    mesh.instanceColor = new THREE.InstancedBufferAttribute(colors, 3);
    mesh.instanceColor.needsUpdate = true;

    return mesh;
}


/* ══════════════════════════════════════════════════════════════════════════
 *  § 5. ПУБЛИЧНЫЙ API
 * ══════════════════════════════════════════════════════════════════════════ */

/**
 * Строит модуль трибун целиком: геометрию ярусов + все места.
 *
 * ─── ЧТО ВОЗВРАЩАЕТСЯ ────────────────────────────────────────────────────
 *   {
 *     group:          THREE.Group,       // вся трибуна как единый объект
 *     tierMeshes:     THREE.Mesh[],      // отдельные меши ярусов
 *     seatsMesh:      InstancedMesh,     // все места
 *     totalSeats:     number,            // сколько мест
 *     tierStats:      Array<Object>,     // статистика по ярусам
 *     drawCalls:      number,            // сколько draw calls (для метрик)
 *   }
 *
 * ─── СТРУКТУРА ГРУППЫ ────────────────────────────────────────────────────
 *   Group «stands»
 *     ├── tier_lower_body           (Mesh)
 *     ├── tier_middle_body          (Mesh)
 *     ├── tier_upper_body           (Mesh)
 *     └── stadium_seats             (InstancedMesh)
 *
 * @returns {Object}
 */
export function buildStands() {
    const group = new THREE.Group();
    group.name = 'stands';

    const tierMeshes = [];
    const tierStats = [];
    const allSeatPositions = [];

    const concreteMat = getConcrete();

    /* ─── 1. Строим геометрию каждого яруса ─────────────────── */
    for (let ti = 0; ti < STADIUM_CONFIG.tiers.length; ti++) {
        const tier = STADIUM_CONFIG.tiers[ti];

        /* Геометрия яруса — бетонные ступени. */
        const geo = buildTierGeometry(tier);
        const mesh = new THREE.Mesh(geo, concreteMat);
        mesh.name = `tier_${tier.id}_body`;
        mesh.castShadow = true;
        mesh.receiveShadow = true;
        group.add(mesh);
        tierMeshes.push(mesh);

        /* ─── 2. Вычисляем места для этого яруса ──────────────── */
        const tierSeats = computeTierSeatPositions(tier, ti);

        tierStats.push({
            id: tier.id,
            name: tier.name,
            rows: tier.rows,
            seats: tierSeats.length,
        });

        /* ─── 3. Добавляем в общий массив ─────────────────────── */
        for (let i = 0; i < tierSeats.length; i++) {
            allSeatPositions.push(tierSeats[i]);
        }
    }

    /* ─── 4. Строим общий InstancedMesh мест ───────────────── */
    const seatsMesh = buildSeatsInstancedMesh(allSeatPositions);
    if (seatsMesh) {
        group.add(seatsMesh);
    }

    /* ─── Итоги ─────────────────────────────────────────────── */
    const totalSeats = allSeatPositions.length;
    const drawCalls = tierMeshes.length + (seatsMesh ? 1 : 0);

    return {
        group,
        tierMeshes,
        seatsMesh,
        totalSeats,
        tierStats,
        drawCalls,
        seatPositions: allSeatPositions,
    };
}


/* ══════════════════════════════════════════════════════════════════════════
 *  § 6. МЕТРИКИ
 * ══════════════════════════════════════════════════════════════════════════ */

/**
 * Возвращает метрики модуля трибун для отладки и профилирования.
 *
 * @param {Object} stands — результат buildStands()
 * @returns {Object}
 */
export function getStandsMetrics(stands) {
    if (!stands) {
        return {
            error: 'Stands не построены. Вызовите buildStands() сначала.'
        };
    }

    /* Считаем общее количество вершин в геометрии ярусов. */
    let totalVerts = 0;
    let totalTris = 0;

    for (const mesh of stands.tierMeshes) {
        const g = mesh.geometry;
        if (!g) continue;

        totalVerts += g.attributes.position.count;
        totalTris += g.index ? g.index.count / 3 : 0;
    }

    /* Геометрия мест — только одна, потому что InstancedMesh. */
    if (stands.seatsMesh) {
        const g = stands.seatsMesh.geometry;
        if (g) {
            totalVerts += g.attributes.position.count;
            totalTris += g.index ? g.index.count / 3 : 0;
        }
    }

    /* Размер матриц инстансов. */
    const seatMatrixBytes = stands.totalSeats * 64;
    const seatColorBytes   = stands.totalSeats * 12;
    const seatVRAM         = (seatMatrixBytes + seatColorBytes) / 1024 / 1024;

    return {
        /* Ярусов. */
        tierCount: stands.tierStats.length,
        tiers: stands.tierStats,

        /* Мест. */
        totalSeats: stands.totalSeats,

        /* Геометрия. */
        totalVertices: totalVerts,
        totalTriangles: totalTris,

        /* Память. */
        seatMatrixMB: seatMatrixBytes / 1024 / 1024,
        seatColorMB:  seatColorBytes / 1024 / 1024,
        seatTotalMB:  seatVRAM,

        /* Производительность. */
        drawCalls: stands.drawCalls,

        /* Оценка FPS при 60 кадрах — метрика нагрузки. */
        note: stands.drawCalls === 4
            ? '✓ Оптимально: 4 draw calls на все трибуны.'
            : `⚠ Draw calls: ${stands.drawCalls}. Проверьте размеры.`,
    };
}