/**
 * src/components/stadium/modules/GoalModule.js
 *
 * ══════════════════════════════════════════════════════════════════════════
 *  ФУТБОЛЬНЫЕ ВОРОТА FIFA (из football_goal_viewer.html) — 2 шт. на поле
 *
 *  Модель ворот в исходнике процедурная (не файл меша), поэтому она
 *  перенесена кодом: рамка (штанги + перекладина), задние стойки с
 *  растяжками, сетка (3 панели + верх). Физика эластичной сетки
 *  (createSim) перенесена БЕЗ изменений.
 *
 *  ─── РАЗМЕРЫ ─────────────────────────────────────────────────────────────
 *    Проём 7.32 × 2.44 м, штанга Ø 0.12 м, глубина сетки 2.0 м,
 *    задние стойки на 4.0 м за линией ворот.
 *
 *  ─── ЛОКАЛЬНЫЕ КООРДИНАТЫ ВОРОТ ───────────────────────────────────────────
 *    Начало — центр линии ворот на земле. +Z — в поле, −Z — сетка.
 *    В стадионе ворота повёрнуты так, что +Z смотрит на центр поля.
 *
 *  ─── ФИЗИКА СЕТКИ ────────────────────────────────────────────────────────
 *    По умолчанию выключена (сетка статична, ничего не считается).
 *    createStadiumGoals({ netPhysics: true }) + goal.launchBall(...) —
 *    сетка реагирует на мяч; шаг считается только пока goal.active.
 * ══════════════════════════════════════════════════════════════════════════
 */

import * as THREE from 'three';


/* ══════════════════════════════════════════════════════════════════════════
 *  § 1. СИМУЛЯЦИЯ СЕТКИ И МЯЧА (из football_goal_viewer.html без изменений)
 * ══════════════════════════════════════════════════════════════════════════ */

function createSim(cfg){
  const FX=cfg.FX, FY=cfg.FY, DEPTH=cfg.DEPTH, PR=cfg.POST_R, RB=cfg.R_BALL, MB=cfg.M_BALL;
  const REAR_Z=-(DEPTH+2.0), REAR_H=3.0, CORD_Y=REAR_H-0.03;
  const NX=60, NY=20, NZ=16;
  const dxs=2*FX/NX, dys=FY/NY, dzs=DEPTH/NZ;
  const NODE_M=0.02, G_NET=1.0, G=9.81, DAMP=0.98;
  const K_STRUCT=0.06, K_SHEAR=0.03, K_BEND=0.02, COMPRESS=0.25, ITER=4;
  const MEM_BASE=70, MEM_GROUND=350, BDAMP=0.992;

  const lat=new Int32Array((NX+1)*(NY+1)*(NZ+1)).fill(-1);
  const lid=(i,j,k)=>i+(NX+1)*(j+(NY+1)*k);
  const tmp=[]; let n=0;
  for(let k=0;k<=NZ;k++)for(let j=0;j<=NY;j++)for(let i=0;i<=NX;i++){
    if(j===NY||k===NZ||i===0||i===NX){ lat[lid(i,j,k)]=n++; tmp.push([-FX+i*dxs, j*dys, -k*dzs, k===0, j===0]); }
  }
  const pos=new Float64Array(n*3), prv=new Float64Array(n*3), rest=new Float64Array(n*3);
  const w=new Float64Array(n), memK=new Float64Array(n);
  for(let q=0;q<n;q++){
    const t=tmp[q];
    pos[3*q]=prv[3*q]=rest[3*q]=t[0];
    pos[3*q+1]=prv[3*q+1]=rest[3*q+1]=t[1];
    pos[3*q+2]=prv[3*q+2]=rest[3*q+2]=t[2];
    w[q]=t[3]?0:1/NODE_M;
    memK[q]=t[4]?MEM_GROUND:MEM_BASE;
  }

  // панели сетки: top, back, left, right
  const panels=[
    {U:NX,V:NZ,f:(u,v)=>lat[lid(u,NY,v)]},
    {U:NX,V:NY,f:(u,v)=>lat[lid(u,v,NZ)]},
    {U:NZ,V:NY,f:(u,v)=>lat[lid(0,v,u)]},
    {U:NZ,V:NY,f:(u,v)=>lat[lid(NX,v,u)]}
  ];
  const seen=new Set(), SA=[],SB=[],SK=[],SR=[];
  function addSpring(a,b,k){
    if(a===b)return; const key=a<b?a*n+b:b*n+a; if(seen.has(key))return; seen.add(key);
    SA.push(a);SB.push(b);SK.push(k);
    SR.push(Math.hypot(rest[3*a]-rest[3*b],rest[3*a+1]-rest[3*b+1],rest[3*a+2]-rest[3*b+2]));
  }
  for(const p of panels){
    for(let v=0;v<=p.V;v++)for(let u=0;u<=p.U;u++){
      const a=p.f(u,v);
      if(u<p.U) addSpring(a,p.f(u+1,v),K_STRUCT);
      if(v<p.V) addSpring(a,p.f(u,v+1),K_STRUCT);
      if(u<p.U&&v<p.V){ addSpring(a,p.f(u+1,v+1),K_SHEAR); addSpring(p.f(u+1,v),p.f(u,v+1),K_SHEAR); }
      if(u+2<=p.U) addSpring(a,p.f(u+2,v),K_BEND);
      if(v+2<=p.V) addSpring(a,p.f(u,v+2),K_BEND);
    }
  }
  const TRI=[];
  for(const p of panels){
    for(let v=0;v<p.V;v++)for(let u=0;u<p.U;u++){
      const a=p.f(u,v),b=p.f(u+1,v),c=p.f(u,v+1),d=p.f(u+1,v+1);
      TRI.push(a,b,c, b,d,c);
    }
  }
  const tri=Int32Array.from(TRI), nt=tri.length/3, near=new Uint8Array(n), candT=new Int32Array(nt);
  const ns=SA.length;
  const sa=Int32Array.from(SA), sb=Int32Array.from(SB), sk=Float64Array.from(SK), sr=Float64Array.from(SR);

  // растяжки к задним столбам
  const cordNode=[lat[lid(0,NY,NZ)],lat[lid(NX/2,NY,NZ)],lat[lid(NX,NY,NZ)]];
  const cordAnchor=[[-FX,CORD_Y,REAR_Z],[0,CORD_Y,REAR_Z],[FX,CORD_Y,REAR_Z]];
  const cordRest=cordNode.map((id,c)=>1.0*Math.hypot(rest[3*id]-cordAnchor[c][0],rest[3*id+1]-cordAnchor[c][1],rest[3*id+2]-cordAnchor[c][2]));
  const K_CORD=0.35;

  // каркас (капсулы) и задние столбы
  const frameSegs=[[-FX,0,0,-FX,FY,0,PR,'post'],[FX,0,0,FX,FY,0,PR,'post'],[-FX,FY,0,FX,FY,0,PR,'bar']];
  const rearSegs=[-FX,0,FX].map(x=>[x,0,REAR_Z,x,REAR_H,REAR_Z,0.05,'rear']);

  // мяч
  const bp=new Float64Array(3), bq=new Float64Array(3);
  bp[1]=bq[1]=RB;
  const cand=new Int32Array(n);
  const sim={n,pos,rest,bp,bq,lastHit:null,inNet:false,contacts:0,ns,
    cordNode,cordAnchor,REAR_Z,REAR_H,NX,NY,NZ,panels,lat,lid};

  function launch(x,y,z,vx,vy,vz,h){
    bp[0]=x;bp[1]=y;bp[2]=z; bq[0]=x-vx*h;bq[1]=y-vy*h;bq[2]=z-vz*h; sim.lastHit=null;
  }
  sim.launch=launch;
  sim.ballVel=(h)=>[(bp[0]-bq[0])/h,(bp[1]-bq[1])/h,(bp[2]-bq[2])/h];

  function segHit(s,e){
    const ax=s[0],ay=s[1],az=s[2],bx=s[3],by=s[4],bz=s[5];
    const abx=bx-ax,aby=by-ay,abz=bz-az;
    let t=((bp[0]-ax)*abx+(bp[1]-ay)*aby+(bp[2]-az)*abz)/(abx*abx+aby*aby+abz*abz);
    t=t<0?0:t>1?1:t;
    const nx=bp[0]-(ax+abx*t), ny=bp[1]-(ay+aby*t), nz=bp[2]-(az+abz*t);
    const d=Math.sqrt(nx*nx+ny*ny+nz*nz), m=RB+s[6];
    if(d<m&&d>1e-9){
      const ix=nx/d,iy=ny/d,iz=nz/d;
      bp[0]+=ix*(m-d);bp[1]+=iy*(m-d);bp[2]+=iz*(m-d);
      let vx=bp[0]-bq[0],vy=bp[1]-bq[1],vz=bp[2]-bq[2];
      const vn=vx*ix+vy*iy+vz*iz;
      if(vn<0){ vx-=(1+e)*vn*ix; vy-=(1+e)*vn*iy; vz-=(1+e)*vn*iz; bq[0]=bp[0]-vx;bq[1]=bp[1]-vy;bq[2]=bp[2]-vz; sim.lastHit=s[7]; }
    }
  }

  const RC=RB+0.004, RC2=RC*RC, WB=1/MB;

  const bary=[0,0,0];
  function triContact(A,B,C){
    const a=3*A,b=3*B,c=3*C;
    const px=bp[0],py=bp[1],pz=bp[2];
    const abx=pos[b]-pos[a],aby=pos[b+1]-pos[a+1],abz=pos[b+2]-pos[a+2];
    const acx=pos[c]-pos[a],acy=pos[c+1]-pos[a+1],acz=pos[c+2]-pos[a+2];
    const apx=px-pos[a],apy=py-pos[a+1],apz=pz-pos[a+2];
    let u,v,wv;
    const d1=abx*apx+aby*apy+abz*apz, d2=acx*apx+acy*apy+acz*apz;
    if(d1<=0&&d2<=0){u=1;v=0;wv=0;}
    else{
      const bpx=px-pos[b],bpy=py-pos[b+1],bpz=pz-pos[b+2];
      const d3=abx*bpx+aby*bpy+abz*bpz, d4=acx*bpx+acy*bpy+acz*bpz;
      if(d3>=0&&d4<=d3){u=0;v=1;wv=0;}
      else{
        const vc=d1*d4-d3*d2;
        if(vc<=0&&d1>=0&&d3<=0){const t=d1/(d1-d3);u=1-t;v=t;wv=0;}
        else{
          const cpx=px-pos[c],cpy=py-pos[c+1],cpz=pz-pos[c+2];
          const d5=abx*cpx+aby*cpy+abz*cpz, d6=acx*cpx+acy*cpy+acz*cpz;
          if(d6>=0&&d5<=d6){u=0;v=0;wv=1;}
          else{
            const vb=d5*d2-d1*d6;
            if(vb<=0&&d2>=0&&d6<=0){const t=d2/(d2-d6);u=1-t;v=0;wv=t;}
            else{
              const va=d3*d6-d5*d4;
              if(va<=0&&(d4-d3)>=0&&(d5-d6)>=0){const t=(d4-d3)/((d4-d3)+(d5-d6));u=0;v=1-t;wv=t;}
              else{const den=1/(va+vb+vc);v=vb*den;wv=vc*den;u=1-v-wv;}
            }
          }
        }
      }
    }
    const qx=u*pos[a]+v*pos[b]+wv*pos[c], qy=u*pos[a+1]+v*pos[b+1]+wv*pos[c+1], qz=u*pos[a+2]+v*pos[b+2]+wv*pos[c+2];
    let nx=px-qx,ny=py-qy,nz=pz-qz;
    const dd=nx*nx+ny*ny+nz*nz;
    if(dd>=RC2)return false;
    let d=Math.sqrt(dd);
    if(d<1e-6){ // центр на поверхности: нормаль треугольника против движения мяча
      nx=aby*acz-abz*acy;ny=abz*acx-abx*acz;nz=abx*acy-aby*acx;
      const l=Math.hypot(nx,ny,nz)||1;nx/=l;ny/=l;nz/=l;
      if(nx*(bp[0]-bq[0])+ny*(bp[1]-bq[1])+nz*(bp[2]-bq[2])>0){nx=-nx;ny=-ny;nz=-nz;}
      d=0;
    }else{nx/=d;ny/=d;nz/=d;}
    const pen=RC-d;
    const wt=u*u*w[A]+v*v*w[B]+wv*wv*w[C];
    const sc=pen/(wt+WB);
    const fa=sc*u*w[A], fb=sc*v*w[B], fc=sc*wv*w[C];
    pos[a]-=nx*fa;pos[a+1]-=ny*fa;pos[a+2]-=nz*fa;
    pos[b]-=nx*fb;pos[b+1]-=ny*fb;pos[b+2]-=nz*fb;
    pos[c]-=nx*fc;pos[c+1]-=ny*fc;pos[c+2]-=nz*fc;
    bp[0]+=nx*sc*WB;bp[1]+=ny*sc*WB;bp[2]+=nz*sc*WB;
    return true;
  }

  sim.step=function(h){
    const h2=h*h;
    // узлы сетки
    for(let q=0;q<n;q++){
      if(w[q]===0)continue;
      const i=3*q, k=memK[q];
      const x=pos[i],y=pos[i+1],z=pos[i+2];
      const nx=x+(x-prv[i])*DAMP+k*(rest[i]-x)*h2;
      const ny=y+(y-prv[i+1])*DAMP+(k*(rest[i+1]-y)-G_NET)*h2;
      const nz=z+(z-prv[i+2])*DAMP+k*(rest[i+2]-z)*h2;
      prv[i]=x;prv[i+1]=y;prv[i+2]=z; pos[i]=nx;pos[i+1]=ny;pos[i+2]=nz;
    }
    // мяч
    {
      const inside=bp[2]<-0.15&&Math.abs(bp[0])<FX&&bp[1]<FY+0.1;
      let damp=sim.inNet?BDAMP:(inside?0.9965:0.99998);
      if(inside){ const vz=bp[2]-bq[2]; if(vz>0) bq[2]=bp[2]-vz*0.985; }
      for(let c=0;c<3;c++){
        const x=bp[c]; const a=(c===1)?-G:0;
        bp[c]=x+(x-bq[c])*damp+a*h2; bq[c]=x;
      }
    }
    // кандидаты на контакт: треугольники рядом с мячом
    const bx=bp[0],by=bp[1],bz=bp[2], rr=RC+0.25;
    for(let q=0;q<n;q++){
      const i=3*q;
      near[q]=(Math.abs(pos[i]-bx)<rr&&Math.abs(pos[i+1]-by)<rr&&Math.abs(pos[i+2]-bz)<rr)?1:0;
    }
    let nc=0;
    for(let t=0;t<nt;t++){ if(near[tri[3*t]]|near[tri[3*t+1]]|near[tri[3*t+2]])candT[nc++]=t; }
    let contacts=0;
    for(let it=0;it<ITER;it++){
      for(let s=0;s<ns;s++){
        const A=sa[s],B=sb[s],a=3*A,b=3*B;
        const dx=pos[b]-pos[a],dy=pos[b+1]-pos[a+1],dz=pos[b+2]-pos[a+2];
        const d2=dx*dx+dy*dy+dz*dz; if(d2<1e-12)continue;
        const d=Math.sqrt(d2);
        let diff=(d-sr[s])/d; if(diff<0)diff*=COMPRESS;
        const wa=w[A],wb=w[B],ws=wa+wb; if(ws===0)continue;
        const c=diff*sk[s]/ws;
        pos[a]+=dx*c*wa;pos[a+1]+=dy*c*wa;pos[a+2]+=dz*c*wa;
        pos[b]-=dx*c*wb;pos[b+1]-=dy*c*wb;pos[b+2]-=dz*c*wb;
      }
      for(let c=0;c<3;c++){
        const id=cordNode[c],i=3*id,an=cordAnchor[c];
        const dx=an[0]-pos[i],dy=an[1]-pos[i+1],dz=an[2]-pos[i+2];
        const d=Math.sqrt(dx*dx+dy*dy+dz*dz);
        if(d>cordRest[c]){ const f=(d-cordRest[c])/d*K_CORD; pos[i]+=dx*f;pos[i+1]+=dy*f;pos[i+2]+=dz*f; }
      }
      for(let q=0;q<n;q++){ if(w[q]!==0&&pos[3*q+1]<0.003)pos[3*q+1]=0.003; }
      contacts=0;
      for(let m=0;m<nc;m++){
        const t=candT[m], A=tri[3*t],B=tri[3*t+1],C=tri[3*t+2];
        if(triContact(A,B,C))contacts++;
      }
    }
    sim.contacts=contacts; sim.inNet=contacts>0;
    for(const s of frameSegs)segHit(s,0.55);
    for(const s of rearSegs)segHit(s,0.3);
    // земля
    if(bp[1]<RB){
      const vyPre=bp[1]-bq[1];
      bp[1]=RB;
      const vx=bp[0]-bq[0], vz=bp[2]-bq[2];
      let vy=vyPre<0?-vyPre*0.55:0;
      if(vy<0.8*h)vy=0;
      const f=sim.inNet?0.9990:0.9997;
      bq[0]=bp[0]-vx*f; bq[1]=bp[1]-vy; bq[2]=bp[2]-vz*f;
    }
  };
  sim.resetNet=function(){ pos.set(rest); prv.set(rest); };
  return sim;
}


/* ══════════════════════════════════════════════════════════════════════════
 *  § 2. КОНСТАНТЫ
 * ══════════════════════════════════════════════════════════════════════════ */

const R_BALL = 0.11, M_BALL = 0.43;
const POST_R = 0.06, GOAL_W = 7.32, GOAL_H = 2.44, DEPTH = 2.0;
const FX = GOAL_W / 2 + POST_R;
const FY = GOAL_H + POST_R;
const SIM_STEP = 1 / 360;
const ACTIVE_SECONDS = 8;

export const GOAL_METRICS = Object.freeze({
    width: GOAL_W, height: GOAL_H, depth: DEPTH, postRadius: POST_R,
    rearPostZ: -(DEPTH + 2.0),
});


/* ══════════════════════════════════════════════════════════════════════════
 *  § 3. ОДНИ ВОРОТА
 * ══════════════════════════════════════════════════════════════════════════ */

function makeNetTexture() {
    const S = 128, c = document.createElement('canvas');
    c.width = c.height = S;
    const g = c.getContext('2d');
    g.fillStyle = '#000'; g.fillRect(0, 0, S, S);
    g.fillStyle = '#fff'; const t = 6;
    for (const o of [0, S]) { g.fillRect(o - t / 2, 0, t, S); g.fillRect(0, o - t / 2, S, t); }
    for (const ox of [0, S]) for (const oy of [0, S]) {
        g.beginPath(); g.arc(ox, oy, t * 0.95, 0, 7); g.fill();
    }
    const tx = new THREE.CanvasTexture(c);
    tx.wrapS = tx.wrapT = THREE.RepeatWrapping;
    tx.anisotropy = 8;
    return tx;
}

/**
 * @param {Object}  [opts]
 * @param {boolean} [opts.netPhysics=false]
 */
export function createGoal(opts = {}) {
    const netPhysics = !!opts.netPhysics;
    const sim = createSim({ FX, FY, DEPTH, POST_R, R_BALL, M_BALL });

    const group = new THREE.Group();
    group.name = 'football_goal';
    const disposables = [];
    const track = (o) => { disposables.push(o); return o; };

    /* ── Каркас ── */
    const white = track(new THREE.MeshStandardMaterial({
        color: 0xffffff, roughness: 0.28, metalness: 0.1, envMapIntensity: 0.7,
    }));
    const tube = (r, len) => {
        const m = new THREE.Mesh(new THREE.CylinderGeometry(r, r, len, 40), white);
        m.castShadow = true; m.receiveShadow = true; return m;
    };
    for (const sx of [-1, 1]) {
        const p = tube(POST_R, FY); p.position.set(sx * FX, FY / 2, 0); p.name = 'goal_post'; group.add(p);
    }
    { const b = tube(POST_R, 2 * FX); b.rotation.z = Math.PI / 2; b.position.set(0, FY, 0); b.name = 'goal_crossbar'; group.add(b); }
    for (const sx of [-1, 1]) {
        const s = new THREE.Mesh(new THREE.SphereGeometry(POST_R, 32, 16), white);
        s.position.set(sx * FX, FY, 0); s.castShadow = true; group.add(s);
    }

    /* ── Задние стойки и растяжки ── */
    const dark = track(new THREE.MeshStandardMaterial({ color: 0x3a4047, roughness: 0.45, metalness: 0.35 }));
    const cordMat = track(new THREE.MeshStandardMaterial({ color: 0x23272c, roughness: 0.6 }));
    const cords = [];
    [-FX, 0, FX].forEach((x) => {
        const p = new THREE.Mesh(new THREE.CylinderGeometry(0.05, 0.05, sim.REAR_H, 24), dark);
        p.position.set(x, sim.REAR_H / 2, sim.REAR_Z); p.castShadow = true; group.add(p);
        const cap = new THREE.Mesh(new THREE.SphereGeometry(0.05, 16, 12), dark);
        cap.position.set(x, sim.REAR_H, sim.REAR_Z); group.add(cap);
        const base = new THREE.Mesh(new THREE.CylinderGeometry(0.16, 0.18, 0.04, 24), dark);
        base.position.set(x, 0.02, sim.REAR_Z); group.add(base);
        const cd = new THREE.Mesh(new THREE.CylinderGeometry(0.007, 0.007, 1, 8), cordMat);
        cd.castShadow = true; group.add(cd); cords.push(cd);
    });
    const Y = new THREE.Vector3(0, 1, 0), tv = new THREE.Vector3(), tv2 = new THREE.Vector3();
    function updateCords() {
        for (let c = 0; c < 3; c++) {
            const i = 3 * sim.cordNode[c], a = sim.cordAnchor[c];
            tv.set(sim.pos[i], sim.pos[i + 1], sim.pos[i + 2]); tv2.set(a[0], a[1], a[2]);
            const d = tv2.clone().sub(tv), L = d.length();
            cords[c].position.copy(tv).addScaledVector(d, 0.5);
            cords[c].scale.set(1, L, 1);
            cords[c].quaternion.setFromUnitVectors(Y, d.normalize());
        }
    }

    /* ── Сетка ── */
    const netTex = track(makeNetTexture());
    const netMat = track(new THREE.MeshStandardMaterial({
        color: 0xf2f2ee, roughness: 0.95, alphaMap: netTex, transparent: true,
        alphaTest: 0.04, side: THREE.DoubleSide, depthWrite: false, envMapIntensity: 0.4,
    }));
    const netPanels = sim.panels.map((p) => {
        const nv = (p.U + 1) * (p.V + 1);
        const pos = new Float32Array(nv * 3), uv = new Float32Array(nv * 2), map = new Int32Array(nv), idx = [];
        for (let v = 0; v <= p.V; v++) for (let u = 0; u <= p.U; u++) {
            const k = v * (p.U + 1) + u; map[k] = p.f(u, v); uv[2 * k] = u; uv[2 * k + 1] = v;
        }
        for (let v = 0; v < p.V; v++) for (let u = 0; u < p.U; u++) {
            const a = v * (p.U + 1) + u, b = a + 1, c = a + p.U + 1, d = c + 1;
            idx.push(a, b, c, b, d, c);
        }
        const g = new THREE.BufferGeometry();
        g.setAttribute('position', new THREE.BufferAttribute(pos, 3));
        g.setAttribute('uv', new THREE.BufferAttribute(uv, 2));
        g.setIndex(idx);
        const m = new THREE.Mesh(g, netMat);
        m.frustumCulled = false; m.renderOrder = 2; m.name = 'goal_net';
        group.add(m);
        return { g, pos, map };
    });
    function updateNet() {
        for (const p of netPanels) {
            for (let k = 0; k < p.map.length; k++) {
                const i = 3 * p.map[k];
                p.pos[3 * k] = sim.pos[i]; p.pos[3 * k + 1] = sim.pos[i + 1]; p.pos[3 * k + 2] = sim.pos[i + 2];
            }
            p.g.attributes.position.needsUpdate = true;
            p.g.computeVertexNormals();
        }
        updateCords();
    }
    updateNet();

    /* ── API ── */
    let acc = 0, activeTimer = 0;
    const goal = {
        group, sim, netPhysics,
        active: false,

        /** Запуск мяча в ЛОКАЛЬНЫХ координатах ворот; включает физику сетки на 8 с. */
        launchBall(x, y, z, vx, vy, vz) {
            sim.launch(x, y, z, vx, vy, vz, SIM_STEP);
            if (netPhysics) { goal.active = true; activeTimer = ACTIVE_SECONDS; }
        },

        /** Позиция мяча симуляции в мировых координатах. */
        getBallWorld(target = new THREE.Vector3()) {
            return group.localToWorld(target.set(sim.bp[0], sim.bp[1], sim.bp[2]));
        },

        update(dt) {
            if (!netPhysics || !goal.active) return;
            acc += Math.min(dt, 0.05);
            let steps = 0;
            while (acc >= SIM_STEP && steps < 14) { sim.step(SIM_STEP); acc -= SIM_STEP; steps++; }
            if (steps === 14) acc = 0;
            updateNet();
            activeTimer -= dt;
            if (activeTimer <= 0) goal.active = false;
        },

        resetNet() { sim.resetNet(); updateNet(); },

        dispose() {
            group.traverse((o) => { if (o.geometry) o.geometry.dispose(); });
            for (const d of disposables) if (d && d.dispose) d.dispose();
            if (group.parent) group.parent.remove(group);
        },
    };
    return goal;
}


/* ══════════════════════════════════════════════════════════════════════════
 *  § 4. ДВЕ ПАРЫ ВОРОТ НА ЛИНИЯХ ВОРОТ ПОЛЯ
 * ══════════════════════════════════════════════════════════════════════════ */

/**
 * Ставит ворота в центры линий ворот: (±pitchLength/2, 0, 0).
 * Ворота справа (x > 0) развёрнуты проёмом к −X, слева — к +X.
 *
 * @param {Object}  [opts]
 * @param {number}  [opts.pitchLength=105]
 * @param {boolean} [opts.netPhysics=false]
 */
export function createStadiumGoals(opts = {}) {
    const halfL = (opts.pitchLength ?? 105) * 0.5;
    const root = new THREE.Group();
    root.name = 'stadium_goals';

    const right = createGoal(opts);
    right.group.name = 'goal_right';
    right.group.position.set(halfL, 0, 0);
    right.group.rotation.y = -Math.PI / 2;      // локальный +Z → мировой −X

    const left = createGoal(opts);
    left.group.name = 'goal_left';
    left.group.position.set(-halfL, 0, 0);
    left.group.rotation.y = Math.PI / 2;        // локальный +Z → мировой +X

    root.add(left.group, right.group);

    return {
        group: root, left, right,
        update(dt) { left.update(dt); right.update(dt); },
        dispose() {
            left.dispose(); right.dispose();
            if (root.parent) root.parent.remove(root);
        },
    };
}
