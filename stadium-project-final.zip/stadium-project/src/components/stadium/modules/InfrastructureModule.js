/**
 * src/components/stadium/modules/InfrastructureModule.js
 *
 * ══════════════════════════════════════════════════════════════════════════
 *  МОДУЛЬ ИНФРАСТРУКТУРЫ — COMPACT EDITION
 *
 *  ─── ВЕРСИЯ ──────────────────────────────────────────────────────────────
 *    Адаптирован под уменьшенный стадион:
 *      • Перила: 1.05 → 0.7 м (не торчат «заборами» над трибунами)
 *      • Фундамент тоньше: 1.2 → 0.8 м
 *      • Колонн между ярусами: 32 (16 × 2)
 *      • Лестниц: ~56 ступеней (вместо ~640)
 *      • Ворот: 6 (вместо 12)
 *
 *  ─── СОБИРАЕТ ────────────────────────────────────────────────────────────
 *    1. Колонны каркаса между ярусами (InstancedMesh)
 *    2. Лестничные марши (InstancedMesh ступеней)
 *    3. Входы-ворота (InstancedMesh)
 *    4. Перила вдоль лестниц
 *    5. Фундаментное кольцо
 * ══════════════════════════════════════════════════════════════════════════
 */

import * as THREE from 'three';
import {
    STADIUM_CONFIG,
    superEllipsePoint,
    superEllipseFrame,
    superEllipseEvenAngles,
    getAisleAngles,
} from '../StadiumConfig.js';
import {
    getSteel,
    getDarkSteel,
    getDarkConcrete,
} from '../StadiumMaterials.js';


/* ══════════════════════════════════════════════════════════════════════════
 *  § 1. КОНСТАНТЫ — COMPACT EDITION
 * ══════════════════════════════════════════════════════════════════════════ */

/** Глубина поперечной фермы между ярусами (м). */
const CROSS_TRUSS_DEPTH = 1.5;

/** Радиус перил (м). */
const RAILING_TUBE_RADIUS = 0.025;

/**
 * Высота перил (м).
 * ⚠️ Уменьшено с 1.05 до 0.7 — не торчат над трибунами.
 */
const RAILING_HEIGHT = 0.7;

/** Высота одной ступеньки (м). */
const STAIR_STEP_HEIGHT = 0.20;

/** Глубина одной ступеньки (м). */
const STAIR_STEP_DEPTH = 0.28;

/** Ширина лестницы (м). */
const STAIR_WIDTH = 2.0;

/** Количество ступеней в марше между ярусами. */
const STAIR_STEPS_PER_TIER = 14;

/**
 * Толщина балки фундамента (м).
 * ⚠️ Уменьшено с 1.2 до 0.8 — под Compact Edition.
 */
const FOUNDATION_THICKNESS = 0.8;

/** Высота балки фундамента (м). */
const FOUNDATION_HEIGHT = 0.5;


/* ══════════════════════════════════════════════════════════════════════════
 *  § 2. ВСПОМОГАТЕЛЬНЫЕ ФУНКЦИИ
 * ══════════════════════════════════════════════════════════════════════════ */

/**
 * Точка на контуре (суперэллипс).
 */
function contourPoint(angle, rx, rz) {
    return superEllipsePoint(angle, rx, rz, STADIUM_CONFIG.shape.power);
}


/**
 * Угол Object3D.rotation.y, при котором локальная ось +Z объекта
 * смотрит по ВНЕШНЕЙ нормали контура (численная производная).
 */
function contourOutwardRotation(angle, rx, rz) {
    return superEllipseFrame(angle, rx, rz, STADIUM_CONFIG.shape.power).rotationY;
}


/**
 * Единичная касательная к контуру (в сторону роста t).
 */
function contourTangent(angle, rx, rz) {
    const { tx, tz } = superEllipseFrame(angle, rx, rz, STADIUM_CONFIG.shape.power);
    return { tx, tz };
}


/* ══════════════════════════════════════════════════════════════════════════
 *  § 3. КОЛОННЫ КАРКАСА
 * ══════════════════════════════════════════════════════════════════════════ */

/**
 * Базовая геометрия одной колонны (единичная высота).
 */
function buildPillarGeometry() {
    const cfg = STADIUM_CONFIG.infrastructure;

    const geo = new THREE.CylinderGeometry(
        cfg.pillarRadius,
        cfg.pillarRadius,
        1.0,
        cfg.pillarSegments,
        1,
        false
    );

    return geo;
}


/**
 * Строит колонны каркаса между ярусами.
 */
function buildPillarRings() {
    const group = new THREE.Group();
    group.name = 'infra_pillars';

    const cfg = STADIUM_CONFIG.infrastructure;
    const tiers = STADIUM_CONFIG.tiers;

    let totalCount = 0;

    for (let ti = 0; ti < tiers.length - 1; ti++) {
        const lowerTier = tiers[ti];
        const upperTier = tiers[ti + 1];

        const lowerEndX = lowerTier.startRadiusX + lowerTier.depth;
        const lowerEndZ = lowerTier.startRadiusZ + lowerTier.depth;

        const rx = (lowerEndX + upperTier.startRadiusX) * 0.5;
        const rz = (lowerEndZ + upperTier.startRadiusZ) * 0.5;

        const yStart = lowerTier.baseY + lowerTier.height;
        const yEnd = upperTier.baseY;
        const pillarHeight = yEnd - yStart + CROSS_TRUSS_DEPTH;

        if (pillarHeight <= 0.1) continue;

        const geo = buildPillarGeometry();
        const mat = getSteel();

        const mesh = new THREE.InstancedMesh(geo, mat, cfg.pillarCount);
        mesh.name = `pillars_tier_${ti}`;
        mesh.castShadow = true;
        mesh.receiveShadow = true;
        mesh.frustumCulled = false;

        const dummy = new THREE.Object3D();

        /* Колонны — равномерно по длине дуги контура. */
        const pillarAngles = superEllipseEvenAngles(
            cfg.pillarCount, rx, rz, STADIUM_CONFIG.shape.power
        );

        for (let i = 0; i < cfg.pillarCount; i++) {
            const { x, z } = contourPoint(pillarAngles[i], rx, rz);

            dummy.position.set(x, yStart + pillarHeight * 0.5, z);
            dummy.rotation.set(0, 0, 0);
            dummy.scale.set(1, pillarHeight, 1);
            dummy.updateMatrix();

            mesh.setMatrixAt(i, dummy.matrix);
        }

        mesh.instanceMatrix.needsUpdate = true;
        group.add(mesh);
        totalCount += cfg.pillarCount;
    }

    return { group, totalCount };
}


/* ══════════════════════════════════════════════════════════════════════════
 *  § 4. ЛЕСТНИЦЫ
 * ══════════════════════════════════════════════════════════════════════════ */

/**
 * Геометрия одной ступени.
 */
function buildStairStepGeometry() {
    return new THREE.BoxGeometry(
        STAIR_WIDTH,
        STAIR_STEP_HEIGHT,
        STAIR_STEP_DEPTH
    );
}


/**
 * Строит лестничные марши.
 */
function buildStairs() {
    const group = new THREE.Group();
    group.name = 'infra_stairs';

    const cfg = STADIUM_CONFIG.infrastructure;
    const tiers = STADIUM_CONFIG.tiers;

    const stepGeo = buildStairStepGeometry();
    const stepMat = getDarkConcrete();
    const aisleAngles = getAisleAngles();

    let totalSteps = 0;

    for (let ti = 0; ti < tiers.length - 1; ti++) {
        const lowerTier = tiers[ti];
        const upperTier = tiers[ti + 1];

        const yStart = lowerTier.baseY + lowerTier.height;
        const yEnd = upperTier.baseY + 0.3;

        const heightDiff = yEnd - yStart;
        if (heightDiff <= 0.2) continue;

        const stepCount = Math.max(3, Math.floor(heightDiff / STAIR_STEP_HEIGHT));
        const actualStepHeight = heightDiff / stepCount;

        const lowerEndX = lowerTier.startRadiusX + lowerTier.depth;
        const lowerEndZ = lowerTier.startRadiusZ + lowerTier.depth;

        const upperStartX = upperTier.startRadiusX;
        const upperStartZ = upperTier.startRadiusZ;

        const rStartX = lowerEndX + 0.3;
        const rStartZ = lowerEndZ + 0.3;
        const rEndX = upperStartX - 0.3;
        const rEndZ = upperStartZ - 0.3;

        const totalInstances = cfg.aisleCount * stepCount;

        const mesh = new THREE.InstancedMesh(stepGeo, stepMat, totalInstances);
        mesh.name = `stairs_tier_${ti}`;
        mesh.castShadow = true;
        mesh.receiveShadow = true;
        mesh.frustumCulled = false;

        const dummy = new THREE.Object3D();

        let idx = 0;
        for (let ai = 0; ai < cfg.aisleCount; ai++) {
            const angle = aisleAngles[ai];

            for (let s = 0; s < stepCount; s++) {
                const t = s / (stepCount - 1);

                const rx = rStartX + (rEndX - rStartX) * t;
                const rz = rStartZ + (rEndZ - rStartZ) * t;

                const { x, z } = contourPoint(angle, rx, rz);

                const y = yStart + t * heightDiff + actualStepHeight * 0.5;

                dummy.position.set(x, y, z);

                const rotY = contourOutwardRotation(angle, rx, rz);
                dummy.rotation.set(0, rotY, 0);
                dummy.scale.set(1, 1, 1);
                dummy.updateMatrix();

                mesh.setMatrixAt(idx, dummy.matrix);
                idx++;
            }
        }

        mesh.count = idx;
        mesh.instanceMatrix.needsUpdate = true;
        group.add(mesh);
        totalSteps += idx;
    }

    return { group, totalSteps };
}


/* ══════════════════════════════════════════════════════════════════════════
 *  § 5. ВХОДЫ-ВОРОТА
 * ══════════════════════════════════════════════════════════════════════════ */

/**
 * Геометрия одних ворот.
 */
function buildVomitoryGeometry() {
    const cfg = STADIUM_CONFIG.infrastructure;

    return new THREE.BoxGeometry(
        cfg.vomitoryWidth,
        cfg.vomitoryHeight,
        cfg.vomitoryWidth * 0.4
    );
}


/**
 * Строит входы-ворота.
 */
function buildVomitoria() {
    const group = new THREE.Group();
    group.name = 'infra_vomitoria';

    const cfg = STADIUM_CONFIG.infrastructure;
    const firstTier = STADIUM_CONFIG.tiers[0];

    const rx = firstTier.startRadiusX - 0.3;
    const rz = firstTier.startRadiusZ - 0.3;

    const geo = buildVomitoryGeometry();
    const mat = getDarkConcrete();

    const mesh = new THREE.InstancedMesh(geo, mat, cfg.vomitoryCount);
    mesh.name = 'vomitoria';
    mesh.castShadow = true;
    mesh.receiveShadow = true;
    mesh.frustumCulled = false;

    const dummy = new THREE.Object3D();

    const vomAngles = superEllipseEvenAngles(
        cfg.vomitoryCount, rx, rz, STADIUM_CONFIG.shape.power
    );

    for (let i = 0; i < cfg.vomitoryCount; i++) {
        const angle = vomAngles[i];
        const { x, z } = contourPoint(angle, rx, rz);

        const y = cfg.vomitoryHeight * 0.5;

        dummy.position.set(x, y, z);

        const rotY = contourOutwardRotation(angle, rx, rz);
        dummy.rotation.set(0, rotY, 0);
        dummy.scale.set(1, 1, 1);
        dummy.updateMatrix();

        mesh.setMatrixAt(i, dummy.matrix);
    }

    mesh.instanceMatrix.needsUpdate = true;
    group.add(mesh);

    return { group, count: cfg.vomitoryCount };
}


/* ══════════════════════════════════════════════════════════════════════════
 *  § 6. ПЕРИЛА
 * ══════════════════════════════════════════════════════════════════════════ */

/**
 * Геометрия одной стойки перил.
 */
function buildRailingPostGeometry() {
    return new THREE.CylinderGeometry(
        RAILING_TUBE_RADIUS,
        RAILING_TUBE_RADIUS,
        RAILING_HEIGHT,
        8,
        1,
        false
    );
}


/**
 * Строит перила на лестницах.
 */
function buildRailings() {
    const group = new THREE.Group();
    group.name = 'infra_railings';

    const cfg = STADIUM_CONFIG.infrastructure;
    const tiers = STADIUM_CONFIG.tiers;

    const postPositions = [];
    const aisleAngles = getAisleAngles();

    for (let ti = 0; ti < tiers.length - 1; ti++) {
        const lowerTier = tiers[ti];
        const upperTier = tiers[ti + 1];

        const yStart = lowerTier.baseY + lowerTier.height;
        const yEnd = upperTier.baseY + 0.3;
        const heightDiff = yEnd - yStart;
        if (heightDiff <= 0.2) continue;

        const lowerEndX = lowerTier.startRadiusX + lowerTier.depth;
        const lowerEndZ = lowerTier.startRadiusZ + lowerTier.depth;

        const upperStartX = upperTier.startRadiusX;
        const upperStartZ = upperTier.startRadiusZ;

        const rStartX = lowerEndX + 0.3;
        const rStartZ = lowerEndZ + 0.3;
        const rEndX = upperStartX - 0.3;
        const rEndZ = upperStartZ - 0.3;

        const postsPerSide = Math.max(3, Math.floor(STAIR_STEPS_PER_TIER / 3));

        for (let ai = 0; ai < cfg.aisleCount; ai++) {
            const angle = aisleAngles[ai];
            const sideOffset = STAIR_WIDTH * 0.5;

            for (let side = -1; side <= 1; side += 2) {
                for (let s = 0; s < postsPerSide; s++) {
                    const t = s / (postsPerSide - 1);

                    const rx = rStartX + (rEndX - rStartX) * t;
                    const rz = rStartZ + (rEndZ - rStartZ) * t;

                    const { x, z } = contourPoint(angle, rx, rz);
                    const y = yStart + t * heightDiff + RAILING_HEIGHT * 0.5;

                    /* Касательная к контуру — численная производная. */
                    const { tx, tz } = contourTangent(angle, rx, rz);

                    postPositions.push({
                        x: x + tx * sideOffset * side,
                        y: y,
                        z: z + tz * sideOffset * side,
                    });
                }
            }
        }
    }

    if (postPositions.length > 0) {
        const postGeo = buildRailingPostGeometry();
        const postMat = getSteel();

        const postsMesh = new THREE.InstancedMesh(
            postGeo, postMat, postPositions.length
        );
        postsMesh.name = 'railing_posts';
        postsMesh.castShadow = true;
        postsMesh.receiveShadow = true;
        postsMesh.frustumCulled = false;

        const dummy = new THREE.Object3D();

        for (let i = 0; i < postPositions.length; i++) {
            const p = postPositions[i];
            dummy.position.set(p.x, p.y, p.z);
            dummy.rotation.set(0, 0, 0);
            dummy.scale.set(1, 1, 1);
            dummy.updateMatrix();
            postsMesh.setMatrixAt(i, dummy.matrix);
        }

        postsMesh.instanceMatrix.needsUpdate = true;
        group.add(postsMesh);
    }

    return { group, postCount: postPositions.length };
}


/* ══════════════════════════════════════════════════════════════════════════
 *  § 7. ФУНДАМЕНТ
 * ══════════════════════════════════════════════════════════════════════════ */

/**
 * Строит фундаментное кольцо.
 */
function buildFoundation() {
    const facade = STADIUM_CONFIG.facade;

    const rX_outer = facade.radiusX - 0.05;
    const rZ_outer = facade.radiusZ - 0.05;
    const rX_inner = rX_outer - FOUNDATION_THICKNESS;
    const rZ_inner = rZ_outer - FOUNDATION_THICKNESS;

    const segments = STADIUM_CONFIG.performance.radialSegments;
    const ringCols = segments + 1;
    const shapePower = STADIUM_CONFIG.shape.power;

    const profile = [
        { rx: rX_inner, rz: rZ_inner, y: 0                  },
        { rx: rX_outer, rz: rZ_outer, y: 0                  },
        { rx: rX_outer, rz: rZ_outer, y: FOUNDATION_HEIGHT  },
        { rx: rX_inner, rz: rZ_inner, y: FOUNDATION_HEIGHT  },
        { rx: rX_inner, rz: rZ_inner, y: 0                  },
    ];

    const profileLen = profile.length;
    const vertexCount = ringCols * profileLen;

    const positions = new Float32Array(vertexCount * 3);
    const uvs = new Float32Array(vertexCount * 2);

    let vIdx = 0;
    for (let p = 0; p < profileLen; p++) {
        const pt = profile[p];
        const v = p / (profileLen - 1);

        for (let i = 0; i < ringCols; i++) {
            const a = (i / segments) * Math.PI * 2;
            const sp = superEllipsePoint(a, pt.rx, pt.rz, shapePower);

            positions[vIdx * 3    ] = sp.x;
            positions[vIdx * 3 + 1] = pt.y;
            positions[vIdx * 3 + 2] = sp.z;

            uvs[vIdx * 2    ] = i / segments;
            uvs[vIdx * 2 + 1] = v;

            vIdx++;
        }
    }

    const quadCount = (profileLen - 1) * segments;
    const indices = new Uint32Array(quadCount * 6);

    let iIdx = 0;
    for (let p = 0; p < profileLen - 1; p++) {
        const rowA = p * ringCols;
        const rowB = (p + 1) * ringCols;

        for (let i = 0; i < segments; i++) {
            const a = rowA + i;
            const b = a + 1;
            const c = rowB + i;
            const d = c + 1;

            indices[iIdx++] = a;
            indices[iIdx++] = c;
            indices[iIdx++] = b;

            indices[iIdx++] = b;
            indices[iIdx++] = c;
            indices[iIdx++] = d;
        }
    }

    const geo = new THREE.BufferGeometry();
    geo.setAttribute('position', new THREE.BufferAttribute(positions, 3));
    geo.setAttribute('uv',       new THREE.BufferAttribute(uvs, 2));
    geo.setIndex(new THREE.BufferAttribute(indices, 1));
    geo.computeVertexNormals();
    geo.computeBoundingSphere();

    const mat = getDarkConcrete();

    const mesh = new THREE.Mesh(geo, mat);
    mesh.name = 'foundation';
    mesh.castShadow = true;
    mesh.receiveShadow = true;
    mesh.position.y = -0.02;

    return mesh;
}


/* ══════════════════════════════════════════════════════════════════════════
 *  § 8. ПУБЛИЧНЫЙ API
 * ══════════════════════════════════════════════════════════════════════════ */

/**
 * Строит всю инфраструктуру стадиона.
 */
export function buildInfrastructure() {
    const group = new THREE.Group();
    group.name = 'infrastructure';

    /* 1. Фундамент */
    const foundation = buildFoundation();
    group.add(foundation);

    /* 2. Колонны каркаса */
    const { group: pillarsGroup, totalCount: pillarCount } =
        buildPillarRings();
    group.add(pillarsGroup);

    /* 3. Лестницы */
    const { group: stairsGroup, totalSteps: stairSteps } =
        buildStairs();
    group.add(stairsGroup);

    /* 4. Входы-ворота */
    const { group: vomitoriaGroup, count: vomitoriaCount } =
        buildVomitoria();
    group.add(vomitoriaGroup);

    /* 5. Перила */
    const { group: railingsGroup, postCount: railingPosts } =
        buildRailings();
    group.add(railingsGroup);

    return {
        group,
        pillarsGroup,
        stairsGroup,
        vomitoriaGroup,
        railingsGroup,
        foundation,
        stats: {
            pillars: pillarCount,
            stairSteps,
            vomitoria: vomitoriaCount,
            railingPosts,
        },
    };
}


/* ══════════════════════════════════════════════════════════════════════════
 *  § 9. МЕТРИКИ
 * ══════════════════════════════════════════════════════════════════════════ */

/**
 * Возвращает метрики модуля.
 */
export function getInfrastructureMetrics(infra) {
    if (!infra) {
        return { error: 'Инфраструктура не построена.' };
    }

    let totalMeshes = 0;
    let totalInstanced = 0;
    let totalVerts = 0;
    let totalTris = 0;

    infra.group.traverse(child => {
        if (!child.isMesh && !child.isInstancedMesh) return;

        totalMeshes++;

        const g = child.geometry;
        if (!g) return;

        const verts = g.attributes.position.count;
        const tris = g.index ? g.index.count / 3 : verts / 3;
        const instCount = child.isInstancedMesh ? child.count : 1;

        if (child.isInstancedMesh) {
            totalInstanced += child.count;
        }

        totalVerts += verts * instCount;
        totalTris += tris * instCount;
    });

    return {
        pillars: infra.stats.pillars,
        stairSteps: infra.stats.stairSteps,
        vomitoria: infra.stats.vomitoria,
        railingPosts: infra.stats.railingPosts,

        totalMeshes,
        totalInstanced,
        totalVertices: totalVerts,
        totalTriangles: totalTris,

        estimatedDrawCalls: 1 + 2 + 2 + 1 + 1,

        summary: `${infra.stats.pillars} колонн, ` +
                 `${infra.stats.stairSteps} ступеней, ` +
                 `${infra.stats.vomitoria} ворот, ` +
                 `${infra.stats.railingPosts} стоек перил.`,
    };
}