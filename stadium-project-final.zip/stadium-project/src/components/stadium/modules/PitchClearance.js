/**
 * src/components/stadium/modules/PitchClearance.js
 *
 * ══════════════════════════════════════════════════════════════════════════
 *  РЕЗЕРВИРОВАНИЕ ПРОСТРАНСТВА ПОД ФУТБОЛЬНОЕ ПОЛЕ
 *
 *  ─── ЗАЧЕМ ЭТОТ МОДУЛЬ ──────────────────────────────────────────────────
 *    Стадион НЕ создаёт поле. Это ответственность игровых систем.
 *    Но стадион обязан гарантировать, что внутри овала трибун
 *    есть пустое пространство размером 105 × 68 м, куда поле
 *    без пересечений сможет быть помещено.
 *
 *  ─── ЧТО ДЕЛАЕТ МОДУЛЬ ──────────────────────────────────────────────────
 *    1. Возвращает точные границы свободной зоны
 *    2. Проверяет, лежит ли точка внутри неё
 *    3. Создаёт невидимый anchor-Group для связи с игровыми системами
 *    4. Опционально — визуализатор для отладки (полупрозрачный прямоугольник)
 *
 *  ─── ГЕОМЕТРИЯ ───────────────────────────────────────────────────────────
 *
 *     ┌───────────────────────────────────────────┐  ← внешняя граница
 *     │                                           │      (овал трибун)
 *     │      ┌───────────────────────────┐        │
 *     │      │                           │        │  ← зона поля
 *     │      │      ПОЛЕ 105 × 68        │        │      (пустая)
 *     │      │                           │        │
 *     │      └───────────────────────────┘        │
 *     │                                           │
 *     └───────────────────────────────────────────┘
 *
 *    Зазор: 22 м по X (вдоль поля), 21 м по Z (поперёк поля).
 *    Эти зазоры — «run-off» — пространство для разбега игроков,
 *    судейских зон и технических помещений.
 * ══════════════════════════════════════════════════════════════════════════
 */

import * as THREE from 'three';
import { STADIUM_CONFIG, superEllipsePoint } from '../StadiumConfig.js';


/* ══════════════════════════════════════════════════════════════════════════
 *  § 1. ГРАНИЦЫ СВОБОДНОЙ ЗОНЫ
 * ══════════════════════════════════════════════════════════════════════════ */

/**
 * Возвращает полные границы резервированной зоны под поле.
 *
 * ─── ВОЗВРАЩАЕМЫЙ ОБЪЕКТ ─────────────────────────────────────────────────
 *   {
 *     pitch: {               // точные границы самого поля 105 × 68
 *       length: 105, width: 68,
 *       halfLength: 52.5, halfWidth: 34,
 *     },
 *     clearance: {           // расширенная зона (поле + зазоры)
 *       minX, maxX,          // по длинной стороне
 *       minZ, maxZ,          // по короткой стороне
 *       innerRadiusX,        // = 74.5 (конец зоны по X)
 *       innerRadiusZ,        // = 55.0 (конец зоны по Z)
 *     },
 *   }
 *
 * ─── СИСТЕМА КООРДИНАТ ───────────────────────────────────────────────────
 *   • Центр арены = (0, 0, 0)
 *   • Поле вытянуто вдоль оси X (105 м)
 *   • Ширина поля — вдоль оси Z (68 м)
 *   • Y — вертикаль (0 = уровень газона)
 *
 * @returns {Object}
 */
export function getPitchClearanceBounds() {
    const { length, width, insetLength, insetWidth } = STADIUM_CONFIG.pitch;

    const halfLength = length * 0.5;
    const halfWidth = width * 0.5;

    /* Границы свободной зоны = поле + зазоры. */
    const innerRadiusX = halfLength + insetLength;   // 74.5
    const innerRadiusZ = halfWidth + insetWidth;     // 55.0

    return {
        /* Точные границы самого поля. */
        pitch: {
            length,
            width,
            halfLength,
            halfWidth,
        },

        /* Расширенная зона, зарезервированная под поле. */
        clearance: {
            minX: -innerRadiusX,
            maxX:  innerRadiusX,
            minZ: -innerRadiusZ,
            maxZ:  innerRadiusZ,
            innerRadiusX,
            innerRadiusZ,
        },
    };
}


/* ══════════════════════════════════════════════════════════════════════════
 *  § 2. ПРОВЕРКИ
 * ══════════════════════════════════════════════════════════════════════════ */

/**
 * Проверяет, лежит ли точка (x, z) внутри зарезервированной зоны.
 * Y-координата игнорируется — мы работаем в плоскости поля.
 *
 * ─── ГДЕ ПРИМЕНИМО ───────────────────────────────────────────────────────
 *   • Игровая логика: «не ставить ли объекты вне поля?»
 *   • Валидация: проверка коллизий при размещении объектов
 *   • Raycast-фильтры: игнорировать попадания по трибунам
 *
 * @param {number} x
 * @param {number} z
 * @returns {boolean}
 */
export function isPointInPitchClearance(x, z) {
    const b = getPitchClearanceBounds().clearance;

    /* Проверяем попадание в суперэллипс (контур трибун), а не в
     * прямоугольник: |x/a|^n + |z/b|^n <= 1. */
    const n = STADIUM_CONFIG.shape.power;
    const d = Math.pow(Math.abs(x / b.innerRadiusX), n) +
              Math.pow(Math.abs(z / b.innerRadiusZ), n);

    return d <= 1.0;
}


/**
 * Проверяет, лежит ли точка строго внутри прямоугольника поля
 * (105 × 68), без учёта зазоров.
 *
 * Полезно игровым системам: «находится ли мяч в пределах поля?»
 *
 * @param {number} x
 * @param {number} z
 * @returns {boolean}
 */
export function isPointInPitch(x, z) {
    const { halfLength, halfWidth } = getPitchClearanceBounds().pitch;

    return (
        x >= -halfLength && x <= halfLength &&
        z >= -halfWidth  && z <= halfWidth
    );
}


/**
 * Находит ближайшую точку зарезервированной зоны к заданной.
 * Если точка уже внутри — возвращает её же.
 *
 * ─── АЛГОРИТМ ────────────────────────────────────────────────────────────
 *   Для суперэллипса: если точка выходит за границу, проецируем её
 *   обратно на контур вдоль радиального направления. Однородность
 *   |x/a|^n + |z/b|^n даёт множитель k = 1 / d^(1/n).
 *
 * @param {number} x
 * @param {number} z
 * @returns {{x: number, z: number, clamped: boolean}}
 */
export function clampPointToPitchClearance(x, z) {
    const b = getPitchClearanceBounds().clearance;

    const n = STADIUM_CONFIG.shape.power;
    const d = Math.pow(Math.abs(x / b.innerRadiusX), n) +
              Math.pow(Math.abs(z / b.innerRadiusZ), n);

    if (d <= 1.0) {
        return { x, z, clamped: false };
    }

    /* Проецируем на границу контура. */
    const factor = 1.0 / Math.pow(d, 1.0 / n);

    return {
        x: x * factor,
        z: z * factor,
        clamped: true,
    };
}


/* ══════════════════════════════════════════════════════════════════════════
 *  § 3. ANCHOR — МАРКЕР ДЛЯ ИГРОВЫХ СИСТЕМ
 * ══════════════════════════════════════════════════════════════════════════ */

/**
 * Создаёт пустой Group-маркер, обозначающий центр поля.
 *
 * ─── ЗАЧЕМ ───────────────────────────────────────────────────────────────
 *   Игровой движок может получить этот Group через `stadium.getPitchAnchor()`
 *   и повесить на него поле, разметку, ворота, мяч, камеру — всё что угодно.
 *
 *   Невидимый объект (visible = false) — не рендерится, но существует
 *   в графе сцены, к нему можно привязываться.
 *
 * ─── МЕТАДАННЫЕ ──────────────────────────────────────────────────────────
 *   userData содержит все границы, чтобы игровые системы имели
 *   к ним доступ без дополнительных вычислений.
 *
 * @returns {THREE.Group}
 */
export function createPitchAnchor() {
    const group = new THREE.Group();
    group.name = 'pitch_anchor';

    /* Невидимый — только для логики. */
    group.visible = false;

    const bounds = getPitchClearanceBounds();

    /* ─── Метаданные для игровых систем ─────────────────────────── */
    group.userData = {
        type: 'pitch_anchor',
        pitchLength: bounds.pitch.length,
        pitchWidth: bounds.pitch.width,
        pitchHalfLength: bounds.pitch.halfLength,
        pitchHalfWidth: bounds.pitch.halfWidth,
        clearanceRadiusX: bounds.clearance.innerRadiusX,
        clearanceRadiusZ: bounds.clearance.innerRadiusZ,
        centerX: 0,
        centerY: 0,
        centerZ: 0,
    };

    /* Позиция — центр арены (по умолчанию 0,0,0, но явно). */
    group.position.set(0, 0, 0);

    return group;
}


/* ══════════════════════════════════════════════════════════════════════════
 *  § 4. ВИЗУАЛИЗАТОР (для отладки)
 * ══════════════════════════════════════════════════════════════════════════ */

/**
 * Создаёт полупрозрачный прямоугольник 105 × 68 м на уровне земли.
 *
 * ─── НАЗНАЧЕНИЕ ──────────────────────────────────────────────────────────
 *   Только для отладки. В продакшене не подключать.
 *   Помогает убедиться, что поле влезает в овал трибун без пересечений.
 *
 * ─── ВНЕШНИЙ ВИД ─────────────────────────────────────────────────────────
 *   • Плоскость с зелёным прозрачным материалом (визуально «поле»)
 *   • Белая рамка по периметру
 *   • Слегка приподнята над уровнем земли (0.01 м) для z-fighting
 *
 * @returns {THREE.Group}
 */
export function createPitchClearanceMarker() {
    const group = new THREE.Group();
    group.name = 'pitch_clearance_marker';

    const bounds = getPitchClearanceBounds();
    const { length, width } = bounds.pitch;

    /* ─── Прозрачный «ковёр» поля ───────────────────────────────── */
    const planeGeo = new THREE.PlaneGeometry(length, width);
    const planeMat = new THREE.MeshBasicMaterial({
        color: 0x2e7d4a,
        transparent: true,
        opacity: 0.18,
        depthWrite: false,
        side: THREE.DoubleSide,
    });
    const plane = new THREE.Mesh(planeGeo, planeMat);
    plane.rotation.x = -Math.PI / 2;   // вертикальная плоскость → горизонтальная
    plane.position.y = 0.01;           // чуть выше земли
    plane.renderOrder = 2;             // рендерить после бетона
    group.add(plane);

    /* ─── Белая рамка по периметру ─────────────────────────────── */
    const lineMat = new THREE.LineBasicMaterial({
        color: 0xffffff,
        transparent: true,
        opacity: 0.75,
    });

    const halfL = length * 0.5;
    const halfW = width * 0.5;
    const corners = [
        new THREE.Vector3(-halfL, 0.02, -halfW),
        new THREE.Vector3( halfL, 0.02, -halfW),
        new THREE.Vector3( halfL, 0.02,  halfW),
        new THREE.Vector3(-halfL, 0.02,  halfW),
        new THREE.Vector3(-halfL, 0.02, -halfW),   // замыкание
    ];

    const lineGeo = new THREE.BufferGeometry().setFromPoints(corners);
    const line = new THREE.Line(lineGeo, lineMat);
    line.renderOrder = 3;
    group.add(line);

    /* ─── Центральный круг (маркер центра поля) ───────────────── */
    const circlePoints = [];
    const r = 9.15;   // стандартный радиус центрального круга
    const segs = 48;
    for (let i = 0; i <= segs; i++) {
        const a = (i / segs) * Math.PI * 2;
        circlePoints.push(new THREE.Vector3(
            Math.cos(a) * r,
            0.02,
            Math.sin(a) * r
        ));
    }
    const circleGeo = new THREE.BufferGeometry().setFromPoints(circlePoints);
    const circle = new THREE.Line(circleGeo, lineMat);
    circle.renderOrder = 3;
    group.add(circle);

    return group;
}


/* ══════════════════════════════════════════════════════════════════════════
 *  § 5. МЕТРИКИ
 * ══════════════════════════════════════════════════════════════════════════ */

/**
 * Возвращает метрики зарезервированной зоны.
 *
 * @returns {Object}
 */
export function getPitchClearanceMetrics() {
    const bounds = getPitchClearanceBounds();
    const { clearance, pitch } = bounds;

    return {
        pitchArea: pitch.length * pitch.width,
        pitchLength: pitch.length,
        pitchWidth: pitch.width,

        clearanceRadiusX: clearance.innerRadiusX,
        clearanceRadiusZ: clearance.innerRadiusZ,
        clearanceInsetX: clearance.innerRadiusX - pitch.halfLength,
        clearanceInsetZ: clearance.innerRadiusZ - pitch.halfWidth,

        /* Площадь суперэллипса (формула шнурования по контуру). */
        clearanceArea: superEllipseArea(clearance.innerRadiusX, clearance.innerRadiusZ),

        /* Гарантия: поле влезает без пересечений. */
        fitsX: clearance.innerRadiusX > pitch.halfLength,
        fitsZ: clearance.innerRadiusZ > pitch.halfWidth,
    };
}


/**
 * Площадь суперэллипса — формула шнурования по 720 точкам контура.
 *
 * @param {number} rx
 * @param {number} rz
 * @returns {number}
 */
function superEllipseArea(rx, rz) {
    const n = STADIUM_CONFIG.shape.power;
    const N = 720;
    let sum = 0;
    let prev = superEllipsePoint(0, rx, rz, n);
    for (let i = 1; i <= N; i++) {
        const pt = superEllipsePoint((i / N) * Math.PI * 2, rx, rz, n);
        sum += prev.x * pt.z - pt.x * prev.z;
        prev = pt;
    }
    return Math.abs(sum) * 0.5;
}
