/**
 * src/components/stadium/modules/PitchModule.js
 *
 * ══════════════════════════════════════════════════════════════════════════
 *  ФУТБОЛЬНОЕ ПОЛЕ (газон из pole2.txt) + БЕГОВАЯ ДОРОЖКА
 *
 *  ─── СИСТЕМА КООРДИНАТ (та же, что у всей арены) ─────────────────────────
 *    • Центр арены (0,0,0); поле вытянуто вдоль X (105 м), ширина по Z (68 м)
 *    • Y = 0 — уровень газона; дорожка лежит на 0.02 м выше (против z-fight)
 *
 *  ─── ГАЗОН ───────────────────────────────────────────────────────────────
 *    Плоскость 117 × 80 м (105×68 + 6 м «газона за линией» с каждой
 *    стороны), процедурная текстура 4096×2816 с разметкой FIFA, бамп-карта
 *    травы и шейдерная доработка материала — код перенесён из pole2.txt.
 *
 *  ─── БЕГОВАЯ ДОРОЖКА ─────────────────────────────────────────────────────
 *    Контур — суперэллипс с тем же показателем (3.5), что и трибуны, поэтому
 *    дорожка идёт параллельно первому ряду. 6 дорожек × 1.22 м = 7.32 м.
 *    Внутренний бордюр, белая разметка дорожек, линия финиша, внешняя
 *    бетонная кромка. Зазор до трибун ≥ 1.9 м (рассчитан численно).
 *
 *  ─── «КОЛЛИЗИЯ» ──────────────────────────────────────────────────────────
 *    В сцене нет физического движка, поэтому модуль отдаёт аналитические
 *    запросы: getSurfaceAt(x, z), isOnTrack(x, z), getLanePoint(lane, s),
 *    surfaceHeight. Все поверхности плоские (Y = 0).
 * ══════════════════════════════════════════════════════════════════════════
 */

import * as THREE from 'three';
import { superEllipsePoint, superEllipseFrame } from '../StadiumConfig.js';


/* ══════════════════════════════════════════════════════════════════════════
 *  § 1. КОНСТАНТЫ ГАЗОНА (из pole2.txt без изменений)
 * ══════════════════════════════════════════════════════════════════════════ */

const FIELD_LENGTH          = 105.00;
const FIELD_WIDTH           =  68.00;
const FIELD_PADDING         =   6.00;
const PLANE_LENGTH          = FIELD_LENGTH + FIELD_PADDING * 2.0;
const PLANE_WIDTH           = FIELD_WIDTH  + FIELD_PADDING * 2.0;

const MARK_CENTER_CIRCLE_R  =  9.15;
const MARK_PENALTY_DEPTH    = 16.50;
const MARK_PENALTY_HALF     = 20.16;
const MARK_GOAL_AREA_DEPTH  =  5.50;
const MARK_GOAL_AREA_HALF   =  9.16;
const MARK_PENALTY_SPOT     = 11.00;
const MARK_CORNER_ARC_R     =  1.00;
const MARK_LINE_WIDTH       =  0.12;

const PITCH_TEX_WIDTH       = 4096;
const PITCH_TEX_HEIGHT      = 2816;
const DETAIL_TEX_SIZE       = 1024;

/* Detail scale — сколько раз микро-текстура повторяется по полю. */
const DETAIL_SCALE          = 48.0;

/* Сила рельефа — высокая, плотная трава.
 * 0.052 = ворс явно читается, трава «повыше», поле остаётся ровным издалека. */
const BUMP_SCALE            = 0.052;


/* ══════════════════════════════════════════════════════════════════════════
 *  § 2–3. УТИЛИТЫ И ПРОЦЕДУРНЫЕ ТЕКСТУРЫ ГАЗОНА (из pole2.txt без изменений)
 * ══════════════════════════════════════════════════════════════════════════ */

function mulberry32(seed) {
    let state = seed >>> 0;
    return function () {
        state = (state + 0x6D2B79F5) >>> 0;
        let t = state;
        t = Math.imul(t ^ (t >>> 15), t | 1);
        t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
        return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
    };
}

function hash2D(x, y, seed) {
    let h = Math.imul(x | 0, 374761393)
          + Math.imul(y | 0, 668265263)
          + Math.imul(seed | 0, 2147483647);
    h = (h ^ (h >>> 13)) >>> 0;
    h = Math.imul(h, 1274126177) >>> 0;
    h = (h ^ (h >>> 16)) >>> 0;
    return h / 4294967296;
}

function smootherstep(t) {
    return t * t * t * (t * (t * 6.0 - 15.0) + 10.0);
}

function tileableNoise2D(x, y, freq, seed) {
    const fx = x * freq;
    const fy = y * freq;
    const xi = Math.floor(fx);
    const yi = Math.floor(fy);
    const xf = fx - xi;
    const yf = fy - yi;
    const wx = smootherstep(xf);
    const wy = smootherstep(yf);
    const x0 = ((xi % freq) + freq) % freq;
    const y0 = ((yi % freq) + freq) % freq;
    const x1 = (x0 + 1) % freq;
    const y1 = (y0 + 1) % freq;
    const v00 = hash2D(x0, y0, seed);
    const v10 = hash2D(x1, y0, seed);
    const v01 = hash2D(x0, y1, seed);
    const v11 = hash2D(x1, y1, seed);
    const v0 = v00 * (1.0 - wx) + v10 * wx;
    const v1 = v01 * (1.0 - wx) + v11 * wx;
    return v0 * (1.0 - wy) + v1 * wy;
}

function tileableNoise2DAniso(x, y, freqX, freqY, seed) {
    const fx = x * freqX;
    const fy = y * freqY;
    const xi = Math.floor(fx);
    const yi = Math.floor(fy);
    const xf = fx - xi;
    const yf = fy - yi;
    const wx = smootherstep(xf);
    const wy = smootherstep(yf);
    const x0 = ((xi % freqX) + freqX) % freqX;
    const y0 = ((yi % freqY) + freqY) % freqY;
    const x1 = (x0 + 1) % freqX;
    const y1 = (y0 + 1) % freqY;
    const v00 = hash2D(x0, y0, seed);
    const v10 = hash2D(x1, y0, seed);
    const v01 = hash2D(x0, y1, seed);
    const v11 = hash2D(x1, y1, seed);
    const v0 = v00 * (1.0 - wx) + v10 * wx;
    const v1 = v01 * (1.0 - wx) + v11 * wx;
    return v0 * (1.0 - wy) + v1 * wy;
}

function tileableFbm(x, y, baseFreq, octaves, persistence, seed) {
    let value = 0.0, amplitude = 1.0, frequency = baseFreq, maxAmp = 0.0;
    for (let o = 0; o < octaves; o++) {
        value += amplitude * tileableNoise2D(x, y, frequency, seed + o * 313);
        maxAmp += amplitude;
        amplitude *= persistence;
        frequency *= 2;
    }
    return value / maxAmp;
}

function tileableFbmAniso(x, y, freqX, freqY, octaves, persistence, seed) {
    let value = 0.0, amplitude = 1.0, maxAmp = 0.0;
    let fx = freqX, fy = freqY;
    for (let o = 0; o < octaves; o++) {
        value += amplitude * tileableNoise2DAniso(
            x, y,
            Math.max(1, Math.round(fx)),
            Math.max(1, Math.round(fy)),
            seed + o * 313
        );
        maxAmp += amplitude;
        amplitude *= persistence;
        fx *= 2;
        fy *= 2;
    }
    return value / maxAmp;
}

function normalizeArray(arr) {
    let min = Infinity, max = -Infinity;
    for (let i = 0; i < arr.length; i++) {
        if (arr[i] < min) min = arr[i];
        if (arr[i] > max) max = arr[i];
    }
    const range = (max - min) || 1.0;
    for (let i = 0; i < arr.length; i++) {
        arr[i] = (arr[i] - min) / range;
    }
}


/* ══════════════════════════════════════════════════════════════════════════
 *  § 3. ПРОЦЕДУРНЫЕ ТЕКСТУРЫ
 * ══════════════════════════════════════════════════════════════════════════ */

function createPitchTexture() {
    const W = PITCH_TEX_WIDTH;
    const H = PITCH_TEX_HEIGHT;
    const canvas = document.createElement('canvas');
    canvas.width = W; canvas.height = H;
    const ctx = canvas.getContext('2d', { alpha: false, desynchronized: true });

    const pxPerMeterX = W / PLANE_LENGTH;
    const pxPerMeterY = H / PLANE_WIDTH;
    const pxPerMeterAvg = (pxPerMeterX + pxPerMeterY) * 0.5;
    const px = (m) => m * pxPerMeterAvg;

    /* ── Полосы стрижки.
     * Сочный, но естественный травяной + спокойный тёмно-зелёный.
     * Разница между полосами — мягкая, читается, но не «мигает». */
    const STRIPE_COUNT = 22;
    const stripeWidth  = W / STRIPE_COUNT;
    const COLOR_LIGHT = '#4d8548';   /* живой травяной, не кислотный */
    const COLOR_DARK  = '#3a6b3b';   /* спокойный тёмный зелёный */

    for (let i = 0; i < STRIPE_COUNT; i++) {
        ctx.fillStyle = (i % 2 === 0) ? COLOR_LIGHT : COLOR_DARK;
        ctx.fillRect(Math.floor(i * stripeWidth), 0,
                     Math.ceil(stripeWidth) + 2, H);
    }

    /* Органическая вариация. */
    ctx.globalCompositeOperation = 'overlay';
    const rnd1 = mulberry32(20240918);
    for (let i = 0; i < 2600; i++) {
        const cx = rnd1() * W, cy = rnd1() * H;
        const r  = 30 + rnd1() * 230;
        const a  = 0.02 + rnd1() * 0.04;
        const isLight = rnd1() > 0.48;
        const g = ctx.createRadialGradient(cx, cy, 0, cx, cy, r);
        g.addColorStop(0.0, isLight
            ? `rgba(220, 230, 210, ${a})`
            : `rgba(20, 40, 20, ${a})`);
        g.addColorStop(0.65, 'rgba(0, 0, 0, 0)');
        g.addColorStop(1.0,  'rgba(0, 0, 0, 0)');
        ctx.fillStyle = g;
        ctx.beginPath(); ctx.arc(cx, cy, r, 0, Math.PI * 2); ctx.fill();
    }

    /* Штрихи газонокосилки. */
    ctx.globalCompositeOperation = 'multiply';
    const rnd2 = mulberry32(77331);
    for (let i = 0; i < 18000; i++) {
        const x = rnd2() * W, y = rnd2() * H;
        const w = 3.0 + rnd2() * 40.0;
        const h = 0.5 + rnd2() * 1.2;
        const a = 0.015 + rnd2() * 0.04;
        ctx.fillStyle = `rgba(60, 88, 55, ${a})`;
        ctx.fillRect(x, y, w, h);
    }

    /* Радиальный градиент яркости — мягкий, не затемняет края. */
    ctx.globalCompositeOperation = 'soft-light';
    const fieldGrad = ctx.createRadialGradient(
        W * 0.42, H * 0.38, 0, W * 0.5, H * 0.5, W * 0.72
    );
    fieldGrad.addColorStop(0.0,  'rgba(255, 255, 245, 0.20)');
    fieldGrad.addColorStop(0.55, 'rgba(200, 220, 200, 0.06)');
    fieldGrad.addColorStop(1.0,  'rgba(0, 0, 0, 0.14)');
    ctx.fillStyle = fieldGrad;
    ctx.fillRect(0, 0, W, H);

    ctx.globalCompositeOperation = 'source-over';

    /* Разметка FIFA. */
    const fX0 = px(FIELD_PADDING);
    const fY0 = px(FIELD_PADDING);
    const fX1 = px(FIELD_PADDING + FIELD_LENGTH);
    const fY1 = px(FIELD_PADDING + FIELD_WIDTH);
    const fCX = px(FIELD_PADDING + FIELD_LENGTH * 0.5);
    const fCY = px(FIELD_PADDING + FIELD_WIDTH  * 0.5);
    const lineWidth = Math.max(3, Math.round(px(MARK_LINE_WIDTH)));

    ctx.strokeStyle = 'rgba(253, 254, 255, 0.97)';
    ctx.fillStyle   = 'rgba(253, 254, 255, 0.97)';
    ctx.lineWidth   = lineWidth;
    ctx.lineCap     = 'butt';
    ctx.lineJoin    = 'miter';

    ctx.strokeRect(fX0, fY0, fX1 - fX0, fY1 - fY0);
    ctx.beginPath(); ctx.moveTo(fCX, fY0); ctx.lineTo(fCX, fY1); ctx.stroke();
    ctx.beginPath();
    ctx.arc(fCX, fCY, px(MARK_CENTER_CIRCLE_R), 0, Math.PI * 2);
    ctx.stroke();
    ctx.beginPath();
    ctx.arc(fCX, fCY, Math.max(2.5, px(0.18)), 0, Math.PI * 2);
    ctx.fill();

    function drawPenaltyEnd(side) {
        const paX = (side < 0) ? fX0 : fX1 - px(MARK_PENALTY_DEPTH);
        const paY = fCY - px(MARK_PENALTY_HALF);
        ctx.strokeRect(paX, paY,
                       px(MARK_PENALTY_DEPTH),
                       px(MARK_PENALTY_HALF * 2));
        const gaX = (side < 0) ? fX0 : fX1 - px(MARK_GOAL_AREA_DEPTH);
        const gaY = fCY - px(MARK_GOAL_AREA_HALF);
        ctx.strokeRect(gaX, gaY,
                       px(MARK_GOAL_AREA_DEPTH),
                       px(MARK_GOAL_AREA_HALF * 2));
        const spotX = (side < 0)
            ? fX0 + px(MARK_PENALTY_SPOT)
            : fX1 - px(MARK_PENALTY_SPOT);
        ctx.beginPath();
        ctx.arc(spotX, fCY, Math.max(2.5, px(0.20)), 0, Math.PI * 2);
        ctx.fill();
        const arcR = px(MARK_CENTER_CIRCLE_R);
        const theta = Math.acos(MARK_GOAL_AREA_DEPTH / MARK_CENTER_CIRCLE_R);
        ctx.beginPath();
        if (side < 0) ctx.arc(spotX, fCY, arcR, -theta, theta);
        else ctx.arc(spotX, fCY, arcR, Math.PI - theta, Math.PI + theta);
        ctx.stroke();
    }
    drawPenaltyEnd(-1);
    drawPenaltyEnd(+1);

    const arcR = px(MARK_CORNER_ARC_R);
    const corners = [
        { x: fX0, y: fY0, a0: 0,            a1: Math.PI * 0.5 },
        { x: fX1, y: fY0, a0: Math.PI*0.5,  a1: Math.PI },
        { x: fX1, y: fY1, a0: Math.PI,      a1: Math.PI * 1.5 },
        { x: fX0, y: fY1, a0: Math.PI*1.5,  a1: Math.PI * 2 }
    ];
    for (const c of corners) {
        ctx.beginPath();
        ctx.arc(c.x, c.y, arcR, c.a0, c.a1);
        ctx.stroke();
    }

    /* Микрошум на разметке. */
    ctx.globalCompositeOperation = 'multiply';
    const rnd3 = mulberry32(11987);
    for (let i = 0; i < 5500; i++) {
        const x = rnd3() * W, y = rnd3() * H;
        const r = 2.0 + rnd3() * 9.0;
        const a = 0.03 + rnd3() * 0.06;
        const g = ctx.createRadialGradient(x, y, 0, x, y, r);
        g.addColorStop(0.0, `rgba(50, 68, 50, ${a})`);
        g.addColorStop(1.0, 'rgba(0, 0, 0, 0)');
        ctx.fillStyle = g;
        ctx.beginPath(); ctx.arc(x, y, r, 0, Math.PI * 2); ctx.fill();
    }
    ctx.globalCompositeOperation = 'source-over';

    const tex = new THREE.CanvasTexture(canvas);
    tex.colorSpace = THREE.SRGBColorSpace;
    tex.wrapS = tex.wrapT = THREE.ClampToEdgeWrapping;
    tex.minFilter = THREE.LinearMipmapLinearFilter;
    tex.magFilter = THREE.LinearFilter;
    tex.generateMipmaps = true;
    tex.anisotropy = 16;
    return tex;
}

/**
 * Карта высот — ультра-мелкое зерно с выраженными «травинками».
 * Веса смещены в пользу blade/micro, чтобы слой травы ощущался.
 */
function generateGrassHeightField(size) {
    const data = new Float32Array(size * size);

    for (let y = 0; y < size; y++) {
        for (let x = 0; x < size; x++) {
            const px = x / size;
            const py = y / size;

            const lowFreq  = tileableFbm(px, py, 18, 3, 0.55, 1001);
            const midFreq  = tileableFbm(px, py, 60, 3, 0.58, 2002);
            const blade    = tileableFbmAniso(px, py, 220, 44, 2, 0.55, 3003);
            const bladeSharp = Math.pow(blade, 0.65);
            const micro    = tileableFbm(px, py, 320, 2, 0.55, 5005);

            /* Больше веса на «травинки» — слой ощущается объёмнее. */
            let h = lowFreq    * 0.08
                  + midFreq    * 0.18
                  + bladeSharp * 0.42
                  + micro      * 0.32;

            h = Math.pow(h, 0.92);

            data[y * size + x] = h;
        }
    }

    normalizeArray(data);
    return data;
}

/**
 * Height field → bump map (grayscale) с repeat = DETAIL_SCALE.
 */
function heightFieldToBumpTexture(heightField, size) {
    const canvas = document.createElement('canvas');
    canvas.width = size; canvas.height = size;
    const ctx = canvas.getContext('2d', { alpha: false });
    const img = ctx.createImageData(size, size);

    for (let i = 0; i < size * size; i++) {
        const v = Math.max(0, Math.min(255, Math.round(heightField[i] * 255)));
        const idx = i * 4;
        img.data[idx    ] = v;
        img.data[idx + 1] = v;
        img.data[idx + 2] = v;
        img.data[idx + 3] = 255;
    }

    ctx.putImageData(img, 0, 0);

    const tex = new THREE.CanvasTexture(canvas);
    tex.colorSpace = THREE.NoColorSpace;
    tex.wrapS = tex.wrapT = THREE.RepeatWrapping;
    tex.minFilter = THREE.LinearMipmapLinearFilter;
    tex.magFilter = THREE.LinearFilter;
    tex.generateMipmaps = true;
    tex.anisotropy = 16;

    /* Ключ к микро-масштабу: 48 повторов по полю. */
    tex.repeat.set(DETAIL_SCALE, DETAIL_SCALE);

    return tex;
}


/* ══════════════════════════════════════════════════════════════════════════
 *  § 4. РЕНДЕРЕР / СЦЕНА / КАМЕРА / КОНТРОЛЫ


/* ══════════════════════════════════════════════════════════════════════════
 *  § 1b. КОНСТАНТЫ ДОРОЖКИ
 * ══════════════════════════════════════════════════════════════════════════ */

/** Показатель суперэллипса — ДОЛЖЕН совпадать со STADIUM_CONFIG.shape.power. */
const TRACK_POWER        = 3.5;
/** Внутренние полуоси дорожки (м). Подобраны так, чтобы углы поля 105×68
 *  (+1.5 м запаса) лежали внутри, а внешний край отстоял от трибун ≥ 1.9 м. */
const TRACK_INNER_RX     = 63.0;
const TRACK_INNER_RZ     = 45.75;
const TRACK_LANES        = 6;
const TRACK_LANE_WIDTH   = 1.22;                                 // IAAF
const TRACK_WIDTH        = TRACK_LANES * TRACK_LANE_WIDTH;       // 7.32 м
const TRACK_Y            = 0.03;       // 3 см над газоном — чёткая ступенька
const TRACK_SEGMENTS     = 3072;                                 // 768 на четверть
const TRACK_TILE_TARGET  = 16.0;                                 // м текстуры по периметру
const TRACK_LINE_WIDTH   = 0.05;                                 // м
const KERB_WIDTH         = 0.20;
const KERB_HEIGHT        = 0.10;
const APRON_WIDTH        = 1.00;                                 // бетонная кромка снаружи
const TRACK_TEX_W        = 2048;
const TRACK_TEX_H        = 1024;

/* Белое ограждение вокруг газона: сплошные горизонтальные панели
 * (как современные спортивные/рекламные щиты), по внутреннему краю дорожки. */
const FENCE_OFFSET       = -0.55;      // м от внутреннего края дорожки к полю
const FENCE_BOARD_H      = 0.90;       // высота панелей
const FENCE_BOARD_T      = 0.06;       // толщина
const FENCE_PANEL_LEN    = 2.5;        // длина одной секции по периметру

/* Серый рекламный забор по внешнему краю дорожки. */
const AD_OFFSET          = 0.40;       // центр забора, м от внешнего края дорожки
const AD_THICK           = 0.10;
const AD_HEIGHT          = 1.00;
const AD_PANEL_LEN       = 5.0;        // длина одного щита по периметру


/* ══════════════════════════════════════════════════════════════════════════
 *  § 6–7. МАТЕРИАЛ ГАЗОНА (из pole2.txt без изменений)
 * ══════════════════════════════════════════════════════════════════════════ */

let grassMaterial = null;
let grassMaterialShader = null;
let pitchTexture = null;
let grassBumpTexture = null;

function createGrassMaterial() {
    const mat = new THREE.MeshStandardMaterial({
        map: pitchTexture,

        /* Абсолютная матовость */
        roughness: 1.0,
        metalness: 0.0,
        envMapIntensity: 0.0,

        /* Высокая, плотная трава */
        bumpMap: grassBumpTexture,
        bumpScale: BUMP_SCALE
    });

    mat.onBeforeCompile = (shader) => {
        shader.uniforms.uDetailScale    = { value: DETAIL_SCALE };
        shader.uniforms.uTime           = { value: 0.0 };
        shader.uniforms.uStripeStrength = { value: 0.045 };
        shader.uniforms.uGrainStrength  = { value: 0.10 };

        /* VERTEX */
        shader.vertexShader = shader.vertexShader.replace(
            '#include <common>',
            `
            #include <common>
            varying vec3 vWorldPos;
            varying vec3 vViewDirWS;
            `
        );

        shader.vertexShader = shader.vertexShader.replace(
            '#include <worldpos_vertex>',
            `
            #include <worldpos_vertex>

            vWorldPos = (modelMatrix * vec4(transformed, 1.0)).xyz;
            vViewDirWS = normalize(cameraPosition - vWorldPos);
            `
        );

        /* FRAGMENT */
        shader.fragmentShader = shader.fragmentShader.replace(
            '#include <common>',
            `
            #include <common>
            uniform float uDetailScale;
            uniform float uTime;
            uniform float uStripeStrength;
            uniform float uGrainStrength;
            varying vec3 vWorldPos;
            varying vec3 vViewDirWS;
            `
        );

        shader.fragmentShader = shader.fragmentShader.replace(
            '#include <map_fragment>',
            `
            #include <map_fragment>

            /* ── A. Микро-зерно по мировым координатам. */
            vec2 grainUV1 = vWorldPos.xz * 380.0;
            vec2 grainUV2 = vWorldPos.xz * 720.0 + vec2(13.7, 41.3);

            float g1 = fract(sin(dot(grainUV1, vec2(12.9898, 78.233))) * 43758.5453);
            float g2 = fract(sin(dot(grainUV2, vec2(93.989, 67.345))) * 24634.6345);
            float g3 = fract(sin(dot(grainUV1 * 1.73, vec2(45.123, 89.456))) * 33145.1234);

            float grain = (g1 + g2 + g3) * 0.3333;

            float grainMod = mix(
                1.0 - uGrainStrength * 0.5,
                1.0 + uGrainStrength * 0.5,
                grain
            );

            diffuseColor.rgb *= grainMod;

            /* ── B. Очень деликатный угловой сдвиг яркости полос.
             *      Слабее предыдущего, чтобы полосы не «кричали». */
            float alongStripe = abs(normalize(vViewDirWS).x);
            float sheenCurve = smoothstep(0.25, 0.90, alongStripe);

            float stripeMod = mix(
                1.0 - uStripeStrength * 0.25,
                1.0 + uStripeStrength * 0.45,
                sheenCurve
            );

            diffuseColor.rgb *= stripeMod;
            `
        );

        grassMaterialShader = shader;
    };

    grassMaterial = mat;
    return mat;
}


/* ══════════════════════════════════════════════════════════════════════════
 *  § 9. ТЕКСТУРА И МАТЕРИАЛ ДОРОЖКИ
 * ══════════════════════════════════════════════════════════════════════════ */

function createTrackTextures() {
    const W = TRACK_TEX_W, H = TRACK_TEX_H;
    const canvas = document.createElement('canvas');
    canvas.width = W; canvas.height = H;
    const ctx = canvas.getContext('2d', { alpha: false });

    /* Терракотовая резина: база + крупные пятна износа. */
    ctx.fillStyle = '#c0532b';
    ctx.fillRect(0, 0, W, H);

    const rnd = mulberry32(777);
    ctx.globalCompositeOperation = 'multiply';
    for (let i = 0; i < 900; i++) {
        const x = rnd() * W, y = rnd() * H, r = 18 + rnd() * 70;
        const a = 0.025 + rnd() * 0.05;
        const g = ctx.createRadialGradient(x, y, 0, x, y, r);
        g.addColorStop(0, `rgba(120, 50, 30, ${a})`);
        g.addColorStop(1, 'rgba(0,0,0,0)');
        ctx.fillStyle = g;
        /* Рисуем с обёрткой по U, чтобы текстура тайлилась бесшовно. */
        for (const dx of [-W, 0, W]) {
            ctx.beginPath(); ctx.arc(x + dx, y, r, 0, Math.PI * 2); ctx.fill();
        }
    }
    /* Светлые «выгоревшие» пятна. */
    ctx.globalCompositeOperation = 'screen';
    for (let i = 0; i < 400; i++) {
        const x = rnd() * W, y = rnd() * H, r = 25 + rnd() * 80;
        const g = ctx.createRadialGradient(x, y, 0, x, y, r);
        g.addColorStop(0, `rgba(255, 140, 90, ${0.015 + rnd() * 0.025})`);
        g.addColorStop(1, 'rgba(0,0,0,0)');
        ctx.fillStyle = g;
        for (const dx of [-W, 0, W]) {
            ctx.beginPath(); ctx.arc(x + dx, y, r, 0, Math.PI * 2); ctx.fill();
        }
    }
    ctx.globalCompositeOperation = 'source-over';

    /* Разметка: V идёт поперёк дорожки (0 = внутренний край, 1 = внешний).
     * Canvas Y инвертируется при загрузке (flipY), но линии симметричны. */
    const pxPerMeterV = H / TRACK_WIDTH;
    const lineW = Math.max(3, TRACK_LINE_WIDTH * pxPerMeterV);
    ctx.fillStyle = '#f3efe6';
    for (let k = 0; k <= TRACK_LANES; k++) {
        const y = (k / TRACK_LANES) * H;
        ctx.fillRect(0, y - lineW * 0.5, W, lineW);
    }

    /* Мелкое зерно резины поверх всего (в т.ч. поверх линий). */
    const img = ctx.getImageData(0, 0, W, H);
    const d = img.data;
    const rg = mulberry32(4242);
    for (let i = 0; i < d.length; i += 4) {
        const n = 1 + (rg() - 0.5) * 0.16;
        d[i] = Math.min(255, d[i] * n);
        d[i + 1] = Math.min(255, d[i + 1] * n);
        d[i + 2] = Math.min(255, d[i + 2] * n);
    }
    ctx.putImageData(img, 0, 0);

    const map = new THREE.CanvasTexture(canvas);
    map.colorSpace = THREE.SRGBColorSpace;
    map.wrapS = THREE.RepeatWrapping;
    map.wrapT = THREE.ClampToEdgeWrapping;
    map.anisotropy = 16;

    /* Бамп — мелкая зернистость резины. */
    const BS = 512;
    const bc = document.createElement('canvas');
    bc.width = BS; bc.height = BS;
    const bctx = bc.getContext('2d', { alpha: false });
    const bimg = bctx.createImageData(BS, BS);
    const rb = mulberry32(9001);
    for (let i = 0; i < BS * BS; i++) {
        const v = Math.floor(90 + rb() * 120);
        bimg.data[i * 4] = bimg.data[i * 4 + 1] = bimg.data[i * 4 + 2] = v;
        bimg.data[i * 4 + 3] = 255;
    }
    bctx.putImageData(bimg, 0, 0);
    const bump = new THREE.CanvasTexture(bc);
    bump.colorSpace = THREE.NoColorSpace;
    bump.wrapS = bump.wrapT = THREE.RepeatWrapping;
    bump.anisotropy = 8;

    return { map, bump };
}


/* ══════════════════════════════════════════════════════════════════════════
 *  § 10. ГЕОМЕТРИЯ КОНТУРА ДОРОЖКИ
 * ══════════════════════════════════════════════════════════════════════════ */

/**
 * Точка на смещённом от внутреннего края контуре.
 * offset > 0 — наружу (к трибунам), < 0 — внутрь (к полю).
 */
function buildContour() {
    const pts = [];            // {x, z, nx, nz}
    for (let i = 0; i < TRACK_SEGMENTS; i++) {
        const t = (i / TRACK_SEGMENTS) * Math.PI * 2;
        const p = superEllipsePoint(t, TRACK_INNER_RX, TRACK_INNER_RZ, TRACK_POWER);
        const f = superEllipseFrame(t, TRACK_INNER_RX, TRACK_INNER_RZ, TRACK_POWER);
        pts.push({ x: p.x, z: p.z, nx: f.nx, nz: f.nz });
    }
    /* Длина дуги по внутреннему краю. */
    const s = new Float64Array(TRACK_SEGMENTS + 1);
    for (let i = 1; i <= TRACK_SEGMENTS; i++) {
        const a = pts[i - 1], b = pts[i % TRACK_SEGMENTS];
        s[i] = s[i - 1] + Math.hypot(b.x - a.x, b.z - a.z);
    }
    return { pts, s, perimeter: s[TRACK_SEGMENTS] };
}

function offsetPoint(c, i, off) {
    const p = c.pts[i % TRACK_SEGMENTS];
    return [p.x + p.nx * off, p.z + p.nz * off];
}

/** Горизонтальная лента между смещениями off0..off1 на высоте y. UV: u — по дуге. */
function buildBand(c, off0, off1, y, uScale, vFromOffsets) {
    const n = TRACK_SEGMENTS;
    const pos = new Float32Array((n + 1) * 2 * 3);
    const uv  = new Float32Array((n + 1) * 2 * 2);
    for (let i = 0; i <= n; i++) {
        const [x0, z0] = offsetPoint(c, i, off0);
        const [x1, z1] = offsetPoint(c, i, off1);
        const u = c.s[i] * uScale;
        pos.set([x0, y, z0, x1, y, z1], i * 6);
        uv.set([u, 0, u, vFromOffsets ? 1 : 0.0], i * 4);
    }
    const idx = [];
    for (let i = 0; i < n; i++) {
        const a = i * 2, b = i * 2 + 1, a2 = (i + 1) * 2, b2 = (i + 1) * 2 + 1;
        idx.push(a, a2, b,  b, a2, b2);       // нормаль вверх (+Y)
    }
    const g = new THREE.BufferGeometry();
    g.setAttribute('position', new THREE.BufferAttribute(pos, 3));
    g.setAttribute('uv', new THREE.BufferAttribute(uv, 2));
    g.setIndex(idx);
    g.computeVertexNormals();
    return g;
}

/** Вертикальная стенка на смещении off от y0 до y1; faceOutward — нормаль наружу. */
function buildWall(c, off, y0, y1, faceOutward, uScale = null) {
    const n = TRACK_SEGMENTS;
    const pos = new Float32Array((n + 1) * 2 * 3);
    const uv = uScale ? new Float32Array((n + 1) * 2 * 2) : null;
    for (let i = 0; i <= n; i++) {
        const [x, z] = offsetPoint(c, i, off);
        pos.set([x, y0, z, x, y1, z], i * 6);
        if (uv) { const u = c.s[i] * uScale; uv.set([u, 0, u, 1], i * 4); }
    }
    const idx = [];
    for (let i = 0; i < n; i++) {
        const a = i * 2, t = i * 2 + 1, a2 = (i + 1) * 2, t2 = (i + 1) * 2 + 1;
        if (faceOutward) idx.push(a, t, a2,  a2, t, t2);
        else             idx.push(a, a2, t,  t, a2, t2);
    }
    const g = new THREE.BufferGeometry();
    g.setAttribute('position', new THREE.BufferAttribute(pos, 3));
    if (uv) g.setAttribute('uv', new THREE.BufferAttribute(uv, 2));
    g.setIndex(idx);
    g.computeVertexNormals();
    return g;
}



/* ══════════════════════════════════════════════════════════════════════════
 *  § 10b. ГАЗОН ВНУТРИ ДОРОЖКИ, БЕЛЫЙ ЗАБОРЧИК, СЕРЫЙ РЕКЛАМНЫЙ ЗАБОР
 * ══════════════════════════════════════════════════════════════════════════ */

/** Точка контура по длине дуги s с боковым смещением off (лерп между узлами). */
function sampleAt(c, s, off) {
    const N = TRACK_SEGMENTS, L = c.perimeter;
    s = ((s % L) + L) % L;
    let lo = 0, hi = N;
    while (hi - lo > 1) { const mid = (lo + hi) >> 1; if (c.s[mid] <= s) lo = mid; else hi = mid; }
    const a = c.pts[lo % N], b = c.pts[(lo + 1) % N];
    const f = (s - c.s[lo]) / ((c.s[lo + 1] - c.s[lo]) || 1);
    let nx = a.nx + (b.nx - a.nx) * f, nz = a.nz + (b.nz - a.nz) * f;
    const l = Math.hypot(nx, nz) || 1; nx /= l; nz /= l;
    return {
        x: a.x + (b.x - a.x) * f + nx * off,
        z: a.z + (b.z - a.z) * f + nz * off,
        tx: -nz, tz: nx,                      // касательная (n = (tz, −tx))
    };
}

/**
 * Зелёная «подложка» от края поля 117×80 до бордюра дорожки.
 * Без неё между краем плоскости газона и дорожкой оставалась полоса тёмной
 * земли (плоскость — прямоугольник, а дорожка — суперэллипс).
 */
function createInfield(c) {
    const pts = [];
    for (let i = 0; i < TRACK_SEGMENTS; i += 2) {
        const [x, z] = offsetPoint(c, i, -KERB_WIDTH);
        pts.push(new THREE.Vector2(x, -z));
    }
    const geo = new THREE.ShapeGeometry(new THREE.Shape(pts));   // UV = метры
    /* После rotation.x = −π/2 точка (x, y) → мир (x, 0, −y) = (x, 0, z). */
    const bump = grassBumpTexture.clone();
    bump.needsUpdate = true;
    bump.wrapS = bump.wrapT = THREE.RepeatWrapping;
    bump.repeat.set(DETAIL_SCALE / PLANE_LENGTH, DETAIL_SCALE / PLANE_LENGTH);

    const mat = new THREE.MeshStandardMaterial({
        name: 'infield_grass', color: 0x437840, roughness: 1.0, metalness: 0.0,
        envMapIntensity: 0.0, bumpMap: bump, bumpScale: BUMP_SCALE,
    });
    mat.polygonOffset = true; mat.polygonOffsetFactor = 1; mat.polygonOffsetUnits = 1;

    const mesh = new THREE.Mesh(geo, mat);
    mesh.name = 'infield_grass';
    mesh.rotation.x = -Math.PI * 0.5;
    mesh.position.y = -0.008;                 // выше земли (−0.02), ниже газона (0)
    mesh.receiveShadow = true;
    return { mesh, disposables: [mat, bump] };
}

/** Текстура белой секции ограждения (2.5 × 0.9 м): рамка, швы, цокольная планка. */
function createFenceTexture() {
    const W = 1024, H = 368;
    const cv = document.createElement('canvas');
    cv.width = W; cv.height = H;
    const g = cv.getContext('2d', { alpha: false });
    g.fillStyle = '#f4f5f3'; g.fillRect(0, 0, W, H);                  // белый пластик/металл
    g.fillStyle = '#ffffff'; g.fillRect(16, 18, W - 32, H - 70);      // лицевая панель
    g.strokeStyle = '#d5d8d9'; g.lineWidth = 3; g.strokeRect(16, 18, W - 32, H - 70);
    g.fillStyle = '#dfe2e3'; g.fillRect(0, H - 40, W, 40);            // цокольная планка
    g.fillStyle = '#c9cdcf'; g.fillRect(0, H - 42, W, 3);
    g.fillStyle = '#b4b9bc';                                          // швы между секциями
    g.fillRect(0, 0, 4, H); g.fillRect(W - 4, 0, 4, H);
    const tx = new THREE.CanvasTexture(cv);
    tx.colorSpace = THREE.SRGBColorSpace;
    tx.wrapS = THREE.RepeatWrapping; tx.wrapT = THREE.ClampToEdgeWrapping;
    tx.anisotropy = 16;
    return tx;
}

/** Белое ограждение из сплошных горизонтальных панелей по периметру поля. */
function createWhiteFence(c) {
    const group = new THREE.Group();
    group.name = 'pitch_fence';

    const repeats = Math.max(1, Math.round(c.perimeter / FENCE_PANEL_LEN));
    const uScale = repeats / c.perimeter;        // целое число секций — без шва

    const tex = createFenceTexture();
    const mat = new THREE.MeshStandardMaterial({
        name: 'fence_panel_white', map: tex, roughness: 0.4, metalness: 0.08, envMapIntensity: 0.5,
    });
    const capMat = new THREE.MeshStandardMaterial({
        name: 'fence_cap_white', color: 0xeceeed, roughness: 0.4, metalness: 0.1,
    });

    const y0 = 0.0, y1 = FENCE_BOARD_H;
    const offField = FENCE_OFFSET - FENCE_BOARD_T / 2;   // грань к полю
    const offTrack = FENCE_OFFSET + FENCE_BOARD_T / 2;   // грань к дорожке

    const field = new THREE.Mesh(buildWall(c, offField, y0, y1, false, uScale), mat);
    const track = new THREE.Mesh(buildWall(c, offTrack, y0, y1, true,  uScale), mat);
    const cap   = new THREE.Mesh(buildBand(c, offField, offTrack, y1, 1, false), capMat);
    field.name = 'fence_panels_field'; track.name = 'fence_panels_track'; cap.name = 'fence_cap';
    for (const m of [field, track, cap]) { m.castShadow = true; m.receiveShadow = true; group.add(m); }

    return { group, disposables: [mat, capMat, tex], panels: repeats };
}

/** Текстура одного рекламного щита (5 × 1 м): нейтральный серый, швы, плинтус. */
function createAdTexture() {
    const W = 1024, H = 256;
    const cv = document.createElement('canvas');
    cv.width = W; cv.height = H;
    const g = cv.getContext('2d', { alpha: false });
    g.fillStyle = '#7f858b'; g.fillRect(0, 0, W, H);
    g.fillStyle = '#979da3'; g.fillRect(14, 22, W - 28, 190);          // панель
    g.strokeStyle = '#6b7075'; g.lineWidth = 4; g.strokeRect(14, 22, W - 28, 190);
    g.fillStyle = '#6d7277'; g.fillRect(0, 222, W, 34);                // плинтус
    g.fillStyle = '#a6abb0'; g.fillRect(0, 0, W, 10);                  // верхний кант
    g.fillStyle = '#4f5358';                                           // швы между щитами
    g.fillRect(0, 0, 5, H); g.fillRect(W - 5, 0, 5, H);
    const tx = new THREE.CanvasTexture(cv);
    tx.colorSpace = THREE.SRGBColorSpace;
    tx.wrapS = THREE.RepeatWrapping; tx.wrapT = THREE.ClampToEdgeWrapping;
    tx.anisotropy = 16;
    return tx;
}

/** Сплошной серый забор из щитов по внешнему краю дорожки. */
function createAdFence(c) {
    const group = new THREE.Group();
    group.name = 'ad_fence';

    const repeats = Math.max(1, Math.round(c.perimeter / AD_PANEL_LEN));
    const uScale = repeats / c.perimeter;       // целое число щитов — без шва

    const tex = createAdTexture();
    const mat = new THREE.MeshStandardMaterial({
        name: 'ad_fence_panel', map: tex, roughness: 0.65, metalness: 0.05, envMapIntensity: 0.5,
    });
    const capMat = new THREE.MeshStandardMaterial({
        name: 'ad_fence_cap', color: 0x5d6267, roughness: 0.6, metalness: 0.1,
    });

    const y0 = TRACK_Y - 0.005, y1 = AD_HEIGHT;
    const offIn  = TRACK_WIDTH + AD_OFFSET - AD_THICK / 2;   // грань к дорожке
    const offOut = TRACK_WIDTH + AD_OFFSET + AD_THICK / 2;   // грань к трибунам

    const inner = new THREE.Mesh(buildWall(c, offIn,  y0, y1, false, uScale), mat);
    const outer = new THREE.Mesh(buildWall(c, offOut, y0, y1, true,  uScale), mat);
    const cap   = new THREE.Mesh(buildBand(c, offIn, offOut, y1, 1, false), capMat);
    inner.name = 'ad_fence_inner'; outer.name = 'ad_fence_outer'; cap.name = 'ad_fence_cap';
    for (const m of [inner, outer, cap]) { m.castShadow = true; m.receiveShadow = true; group.add(m); }

    return { group, disposables: [mat, capMat, tex], offIn, offOut, panels: repeats };
}


/* ══════════════════════════════════════════════════════════════════════════
 *  § 11. СБОРКА ДОРОЖКИ
 * ══════════════════════════════════════════════════════════════════════════ */

function createRunningTrack(c) {
    const group = new THREE.Group();
    group.name = 'running_track';

    /* Подгоняем длину тайла так, чтобы по периметру укладывалось целое
     * число повторов текстуры — иначе на стыке будет видимый шов. */
    const repeats = Math.max(1, Math.round(c.perimeter / TRACK_TILE_TARGET));
    const uScale = repeats / c.perimeter;

    const { map, bump } = createTrackTextures();
    bump.repeat.set(repeats * 2, 1);   // зерно: ~8 м на тайл

    const trackMat = new THREE.MeshStandardMaterial({
        name: 'track_rubber',
        map,
        bumpMap: bump,
        bumpScale: 0.6,
        roughness: 0.92,
        metalness: 0.0,
        envMapIntensity: 0.35,
    });
    trackMat.polygonOffset = true;
    trackMat.polygonOffsetFactor = -1;
    trackMat.polygonOffsetUnits = -1;

    /* ── Полотно ── */
    const trackGeo = buildBand(c, 0, TRACK_WIDTH, TRACK_Y, uScale, true);
    /* Бамп-карта использует те же UV (u по периметру, v 0..1) —
     * подгоним повтор, чтобы зерно не растягивалось. */
    const track = new THREE.Mesh(trackGeo, trackMat);
    track.name = 'track_surface';
    track.receiveShadow = true;
    group.add(track);

    /* ── Внутренний бордюр (белый) ── */
    const kerbMat = new THREE.MeshStandardMaterial({
        name: 'track_kerb', color: 0xf1efe8, roughness: 0.8, metalness: 0.0,
    });
    const kerbTop = new THREE.Mesh(
        buildBand(c, -KERB_WIDTH, 0, TRACK_Y + KERB_HEIGHT, uScale, false), kerbMat);
    kerbTop.name = 'track_kerb_top';
    const kerbIn = new THREE.Mesh(
        buildWall(c, -KERB_WIDTH, TRACK_Y - 0.01, TRACK_Y + KERB_HEIGHT, false), kerbMat);
    const kerbOut = new THREE.Mesh(
        buildWall(c, 0, TRACK_Y, TRACK_Y + KERB_HEIGHT, true), kerbMat);
    for (const m of [kerbTop, kerbIn, kerbOut]) { m.receiveShadow = true; m.castShadow = true; group.add(m); }

    /* ── Внешняя бетонная кромка ── */
    const apronMat = new THREE.MeshStandardMaterial({
        name: 'track_apron', color: 0x8a8d90, roughness: 0.95, metalness: 0.0,
    });
    const apron = new THREE.Mesh(
        buildBand(c, TRACK_WIDTH, TRACK_WIDTH + APRON_WIDTH, TRACK_Y - 0.005, uScale, false), apronMat);
    apron.name = 'track_apron';
    apron.receiveShadow = true;
    group.add(apron);

    /* ── Линия финиша: поперёк дорожек на нижней прямой (z > 0), x ≈ +20 ── */
    let fi = 0, best = Infinity;
    for (let i = 0; i < TRACK_SEGMENTS; i++) {
        const p = c.pts[i];
        if (p.z > 0 && Math.abs(p.x - 20) < best) { best = Math.abs(p.x - 20); fi = i; }
    }
    const [fx0, fz0] = offsetPoint(c, fi, 0);
    const [fx1, fz1] = offsetPoint(c, fi, TRACK_WIDTH);
    const fLen = Math.hypot(fx1 - fx0, fz1 - fz0);
    const finish = new THREE.Mesh(
        new THREE.PlaneGeometry(fLen, 0.10),
        new THREE.MeshStandardMaterial({ color: 0xffffff, roughness: 0.8 }));
    finish.name = 'track_finish_line';
    finish.rotation.x = -Math.PI / 2;
    finish.rotation.z = -Math.atan2(fz1 - fz0, fx1 - fx0);
    finish.position.set((fx0 + fx1) / 2, TRACK_Y + 0.004, (fz0 + fz1) / 2);
    finish.receiveShadow = true;
    group.add(finish);

    /* ── Полигоны для запросов «где точка» (внутренний и внешний край) ── */
    const innerPoly = [], outerPoly = [], apronPoly = [];
    for (let i = 0; i < TRACK_SEGMENTS; i += 4) {
        innerPoly.push(offsetPoint(c, i, 0));
        outerPoly.push(offsetPoint(c, i, TRACK_WIDTH));
        apronPoly.push(offsetPoint(c, i, TRACK_WIDTH + APRON_WIDTH));
    }

    return {
        group,
        contour: c,
        polys: { innerPoly, outerPoly, apronPoly },
        disposables: [trackMat, kerbMat, apronMat, map, bump, finish.material],
    };
}

function pointInPoly(x, z, poly) {
    let inside = false;
    for (let i = 0, j = poly.length - 1; i < poly.length; j = i++) {
        const [xi, zi] = poly[i], [xj, zj] = poly[j];
        if ((zi > z) !== (zj > z) && x < ((xj - xi) * (z - zi)) / (zj - zi) + xi) inside = !inside;
    }
    return inside;
}


/* ══════════════════════════════════════════════════════════════════════════
 *  § 12. ПУБЛИЧНЫЙ API
 * ══════════════════════════════════════════════════════════════════════════ */

/**
 * Создаёт газон + беговую дорожку. Требует DOM (canvas) — вызывать в браузере.
 *
 * @param {Object}  [opts]
 * @param {boolean} [opts.track=true]   — беговая дорожка (+ подложка газона)
 * @param {boolean} [opts.fence=true]   — белое панельное ограждение вокруг газона (нужна дорожка)
 * @param {boolean} [opts.adFence=true] — серый рекламный забор по внешнему краю дорожки
 * @returns {{
 *   group: THREE.Group, pitchMesh: THREE.Mesh, trackGroup: THREE.Group|null,
 *   surfaceHeight: number,
 *   getSurfaceAt: (x:number, z:number) => 'pitch'|'track'|'apron'|null,
 *   isOnPitch: (x:number, z:number) => boolean,
 *   isOnTrack: (x:number, z:number) => boolean,
 *   getLanePoint: (lane:number, s:number) => {x:number, z:number, tx:number, tz:number},
 *   getTrackInfo: () => Object,
 *   dispose: () => void
 * }}
 */
export function createStadiumPitch(opts = {}) {
    const withTrack = opts.track !== false;

    const root = new THREE.Group();
    root.name = 'stadium_pitch';

    /* ── Газон ── */
    pitchTexture = createPitchTexture();
    grassBumpTexture = heightFieldToBumpTexture(generateGrassHeightField(DETAIL_TEX_SIZE), DETAIL_TEX_SIZE);
    const material = createGrassMaterial();
    /* Газон чуть «ближе» к камере, чем зелёная подложка, — без z-fighting. */
    material.polygonOffset = true;
    material.polygonOffsetFactor = -1;
    material.polygonOffsetUnits = -1;

    const geometry = new THREE.PlaneGeometry(PLANE_LENGTH, PLANE_WIDTH, 1, 1);
    const pitchMesh = new THREE.Mesh(geometry, material);
    pitchMesh.name = 'pitch_grass';
    pitchMesh.rotation.x = -Math.PI * 0.5;
    pitchMesh.position.set(0, 0, 0);
    pitchMesh.receiveShadow = true;
    pitchMesh.castShadow = false;
    root.add(pitchMesh);

    /* ── Дорожка ── */
    let track = null, infield = null, fence = null, adFence = null;
    let fencePoly = null, adPoly = null;
    if (withTrack) {
        const contour = buildContour();

        /* Подложка: зелёное до самого бордюра (между краем плоскости и дорожкой). */
        infield = createInfield(contour);
        root.add(infield.mesh);

        track = createRunningTrack(contour);
        root.add(track.group);

        if (opts.fence !== false) {
            fence = createWhiteFence(contour);
            root.add(fence.group);
            fencePoly = [];
            for (let i = 0; i < TRACK_SEGMENTS; i += 4) fencePoly.push(offsetPoint(contour, i, FENCE_OFFSET));
        }
        if (opts.adFence !== false) {
            adFence = createAdFence(contour);
            root.add(adFence.group);
            adPoly = [];
            for (let i = 0; i < TRACK_SEGMENTS; i += 4) adPoly.push(offsetPoint(contour, i, adFence.offIn));
        }
    }

    const halfL = FIELD_LENGTH * 0.5, halfW = FIELD_WIDTH * 0.5;

    const api = {
        group: root,
        pitchMesh,
        trackGroup: track ? track.group : null,
        surfaceHeight: 0,

        isOnPitch(x, z) {
            return Math.abs(x) <= PLANE_LENGTH * 0.5 && Math.abs(z) <= PLANE_WIDTH * 0.5
                && !(track && !pointInPoly(x, z, track.polys.innerPoly));
        },

        /** В пределах размеченного поля 105 × 68. */
        isInsideLines(x, z) {
            return Math.abs(x) <= halfL && Math.abs(z) <= halfW;
        },

        isOnTrack(x, z) {
            if (!track) return false;
            return pointInPoly(x, z, track.polys.outerPoly) && !pointInPoly(x, z, track.polys.innerPoly);
        },

        /** Точка внутри белого заборчика (игровая зона газона). */
        isInsideFence(x, z) {
            return fencePoly ? pointInPoly(x, z, fencePoly) : false;
        },

        /** Точка внутри серого рекламного забора (газон + дорожка). */
        isInsideAdFence(x, z) {
            return adPoly ? pointInPoly(x, z, adPoly) : false;
        },

        getBarrierInfo() {
            return {
                fence: fence ? { offsetFromTrackInnerEdge: FENCE_OFFSET, height: FENCE_BOARD_H, thickness: FENCE_BOARD_T, panels: fence.panels } : null,
                adFence: adFence ? {
                    offsetFromTrackOuterEdge: AD_OFFSET, height: AD_HEIGHT,
                    thickness: AD_THICK, panels: adFence.panels,
                } : null,
            };
        },

        fenceGroup: fence ? fence.group : null,
        adFenceGroup: adFence ? adFence.group : null,
        infieldMesh: infield ? infield.mesh : null,

        getSurfaceAt(x, z) {
            if (track) {
                if (pointInPoly(x, z, track.polys.innerPoly)) return 'pitch';
                if (pointInPoly(x, z, track.polys.outerPoly)) return 'track';
                if (pointInPoly(x, z, track.polys.apronPoly)) return 'apron';
                return null;
            }
            return (Math.abs(x) <= PLANE_LENGTH * 0.5 && Math.abs(z) <= PLANE_WIDTH * 0.5) ? 'pitch' : null;
        },

        /**
         * Точка на середине дорожки `lane` (1 = внутренняя) и касательная.
         * @param {number} lane 1..6   @param {number} s 0..1 — доля периметра
         */
        getLanePoint(lane, s) {
            if (!track) return null;
            const c = track.contour;
            const off = (lane - 0.5) * TRACK_LANE_WIDTH;
            const i = Math.floor(((s % 1) + 1) % 1 * TRACK_SEGMENTS);
            const [x, z] = offsetPoint(c, i, off);
            const [x2, z2] = offsetPoint(c, i + 1, off);
            const len = Math.hypot(x2 - x, z2 - z) || 1;
            return { x, z, tx: (x2 - x) / len, tz: (z2 - z) / len };
        },

        getTrackInfo() {
            return track ? {
                lanes: TRACK_LANES, laneWidth: TRACK_LANE_WIDTH, width: TRACK_WIDTH,
                innerRadiusX: TRACK_INNER_RX, innerRadiusZ: TRACK_INNER_RZ,
                outerRadiusX: TRACK_INNER_RX + TRACK_WIDTH, outerRadiusZ: TRACK_INNER_RZ + TRACK_WIDTH,
                innerPerimeter: track.contour.perimeter, y: TRACK_Y,
            } : null;
        },

        dispose() {
            root.traverse(o => { if (o.geometry) o.geometry.dispose(); });
            for (const m of [material, pitchTexture, grassBumpTexture]) if (m && m.dispose) m.dispose();
            if (track) for (const d of track.disposables) if (d && d.dispose) d.dispose();
            for (const part of [infield, fence, adFence]) {
                if (part) for (const d of part.disposables) if (d && d.dispose) d.dispose();
            }
            if (root.parent) root.parent.remove(root);
        },
    };
    return api;
}
