/**
 * src/components/stadium/StadiumConfig.js
 *
 * ══════════════════════════════════════════════════════════════════════════
 *  ЕДИНЫЙ ИСТОЧНИК ИСТИНЫ для всей геометрии стадиона.
 *
 *  ─── ВЕРСИЯ ──────────────────────────────────────────────────────────────
 *    Compact Edition — 6000 мест вместо 86 000.
 *    Все элементы пропорционально уменьшены, архитектура сохранена:
 *      • 3 яруса (6 / 7 / 5 рядов)
 *      • Ширина места 1.4 м (вместо 0.48 м)
 *      • Пропорционально уменьшены крыша, фасад, колонны
 *      • Проверено: ярусы не пересекаются, крыша выше трибун
 *
 *  ─── КООРДИНАТНАЯ СИСТЕМА ────────────────────────────────────────────────
 *    • Центр арены  = (0, 0, 0)
 *    • Поле лежит в плоскости XZ:
 *         длина поля (105 м) вдоль оси X,
 *         ширина поля (68 м) вдоль оси Z.
 *    • Вверх — ось Y.
 *    • Трибуны — вложенные СУПЕРЭЛЛИПСЫ (прямоугольники со скруглёнными
 *      углами, показатель — shape.power) вокруг центра.
 *
 *  ─── РАСЧЁТ ЯРУСОВ ───────────────────────────────────────────────────────
 *    Поле: 105 × 68 → вписываем в суперэллипс.
 *    Внутренний контур 1-го яруса = (105/2 + 22, 68/2 + 21) = 74.5 × 55.0.
 *    Каждый следующий ярус начинается там, где заканчивается предыдущий,
 *    плюс разделительный пояс 1.5 м.
 * ══════════════════════════════════════════════════════════════════════════
 */

/* ══════════════════════════════════════════════════════════════════════════
 *  § 1. БАЗОВЫЕ КОНСТАНТЫ ПОЛЯ
 * ══════════════════════════════════════════════════════════════════════════ */

/** Длина поля по FIFA (м). */
const PITCH_LENGTH = 105.0;

/** Ширина поля по FIFA (м). */
const PITCH_WIDTH = 68.0;

/** Зазор от короткой стороны поля до первого ряда трибун (м). */
const PITCH_INSET_LENGTH = 22.0;

/** Зазор от длинной стороны поля до первого ряда трибун (м). */
const PITCH_INSET_WIDTH = 21.0;

/** Внутренний радиус овала 1-го яруса по оси X (м). */
const TIER_BASE_RADIUS_X = PITCH_LENGTH / 2 + PITCH_INSET_LENGTH;   // 74.5

/** Внутренний радиус овала 1-го яруса по оси Z (м). */
const TIER_BASE_RADIUS_Z = PITCH_WIDTH / 2 + PITCH_INSET_WIDTH;     // 55.0

/**
 * Показатель суперэллипса (кривая Ламе): |x/a|^n + |z/b|^n = 1.
 *   n = 2.0 → обычный эллипс
 *   n = 3.5 → прямоугольник со скруглёнными углами (ЦЕЛЬ)
 *   n = 5.0 → почти прямоугольник
 * Рекомендуемый диапазон подстройки: 3.0–4.5.
 */
const SHAPE_POWER = 3.5;


/* ══════════════════════════════════════════════════════════════════════════
 *  § 2. ГЕОМЕТРИЯ ОДНОГО РЯДА
 * ══════════════════════════════════════════════════════════════════════════ */

/** Глубина одного ряда сидений (м). */
const ROW_DEPTH = 0.85;

/** Высота подступенка между рядами (м). */
const ROW_HEIGHT = 0.55;

/**
 * Ширина одного сиденья (м).
 * ⚠️ Увеличено с 0.48 до 1.40 — места стоят в 3 раза реже по кольцу,
 * итоговое количество мест ~6000 вместо ~86 000.
 */
const SEAT_WIDTH = 1.40;


/* ══════════════════════════════════════════════════════════════════════════
 *  § 3. ЯРУСЫ
 *  Три яруса: 6 + 7 + 5 = 18 рядов суммарно.
 *  Между ярусами — разделительный пояс 1.5 м.
 * ══════════════════════════════════════════════════════════════════════════ */

/** Разделительный пояс между 1-м и 2-м ярусом (м). */
const INTER_TIER_GAP_1 = 1.5;

/** Разделительный пояс между 2-м и 3-м ярусом (м). */
const INTER_TIER_GAP_2 = 1.5;

/* ─── Параметры каждого яруса ─────────────────────────────────────────── */

/** Количество рядов в каждом ярусе (было 24/28/22). */
const TIER_1_ROWS = 6;
const TIER_2_ROWS = 7;
const TIER_3_ROWS = 5;

/** Общая глубина яруса (м). */
const TIER_1_DEPTH = TIER_1_ROWS * ROW_DEPTH;   // 5.10 м
const TIER_2_DEPTH = TIER_2_ROWS * ROW_DEPTH;   // 5.95 м
const TIER_3_DEPTH = TIER_3_ROWS * ROW_DEPTH;   // 4.25 м

/** Общая высота яруса (м). */
const TIER_1_HEIGHT = TIER_1_ROWS * ROW_HEIGHT;   // 3.30 м
const TIER_2_HEIGHT = TIER_2_ROWS * ROW_HEIGHT;   // 3.85 м
const TIER_3_HEIGHT = TIER_3_ROWS * ROW_HEIGHT;   // 2.75 м

/* ─── Начала ярусов по X ───────────────────────────────────────────────── */

const TIER_1_START_X = TIER_BASE_RADIUS_X;                                          // 74.50
const TIER_2_START_X = TIER_1_START_X + TIER_1_DEPTH + INTER_TIER_GAP_1;            // 81.10
const TIER_3_START_X = TIER_2_START_X + TIER_2_DEPTH + INTER_TIER_GAP_2;            // 88.55

/* ─── Начала ярусов по Z ───────────────────────────────────────────────── */

const TIER_1_START_Z = TIER_BASE_RADIUS_Z;                                          // 55.00
const TIER_2_START_Z = TIER_1_START_Z + TIER_1_DEPTH + INTER_TIER_GAP_1;            // 61.60
const TIER_3_START_Z = TIER_2_START_Z + TIER_2_DEPTH + INTER_TIER_GAP_2;            // 69.05

/* ─── Верхние радиусы (конец последнего ряда) ─────────────────────────── */

const TIER_3_END_X = TIER_3_START_X + TIER_3_DEPTH;   // 92.80
const TIER_3_END_Z = TIER_3_START_Z + TIER_3_DEPTH;   // 73.30

/* ─── Кумулятивные высоты (низ яруса) ─────────────────────────────────── */

const TIER_1_BASE_Y = 0.0;                              // 0
const TIER_2_BASE_Y = TIER_1_HEIGHT;                    // 3.30
const TIER_3_BASE_Y = TIER_2_BASE_Y + TIER_2_HEIGHT;    // 7.15
const STANDS_TOP_Y  = TIER_3_BASE_Y + TIER_3_HEIGHT;    // 9.90


/* ══════════════════════════════════════════════════════════════════════════
 *  § 4. ФАСАД
 * ══════════════════════════════════════════════════════════════════════════ */

/** Отступ фасада наружу от последнего ряда верхнего яруса (м). */
const FACADE_OFFSET = 4.0;

/** Внешние радиусы фасада. */
const FACADE_RADIUS_X = TIER_3_END_X + FACADE_OFFSET;   // 96.80
const FACADE_RADIUS_Z = TIER_3_END_Z + FACADE_OFFSET;   // 77.30

/**
 * Высота фасада (м).
 * ⚠️ Уменьшена с 42 до 15 — пропорционально низким трибунам (9.9 м).
 */
const FACADE_HEIGHT = 15.0;

/** Количество вертикальных рёбер фасада. */
const FACADE_RIB_COUNT = 32;

/** Размеры рёбер. */
const FACADE_RIB_WIDTH = 0.90;
const FACADE_RIB_DEPTH = 0.60;

/** Горизонтальные пояса — каждые N метров. */
const FACADE_BELT_SPACING = 3.0;
const FACADE_BELT_HEIGHT = 0.40;
const FACADE_BELT_DEPTH = 0.30;


/* ══════════════════════════════════════════════════════════════════════════
 *  § 5. КРЫША
 * ══════════════════════════════════════════════════════════════════════════ */

/** Смещение внутреннего края крыши внутрь (отрицательное = внутрь). */
const ROOF_INNER_OFFSET = -8.0;

/** Смещение внешнего края крыши наружу от фасада (м). */
const ROOF_OUTER_OFFSET = 4.0;

/** Внутренние радиусы крыши (немного внутрь от верхнего яруса). */
const ROOF_INNER_RADIUS_X = TIER_3_END_X + ROOF_INNER_OFFSET;   // 84.80
const ROOF_INNER_RADIUS_Z = TIER_3_END_Z + ROOF_INNER_OFFSET;   // 65.30

/** Внешние радиусы крыши (немного наружу от фасада). */
const ROOF_OUTER_RADIUS_X = FACADE_RADIUS_X + ROOF_OUTER_OFFSET;   // 100.80
const ROOF_OUTER_RADIUS_Z = FACADE_RADIUS_Z + ROOF_OUTER_OFFSET;   // 81.30

/**
 * Высотная посадка крыши (м).
 * ⚠️ Уменьшена с 44 до 17 — выше трибун на 7 м.
 */
const ROOF_BASE_HEIGHT = 17.0;

/** Лёгкий наклон вниз к центру чаши (м). */
const ROOF_INNER_DROP = 0.80;

/** Толщина плиты навеса (м). */
const ROOF_THICKNESS = 0.70;

/** Опорные колонны крыши. */
const ROOF_PILLAR_COUNT = 16;
const ROOF_PILLAR_RADIUS = 0.35;
const ROOF_PILLAR_SEGMENTS = 10;


/* ══════════════════════════════════════════════════════════════════════════
 *  § 6. ИНФРАСТРУКТУРА
 * ══════════════════════════════════════════════════════════════════════════ */

/** Колонны каркаса вокруг арены (между ярусами). */
const PILLAR_COUNT = 16;
const PILLAR_RADIUS = 0.50;
const PILLAR_SEGMENTS = 12;

/** Поперечные фермы — каждые N колонн. */
const TRUSS_EVERY_N = 4;

/** Лестничные проходы внутри трибун. */
const AISLE_COUNT = 8;
const AISLE_WIDTH = 1.80;

/** Входы в чашу на уровне поля. */
const VOMITORY_COUNT = 6;
const VOMITORY_WIDTH = 3.20;
const VOMITORY_HEIGHT = 2.40;


/* ══════════════════════════════════════════════════════════════════════════
 *  § 7. ОСВЕЩЕНИЕ
 * ══════════════════════════════════════════════════════════════════════════ */

const FLOODLIGHT_COUNT = 8;
const FLOODLIGHT_HEIGHT = 3.0;
const FLOODLIGHT_INTENSITY = 70.0;
const FLOODLIGHT_DISTANCE = 180.0;
const FLOODLIGHT_RADIUS = 88.0;

const AMBIENT_COLOR = 0xa8c0d8;
const AMBIENT_INTENSITY = 0.35;

const HEMISPHERE_SKY = 0xc8d8e8;
const HEMISPHERE_GROUND = 0x1a1e22;
const HEMISPHERE_INTENSITY = 0.55;

const SUN_INTENSITY = 1.15;
const SUN_POSITION = [60.0, 120.0, 40.0];


/* ══════════════════════════════════════════════════════════════════════════
 *  § 8. ОБЩИЕ ПАРАМЕТРЫ СЦЕНЫ
 * ══════════════════════════════════════════════════════════════════════════ */

const GROUND_SIZE = 400.0;
const FOG_COLOR = 0x0a0e12;
const FOG_DENSITY = 0.0013;
const CLEAR_COLOR = 0x0a0e12;


/* ══════════════════════════════════════════════════════════════════════════
 *  § 9. ПРОИЗВОДИТЕЛЬНОСТЬ
 * ══════════════════════════════════════════════════════════════════════════ */

/** Сегментов вокруг арены для большинства круговых элементов. */
const RADIAL_SEGMENTS = 96;

/** Детализация ступеней яруса. */
const TIER_RADIAL_SEGMENTS = 72;


/* ══════════════════════════════════════════════════════════════════════════
 *  § 10. ПАЛИТРА СИДЕНИЙ
 *  Кластеры цвета для визуального разнообразия трибун.
 * ══════════════════════════════════════════════════════════════════════════ */

const SEAT_PALETTE = [
    0xb2262b,   // основной красный
    0x8c1d22,   // тёмно-красный
    0xd94148,   // яркий красный
    0x1e2a38,   // тёмно-синий
    0x2f4a6b,   // синий
    0xe8e2d4,   // кремовый
    0x3c3f44,   // графит
    0xc4b48a,   // песочный
];


/* ══════════════════════════════════════════════════════════════════════════
 *  § 11. СБОРКА И ЭКСПОРТ КОНФИГА
 * ══════════════════════════════════════════════════════════════════════════ */

/**
 * Главный конфиг арены.
 * Объект глубоко заморожен — мутации невозможны.
 */
export const STADIUM_CONFIG = deepFreeze({

    /* ─── ФОРМА КОНТУРА ────────────────────────────────────────────── */
    shape: {
        power: SHAPE_POWER,
    },

    /* ─── ПОЛЕ ─────────────────────────────────────────────────────── */
    pitch: {
        length: PITCH_LENGTH,
        width: PITCH_WIDTH,
        insetLength: PITCH_INSET_LENGTH,
        insetWidth: PITCH_INSET_WIDTH,
        baseRadiusX: TIER_BASE_RADIUS_X,
        baseRadiusZ: TIER_BASE_RADIUS_Z,
    },

    /* ─── РЯД ──────────────────────────────────────────────────────── */
    row: {
        depth: ROW_DEPTH,
        height: ROW_HEIGHT,
        seatWidth: SEAT_WIDTH,
    },

    /* ─── ЯРУСЫ ────────────────────────────────────────────────────── */
    tiers: [
        {
            id: 'lower',
            name: 'Нижний ярус',
            startRadiusX: TIER_1_START_X,
            startRadiusZ: TIER_1_START_Z,
            rows: TIER_1_ROWS,
            depth: TIER_1_DEPTH,
            height: TIER_1_HEIGHT,
            baseY: TIER_1_BASE_Y,
            outerWallHeight: 0.60,
        },
        {
            id: 'middle',
            name: 'Средний ярус',
            startRadiusX: TIER_2_START_X,
            startRadiusZ: TIER_2_START_Z,
            rows: TIER_2_ROWS,
            depth: TIER_2_DEPTH,
            height: TIER_2_HEIGHT,
            baseY: TIER_2_BASE_Y,
            outerWallHeight: 0.60,
        },
        {
            id: 'upper',
            name: 'Верхний ярус',
            startRadiusX: TIER_3_START_X,
            startRadiusZ: TIER_3_START_Z,
            rows: TIER_3_ROWS,
            depth: TIER_3_DEPTH,
            height: TIER_3_HEIGHT,
            baseY: TIER_3_BASE_Y,
            outerWallHeight: 0.60,
        },
    ],

    /* ─── ГАБАРИТЫ АРЕНЫ ───────────────────────────────────────────── */
    arena: {
        outerRadiusX: TIER_3_END_X,
        outerRadiusZ: TIER_3_END_Z,
        standsTopY: STANDS_TOP_Y,
        totalHeight: FACADE_HEIGHT,
    },

    /* ─── ФАСАД ────────────────────────────────────────────────────── */
    facade: {
        offset: FACADE_OFFSET,
        radiusX: FACADE_RADIUS_X,
        radiusZ: FACADE_RADIUS_Z,
        height: FACADE_HEIGHT,
        ribCount: FACADE_RIB_COUNT,
        ribWidth: FACADE_RIB_WIDTH,
        ribDepth: FACADE_RIB_DEPTH,
        beltSpacing: FACADE_BELT_SPACING,
        beltHeight: FACADE_BELT_HEIGHT,
        beltDepth: FACADE_BELT_DEPTH,
    },

    /* ─── КРЫША ────────────────────────────────────────────────────── */
    roof: {
        innerRadiusX: ROOF_INNER_RADIUS_X,
        innerRadiusZ: ROOF_INNER_RADIUS_Z,
        outerRadiusX: ROOF_OUTER_RADIUS_X,
        outerRadiusZ: ROOF_OUTER_RADIUS_Z,
        baseHeight: ROOF_BASE_HEIGHT,
        innerDrop: ROOF_INNER_DROP,
        thickness: ROOF_THICKNESS,
        pillarCount: ROOF_PILLAR_COUNT,
        pillarRadius: ROOF_PILLAR_RADIUS,
        pillarSegments: ROOF_PILLAR_SEGMENTS,
    },

    /* ─── ИНФРАСТРУКТУРА ───────────────────────────────────────────── */
    infrastructure: {
        pillarCount: PILLAR_COUNT,
        pillarRadius: PILLAR_RADIUS,
        pillarSegments: PILLAR_SEGMENTS,
        trussEveryN: TRUSS_EVERY_N,
        aisleCount: AISLE_COUNT,
        aisleWidth: AISLE_WIDTH,
        vomitoryCount: VOMITORY_COUNT,
        vomitoryWidth: VOMITORY_WIDTH,
        vomitoryHeight: VOMITORY_HEIGHT,
    },

    /* ─── ОСВЕЩЕНИЕ ────────────────────────────────────────────────── */
    lighting: {
        floodlightCount: FLOODLIGHT_COUNT,
        floodlightHeight: FLOODLIGHT_HEIGHT,
        floodlightIntensity: FLOODLIGHT_INTENSITY,
        floodlightDistance: FLOODLIGHT_DISTANCE,
        floodlightRadius: FLOODLIGHT_RADIUS,
        ambientColor: AMBIENT_COLOR,
        ambientIntensity: AMBIENT_INTENSITY,
        hemisphereSky: HEMISPHERE_SKY,
        hemisphereGround: HEMISPHERE_GROUND,
        hemisphereIntensity: HEMISPHERE_INTENSITY,
        sunIntensity: SUN_INTENSITY,
        sunPosition: SUN_POSITION,
    },

    /* ─── МАТЕРИАЛЫ ────────────────────────────────────────────────── */
    materials: {
        concrete:     { color: 0x8c9098, roughness: 0.92, metalness: 0.05 },
        darkConcrete: { color: 0x5a5e66, roughness: 0.88, metalness: 0.05 },
        steel:        { color: 0xb8bcc4, roughness: 0.42, metalness: 0.78 },
        darkSteel:    { color: 0x3a3e44, roughness: 0.55, metalness: 0.72 },
        glass: {
            color: 0x9ec8e8,
            roughness: 0.08,
            metalness: 0.00,
            transmission: 0.85,
            thickness: 0.40,
        },
        roofTop:    { color: 0xd0d4d8, roughness: 0.60, metalness: 0.05 },
        roofBottom: { color: 0x3a3e44, roughness: 0.85, metalness: 0.05 },
        ground:     { color: 0x14181c, roughness: 0.98, metalness: 0.00 },
        pillarTrim: { color: 0x1a1e24, roughness: 0.60, metalness: 0.40 },
    },

    /* ─── ПАЛИТРА МЕСТ ─────────────────────────────────────────────── */
    seatPalette: SEAT_PALETTE,

    /* ─── СЦЕНА ────────────────────────────────────────────────────── */
    scene: {
        groundSize: GROUND_SIZE,
        fogColor: FOG_COLOR,
        fogDensity: FOG_DENSITY,
        clearColor: CLEAR_COLOR,
    },

    /* ─── ПРОИЗВОДИТЕЛЬНОСТЬ ───────────────────────────────────────── */
    performance: {
        radialSegments: RADIAL_SEGMENTS,
        tierRadialSegments: TIER_RADIAL_SEGMENTS,
    },
});


/* ══════════════════════════════════════════════════════════════════════════
 *  § 11б. СУПЕРЭЛЛИПС — ЕДИНАЯ ПАРАМЕТРИЗАЦИЯ КОНТУРА
 *
 *  Все контуры (трибуны, крыша, фасад, колонны, места) строятся
 *  через эти функции. Ни в одном модуле не должно быть «голых»
 *  cos(a)·rx / sin(a)·rz.
 *
 *    x = sign(cos t)·|cos t|^(2/n)·a
 *    z = sign(sin t)·|sin t|^(2/n)·b
 *
 *  ВАЖНО: параметр t НЕ равен полярному углу и шагает по кривой
 *  неравномерно (на прямых сторонах шаг по длине дуги больше,
 *  в углах — меньше). Поэтому для расстановки дискретных объектов
 *  (колонны, места, лестницы…) используйте superEllipseEvenAngles().
 * ══════════════════════════════════════════════════════════════════════════ */

/**
 * Точка на суперэллипсе.
 *
 * @param {number} angle — параметр t (рад)
 * @param {number} rx    — полуось по X
 * @param {number} rz    — полуось по Z
 * @param {number} power — показатель n (2 = эллипс)
 * @returns {{x: number, z: number}}
 */
export function superEllipsePoint(angle, rx, rz, power) {
    const c = Math.cos(angle);
    const s = Math.sin(angle);
    const k = 2 / power;
    return {
        x: Math.sign(c) * Math.pow(Math.abs(c), k) * rx,
        z: Math.sign(s) * Math.pow(Math.abs(s), k) * rz,
    };
}

/**
 * Единичная касательная к суперэллипсу (в сторону роста t) и
 * внешняя нормаль. Численная производная, центральная разность.
 *
 * Для t, где |cos t| или |sin t| → 0, производная аналитически
 * бесконечна (вертикальная/горизонтальная касательная), поэтому
 * шаг берём симметричный и не слишком малый.
 *
 * @returns {{tx:number, tz:number, nx:number, nz:number, rotationY:number}}
 *   rotationY — угол Object3D.rotation.y, при котором локальная ось +Z
 *   объекта смотрит по внешней нормали (так же, как atan2(nx, nz)).
 */
export function superEllipseFrame(angle, rx, rz, power = SHAPE_POWER) {
    const EPS = 1e-3;
    const p0 = superEllipsePoint(angle - EPS, rx, rz, power);
    const p1 = superEllipsePoint(angle + EPS, rx, rz, power);
    const dx = p1.x - p0.x;
    const dz = p1.z - p0.z;
    const len = Math.hypot(dx, dz) || 1;

    const tx = dx / len;
    const tz = dz / len;

    /* Контур обходится против часовой (если смотреть сверху на XZ при
     * x = cos, z = sin) → внешняя нормаль = (tz, −tx). */
    const nx = tz;
    const nz = -tx;

    return { tx, tz, nx, nz, rotationY: Math.atan2(nx, nz) };
}

/** Кэш таблиц длины дуги: ключ = `${rx}|${rz}|${power}`. */
const _arcTableCache = new Map();

/**
 * Таблица накопленной длины дуги суперэллипса.
 *
 * Сетка по t НЕ равномерная: у осей (t = 0, π/2, π, 3π/2) координата
 * ведёт себя как |t|^(2/n) — производная там бесконечна, и равномерная
 * сетка даёт грубую длину дуги именно на прямых сторонах. Поэтому в каждом
 * квадранте узлы сгущены к краям подстановкой t = (π/2)·w(s), w ~ s^(n/2)
 * у концов (тогда |t|^(2/n) ~ s — гладко и линейно).
 *
 * @private
 */
function getArcTable(rx, rz, power) {
    const key = `${rx.toFixed(4)}|${rz.toFixed(4)}|${power}`;
    let table = _arcTableCache.get(key);
    if (table) return table;

    const PER_QUADRANT = 1024;
    const N = PER_QUADRANT * 4;
    const e = power / 2;   // = 1 / (2/n)

    /* w(s): 0→1, плотно у обоих концов. */
    const w = (u) => (u < 0.5)
        ? 0.5 * Math.pow(2 * u, e)
        : 1 - 0.5 * Math.pow(2 * (1 - u), e);

    const ts = new Float64Array(N + 1);
    const cum = new Float64Array(N + 1);

    ts[0] = 0;
    let prev = superEllipsePoint(0, rx, rz, power);
    for (let i = 1; i <= N; i++) {
        const q = Math.floor((i - 1) / PER_QUADRANT);          // номер квадранта
        const u = (i - q * PER_QUADRANT) / PER_QUADRANT;       // 0..1 внутри
        const t = (q + w(u)) * (Math.PI / 2);
        const pt = superEllipsePoint(t, rx, rz, power);
        ts[i] = t;
        cum[i] = cum[i - 1] + Math.hypot(pt.x - prev.x, pt.z - prev.z);
        prev = pt;
    }
    table = { ts, cum, total: cum[N], N };
    _arcTableCache.set(key, table);
    return table;
}

/**
 * Периметр суперэллипса (м) — численно.
 */
export function superEllipsePerimeter(rx, rz, power = SHAPE_POWER) {
    return getArcTable(rx, rz, power).total;
}

/**
 * Параметр t, соответствующий доле fraction (0..1) длины дуги,
 * отсчитанной от t = 0 против часовой стрелки.
 */
export function superEllipseAngleAtFraction(fraction, rx, rz, power = SHAPE_POWER) {
    const { ts, cum, total, N } = getArcTable(rx, rz, power);
    const f = ((fraction % 1) + 1) % 1;
    const target = f * total;

    let lo = 0, hi = N;
    while (hi - lo > 1) {
        const mid = (lo + hi) >> 1;
        if (cum[mid] <= target) lo = mid; else hi = mid;
    }
    const span = cum[hi] - cum[lo] || 1;
    const u = (target - cum[lo]) / span;
    return ts[lo] + (ts[hi] - ts[lo]) * u;
}

/**
 * Обратная функция к superEllipseAngleAtFraction: доля длины дуги
 * (0..1), на которой лежит точка с параметром t.
 */
export function superEllipseFractionAtAngle(angle, rx, rz, power = SHAPE_POWER) {
    const { ts, cum, total, N } = getArcTable(rx, rz, power);
    const TWO_PI = Math.PI * 2;
    const t = ((angle % TWO_PI) + TWO_PI) % TWO_PI;

    let lo = 0, hi = N;
    while (hi - lo > 1) {
        const mid = (lo + hi) >> 1;
        if (ts[mid] <= t) lo = mid; else hi = mid;
    }
    const span = ts[hi] - ts[lo] || 1;
    const u = (t - ts[lo]) / span;
    return (cum[lo] + (cum[hi] - cum[lo]) * u) / total;
}

/**
 * count значений параметра t, равномерно распределённых по ДЛИНЕ ДУГИ
 * контура с полуосями (rx, rz). Первая точка — t = 0 (+ offsetFraction).
 *
 * Если нужно, чтобы внутренний и внешний контуры (разные rx/rz) были
 * связаны фермами/лестницами под одним t — считайте t по опорному
 * контуру и подставляйте тот же t в superEllipsePoint для остальных.
 *
 * @param {number} count
 * @param {number} rx
 * @param {number} rz
 * @param {number} [power]
 * @param {number} [offsetFraction=0] — сдвиг старта (доля периметра, 0..1)
 * @returns {number[]}
 */
export function superEllipseEvenAngles(count, rx, rz, power = SHAPE_POWER, offsetFraction = 0) {
    const out = new Array(count);
    for (let i = 0; i < count; i++) {
        out[i] = superEllipseAngleAtFraction(i / count + offsetFraction, rx, rz, power);
    }
    return out;
}


/**
 * Параметры t осей азимутальных проходов (лестниц между секторами).
 * Единый источник для StandsModule (где пропускаются места) и
 * InfrastructureModule (где ставятся лестницы и перила) — иначе
 * лестницы и «щели» между секторами разъедутся.
 *
 * Проходы распределены равномерно по длине дуги опорного контура
 * (внутренний край 1-го яруса), а t затем используется для всех ярусов.
 *
 * @returns {number[]}
 */
export function getAisleAngles() {
    const { infrastructure, pitch, shape } = STADIUM_CONFIG;
    return superEllipseEvenAngles(
        infrastructure.aisleCount,
        pitch.baseRadiusX,
        pitch.baseRadiusZ,
        shape.power
    );
}


/**
 * Полуоси контура, по которому стоят прожекторы на крыше:
 * середина кольцевой плиты крыши (между внутренним и внешним краем).
 * Используется и визуальными корпусами (RoofModule), и источниками
 * света (StadiumLighting), чтобы они лежали на одном контуре.
 *
 * @returns {{rx: number, rz: number}}
 */
export function getFloodlightContour() {
    const r = STADIUM_CONFIG.roof;
    return {
        rx: (r.innerRadiusX + r.outerRadiusX) * 0.5,
        rz: (r.innerRadiusZ + r.outerRadiusZ) * 0.5,
    };
}


/* ══════════════════════════════════════════════════════════════════════════
 *  § 12. ПРОИЗВОДНЫЕ ФУНКЦИИ
 *  Вычисляются на лету, чтобы не дублировать данные в конфиге.
 * ══════════════════════════════════════════════════════════════════════════ */

/**
 * Возвращает список ярусов в порядке снизу вверх.
 */
export function getTierList() {
    return STADIUM_CONFIG.tiers;
}

/**
 * Возвращает ярус по идентификатору.
 */
export function getTierById(id) {
    return STADIUM_CONFIG.tiers.find(t => t.id === id) || null;
}

/**
 * Внешний радиус X (конец верхнего яруса).
 */
export function getOuterRadiusX() {
    return STADIUM_CONFIG.arena.outerRadiusX;
}

/**
 * Внешний радиус Z (конец верхнего яруса).
 */
export function getOuterRadiusZ() {
    return STADIUM_CONFIG.arena.outerRadiusZ;
}

/**
 * Общая высота трибун.
 */
export function getStandsHeight() {
    return STADIUM_CONFIG.arena.standsTopY;
}

/**
 * Границы зарезервированного под поле пространства.
 */
export function getPitchClearanceBounds() {
    const p = STADIUM_CONFIG.pitch;
    return {
        minX: -(p.baseRadiusX),
        maxX:  (p.baseRadiusX),
        minZ: -(p.baseRadiusZ),
        maxZ:  (p.baseRadiusZ),
        innerRadiusX: p.baseRadiusX,
        innerRadiusZ: p.baseRadiusZ,
    };
}

/**
 * Приблизительная оценка вместимости стадиона (без учёта проходов).
 * Периметр суперэллипса считается численно.
 */
export function estimateCapacity() {
    const { tiers, row, shape } = STADIUM_CONFIG;
    let total = 0;

    for (const tier of tiers) {
        const rMidX = tier.startRadiusX + tier.depth * 0.5;
        const rMidZ = tier.startRadiusZ + tier.depth * 0.5;

        /* Периметр суперэллипса считаем численно. */
        const perimeter = superEllipsePerimeter(rMidX, rMidZ, shape.power);

        const seatsPerRow = Math.floor(perimeter / row.seatWidth);
        total += seatsPerRow * tier.rows;
    }
    return total;
}

/**
 * Рекурсивная заморозка объекта.
 */
function deepFreeze(obj) {
    Object.freeze(obj);
    for (const key of Object.keys(obj)) {
        const value = obj[key];
        if (value && typeof value === 'object' && !Object.isFrozen(value)) {
            deepFreeze(value);
        }
    }
    return obj;
}